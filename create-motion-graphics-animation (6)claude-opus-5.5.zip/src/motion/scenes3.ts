/* ------------------------------------------------------------------
   scenes3.ts — صحنه‌های منتخبِ ۵ دقیقه‌ای (جلسهٔ سوم • بخشِ سوم)
   «شکرگزاری، فرکانسِ خدا و سیستمِ جهان» — استاد حاج نصرالله باستین
   منطقهٔ امنِ بصری روی ۱۲۸۰×۷۲۰: y از ۹۰ تا ۵۹۰
------------------------------------------------------------------ */
import {
  AR,
  VZ,
  clamp01,
  drawArcProgress,
  drawAudioAuraRing,
  drawFlowPulse,
  drawGlowingText,
  drawGrowingPath,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawRoundedRect,
  drawSacredMandala,
  drawStar8,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  span,
  toFaDigits,
  withAlpha,
} from './primitives';
import {
  drawBoat,
  drawCounter,
  drawFigure,
  drawFootprint,
  drawHeart,
  drawLeaf,
  drawPopText,
  drawRadioWaves,
  drawStaggerWords,
  drawWaterWaves,
  drawWaveform,
  drawWipeText,
} from './fx';
import type { SceneFn } from './scenes1';

/* ═════════════════ ابزارهای مشترک ═════════════════ */

function title(ctx: CanvasRenderingContext2D, text: string, t: number, a: string, y = 108) {
  drawWipeText(ctx, text, 640, y, `800 38px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.5) / 1.6);
}

/** متنِ کلیدیِ بزرگ که در لحظهٔ اوجِ جمله ظاهر و محو می‌شود */
function quoteBeat(
  ctx: CanvasRenderingContext2D,
  text: string,
  t: number,
  from: number,
  to: number,
  y: number,
  color: string,
  size = 26,
) {
  if (t < from || t > to + 0.8) return;
  const out = 1 - span(t, to, to + 0.8);
  ctx.save();
  ctx.globalAlpha *= out;
  drawStaggerWords(ctx, text, 640, y, `800 ${size}px ${VZ}`, '#fff7ed', withAlpha(color, 0.75), t, from, 0.11, 12);
  ctx.restore();
}

function rainDrops(
  ctx: CanvasRenderingContext2D,
  g: number,
  x0: number,
  x1: number,
  yTop: number,
  yBottom: number,
  color: string,
  count: number,
  alpha: number,
) {
  if (alpha <= 0.01) return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = withAlpha(color, 0.7);
  ctx.lineWidth = 1.6;
  ctx.lineCap = 'round';
  const H = yBottom - yTop;
  for (let i = 0; i < count; i++) {
    const x = x0 + seeded(i * 7.1) * (x1 - x0);
    const sp = 260 + seeded(i * 3.3) * 220;
    const y = yTop + ((seeded(i * 1.9) * H + g * sp) % H);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - 3, y + 14);
    ctx.stroke();
  }
  ctx.restore();
}

function cloud(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string, alpha: number) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.translate(x, y);
  ctx.scale(s, s);
  const gr = ctx.createLinearGradient(0, -40, 0, 30);
  gr.addColorStop(0, 'rgba(226,232,240,0.30)');
  gr.addColorStop(1, withAlpha(color, 0.14));
  ctx.fillStyle = gr;
  ctx.beginPath();
  ctx.arc(-46, 6, 30, 0, Math.PI * 2);
  ctx.arc(-6, -12, 42, 0, Math.PI * 2);
  ctx.arc(42, 2, 32, 0, Math.PI * 2);
  ctx.arc(10, 18, 30, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = withAlpha(color, 0.35);
  ctx.lineWidth = 1.4;
  ctx.stroke();
  ctx.restore();
}

/* ══════════ ۱ — نزدیک‌ترین فرکانس به خدا: شکرگزاری ══════════ */
export const sceneGratitudeFrequency: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'نزدیک‌ترین فرکانس به خدا', t, a);

  // دیالِ رادیوییِ بزرگ — عقربه از «ناسپاسی» به «شکرگزاری» می‌چرخد
  const cx = 640;
  const cy = 360;
  const R = 150;
  const tune = easeInOutCubic(span(t, 3, d * 0.55));
  const p = easeOutBack(span(t, 0.8, 2.2));
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(p, p);

  // نوارِ طیفِ فرکانس
  const arcStart = Math.PI * 1.08;
  const arcSweep = Math.PI * 0.84;
  for (let i = 0; i <= 60; i++) {
    const k = i / 60;
    const ang = arcStart + arcSweep * k;
    const long = i % 10 === 0;
    ctx.strokeStyle = withAlpha(k < 0.5 ? '#fb7185' : a, long ? 0.9 : 0.4);
    ctx.lineWidth = long ? 3 : 1.4;
    ctx.beginPath();
    ctx.moveTo(Math.cos(ang) * (R - (long ? 22 : 12)), Math.sin(ang) * (R - (long ? 22 : 12)));
    ctx.lineTo(Math.cos(ang) * R, Math.sin(ang) * R);
    ctx.stroke();
  }
  const labels: Array<[number, string, string]> = [
    [0.04, 'کفر و ناسپاسی', '#fecaca'],
    [0.5, 'غفلت', '#cbd5e1'],
    [0.96, 'شکرگزاری', '#fde68a'],
  ];
  labels.forEach(([k, txt, col]) => {
    const ang = arcStart + arcSweep * k;
    ctx.font = `700 16px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = col;
    ctx.fillText(txt, Math.cos(ang) * (R + 40), Math.sin(ang) * (R + 30));
  });

  // عقربه
  const jitter = (1 - tune) * Math.sin(g * 11) * 0.05;
  const needle = arcStart + arcSweep * lerp(0.06, 0.96, tune) + jitter;
  ctx.strokeStyle = '#fff7ed';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.shadowColor = tune > 0.8 ? a : '#fb7185';
  ctx.shadowBlur = 18;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(Math.cos(needle) * (R - 8), Math.sin(needle) * (R - 8));
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, 9, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // موجِ سیگنال: نویزیِ قرمز ← سینوسیِ طلاییِ خالص
  const noisy = 1 - tune;
  ctx.save();
  ctx.strokeStyle = withAlpha(tune > 0.6 ? a : '#fb7185', 0.85);
  ctx.lineWidth = 2.6;
  ctx.shadowColor = tune > 0.6 ? a : '#fb7185';
  ctx.shadowBlur = 12;
  ctx.beginPath();
  for (let x = 0; x <= 760; x += 4) {
    const k = x / 760;
    const env = Math.sin(k * Math.PI);
    const pure = Math.sin(k * 28 + g * 4) * 22 * (0.5 + e);
    const noise = (seeded(Math.floor(x / 4) + Math.floor(g * 24) * 97) - 0.5) * 70;
    const y = 470 + env * (pure * tune + noise * noisy);
    if (x === 0) ctx.moveTo(260 + x, y);
    else ctx.lineTo(260 + x, y);
  }
  ctx.stroke();
  ctx.restore();

  drawCounter(
    ctx,
    `${toFaDigits(Math.round(lerp(12, 100, tune)))}٪ هم‌فرکانس`,
    640,
    410,
    `800 22px ${VZ}`,
    tune > 0.8 ? '#fde68a' : '#fecaca',
    withAlpha(tune > 0.8 ? a : '#fb7185', 0.6),
    span(t, 2.2, 3),
  );

  // سه شکرِ روزانه — یکی‌یکی روی مدار می‌نشینند
  const thanks = ['شکر بابتِ زنده بودن', 'شکر بابتِ همسر و فرزندان', 'شکر بابتِ پدر و مادر'];
  thanks.forEach((txt, i) => {
    const at = d * 0.36 + i * 2.6;
    const side = i === 1 ? 0 : i === 0 ? 1 : -1;
    drawKineticPill(ctx, 640 + side * 380, 214 + (i === 1 ? -40 : 0) + 30, txt, (t - at) / 1, i % 2 ? b : a, '✦', 0.9, 16);
  });

  if (tune > 0.9) {
    drawAudioAuraRing(ctx, cx, cy, 64, g, (tune - 0.9) * 10 * (0.4 + e), a);
    drawStar8(ctx, cx, cy, 20 + e * 12, '#fde68a', g * 0.8, true, (tune - 0.9) * 10);
  }

  drawVerseCard(ctx, 640, 548, 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', 'ستایش و سپاس، مخصوصِ خدای جهانیان است', 'سورهٔ حمد • آیهٔ ۲', (t - d * 0.7) / 1.4, a, 720);
};

/* ══════════ ۲ — لَئِن شَکَرتُم لَأَزیدَنَّکُم: تشت ← اقیانوس ══════════ */
export const sceneVesselOcean: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'ظرفِ وجودت را بزرگ کن', t, a);

  // باران همیشه هست — یکسان، بی‌کم‌وکاست
  cloud(ctx, 360, 168, 1, b, easeOutCubic(span(t, 0.6, 2)));
  cloud(ctx, 640, 150, 1.25, b, easeOutCubic(span(t, 0.9, 2.3)));
  cloud(ctx, 920, 168, 1, b, easeOutCubic(span(t, 1.2, 2.6)));
  rainDrops(ctx, g, 260, 1020, 190, 470, '#bae6fd', 90, easeOutCubic(span(t, 1.6, 3)));

  // چهار مرحلهٔ ظرف
  const stages = [
    { name: 'تشت', w: 120, h: 46 },
    { name: 'حوض', w: 300, h: 60 },
    { name: 'استخر', w: 560, h: 74 },
    { name: 'دریا', w: 860, h: 88 },
    { name: 'اقیانوس', w: 1180, h: 104 },
  ];
  const grow = clamp01((t - 4) / (d * 0.62));
  const fi = grow * (stages.length - 1);
  const i0 = Math.floor(fi);
  const i1 = Math.min(stages.length - 1, i0 + 1);
  const k = easeInOutCubic(fi - i0);
  const w = lerp(stages[i0].w, stages[i1].w, k);
  const h = lerp(stages[i0].h, stages[i1].h, k);
  const baseY = 480;

  ctx.save();
  // دیواره
  ctx.strokeStyle = withAlpha(a, 0.85);
  ctx.lineWidth = 3;
  ctx.shadowColor = a;
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.moveTo(640 - w / 2 - 10, baseY - h);
  ctx.quadraticCurveTo(640 - w / 2, baseY, 640, baseY + 6);
  ctx.quadraticCurveTo(640 + w / 2, baseY, 640 + w / 2 + 10, baseY - h);
  ctx.stroke();
  ctx.shadowBlur = 0;
  // آب
  ctx.beginPath();
  const level = baseY - h * 0.78;
  ctx.moveTo(640 - w / 2 - 4, level);
  for (let x = -w / 2; x <= w / 2; x += 6) {
    ctx.lineTo(640 + x, level + Math.sin(x * 0.05 + g * 3) * (2 + e * 4));
  }
  ctx.quadraticCurveTo(640 + w / 2, baseY, 640, baseY + 4);
  ctx.quadraticCurveTo(640 - w / 2, baseY, 640 - w / 2 - 4, level);
  ctx.closePath();
  const wg = ctx.createLinearGradient(0, level, 0, baseY);
  wg.addColorStop(0, withAlpha(b, 0.6));
  wg.addColorStop(1, withAlpha(b, 0.15));
  ctx.fillStyle = wg;
  ctx.fill();
  ctx.restore();

  // برچسبِ مرحله با پرشِ اندازه
  const label = stages[k > 0.5 ? i1 : i0].name;
  const pulse = 1 + Math.sin(k * Math.PI) * 0.25;
  ctx.save();
  ctx.translate(640, baseY + 46);
  ctx.scale(pulse, pulse);
  drawGlowingText(ctx, label, 0, 0, `900 30px ${VZ}`, '#e0f2fe', withAlpha(b, 0.7), 18);
  ctx.restore();

  // مسیرِ مراحل
  stages.forEach((s, i) => {
    const x = 640 + (2 - i) * 120;
    const on = fi >= i - 0.01;
    ctx.fillStyle = on ? b : 'rgba(148,163,184,0.25)';
    ctx.beginPath();
    ctx.arc(x, 574, on ? 6 : 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.font = `600 13px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.fillStyle = on ? '#e0f2fe' : 'rgba(148,163,184,0.6)';
    ctx.fillText(s.name, x, 596);
  });

  drawKineticPill(ctx, 230, 260, 'نعمت مثلِ باران همیشه هست', (t - 3) / 1.1, b, '☂', 0.86, 15);
  drawKineticPill(ctx, 1050, 260, 'ظرفیتِ ما زیاد می‌شود', (t - d * 0.3) / 1.1, a, '✦', 0.86, 15);

  drawVerseCard(ctx, 640, 330, 'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', 'اگر شکر کنید، ظرفیتِ شما را می‌افزاییم', 'سورهٔ ابراهیم • آیهٔ ۷', (t - d * 0.8) / 1.3, a, 640);
};

/* ══════════ ۳ — حسِ خوب پیش از هر کار ══════════ */
export const sceneGoodFeeling: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'اول به حسِ خوب برس', t, a);

  // دو ستونِ علت و معلول
  const split = easeOutCubic(span(t, 1, 2.6));
  const shift = easeInOutCubic(span(t, d * 0.35, d * 0.6));

  // ترازوی احساس
  const cx = 640;
  const cy = 300;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.globalAlpha *= split;
  ctx.rotate(lerp(0.22, -0.22, shift) + Math.sin(g * 1.4) * 0.015);
  ctx.strokeStyle = 'rgba(226,232,240,0.8)';
  ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(-260, 0);
  ctx.lineTo(260, 0);
  ctx.stroke();
  // کفه‌ها
  for (const s of [-1, 1]) {
    ctx.save();
    ctx.translate(s * 260, 0);
    ctx.rotate(-(lerp(0.22, -0.22, shift)));
    ctx.strokeStyle = withAlpha(s < 0 ? a : '#fb7185', 0.8);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-44, 70);
    ctx.moveTo(0, 0);
    ctx.lineTo(44, 70);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(0, 72, 56, 12, 0, 0, Math.PI);
    ctx.fillStyle = withAlpha(s < 0 ? a : '#fb7185', 0.3);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx - 18, cy + 60);
  ctx.lineTo(cx + 18, cy + 60);
  ctx.closePath();
  ctx.globalAlpha = split;
  ctx.fill();
  ctx.globalAlpha = 1;

  const tiltY = (s: number) => cy + s * Math.sin(lerp(0.22, -0.22, shift)) * 260 + 60;
  drawHeart(ctx, cx - 260, tiltY(-1), 24, a, 0.5 + 0.5 * Math.sin(g * 4) * (0.4 + e), split);
  drawGlowingText(ctx, 'احساسِ خوب', cx - 260, tiltY(-1) + 56, `800 18px ${VZ}`, '#fde68a', withAlpha(a, 0.5), 10);
  ctx.save();
  ctx.globalAlpha = split * lerp(1, 0.4, shift);
  drawHeart(ctx, cx + 260, tiltY(1), 20, '#64748b', 0.1, 1);
  ctx.restore();
  drawGlowingText(ctx, 'حُزن • احساسِ بد', cx + 260, tiltY(1) + 56, `700 17px ${VZ}`, '#fecaca', 'rgba(0,0,0,0)', 0);

  // فلش‌های علت ← معلول
  const arrowP = span(t, d * 0.55, d * 0.7);
  if (arrowP > 0) {
    drawKineticPill(ctx, 380, 470, 'احساسِ خوب ← اتفاقِ خوب', arrowP, a, '↑', 0.95, 17);
    drawKineticPill(ctx, 900, 470, 'احساسِ بد ← اتفاقِ بد', (t - d * 0.6) / 1, '#fb7185', '↓', 0.95, 17);
  }

  // لباس و ساعت: «قبل از سرِ کار رفتن»
  const clockP = easeOutBack(span(t, 3, 4.4));
  ctx.save();
  ctx.translate(1110, 190);
  ctx.scale(clockP, clockP);
  drawArcProgress(ctx, 0, 0, 38, (g * 0.08) % 1, b, 5, -Math.PI / 2, Math.PI * 2);
  ctx.strokeStyle = '#e0f2fe';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(Math.cos(g * 0.5) * 22, Math.sin(g * 0.5) * 22);
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -28);
  ctx.stroke();
  ctx.restore();
  drawGlowingText(ctx, 'پیش از رفتن به سرِ کار', 1110, 254, `600 14px ${VZ}`, '#bae6fd', 'rgba(0,0,0,0)', 0);

  quoteBeat(ctx, 'با شکرگزاری، حس را تغییر بده', t, d * 0.78, d - 0.6, 548, a, 28);
};

/* ══════════ ۴ — مادرِ موسی: فَأَلقیهِ فِی الیَمّ ══════════ */
export const sceneMosesMother: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'نترس، غمگین مباش', t, a, 104);

  // رودِ نیل — امواجِ پهن
  drawWaterWaves(ctx, 382, 1280, g * 0.9, b, a, 4, 13);

  // ماه و نورِ هدایت از بالا
  const moonP = easeOutCubic(span(t, 1, 3));
  const mg = ctx.createRadialGradient(1040, 170, 4, 1040, 170, 180);
  mg.addColorStop(0, withAlpha('#fef3c7', 0.5 * moonP));
  mg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = mg;
  ctx.beginPath();
  ctx.arc(1040, 170, 180, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = withAlpha('#fef3c7', 0.92 * moonP);
  ctx.beginPath();
  ctx.arc(1040, 170, 30, 0, Math.PI * 2);
  ctx.fill();

  // مادر در ساحلِ راست
  const release = easeInOutCubic(span(t, 4, 9));
  ctx.save();
  ctx.globalAlpha *= easeOutCubic(span(t, 1.2, 2.6));
  const mx = 1110;
  const my = 372;
  ctx.fillStyle = withAlpha('#e2e8f0', 0.9);
  ctx.strokeStyle = withAlpha('#e2e8f0', 0.9);
  ctx.shadowColor = withAlpha(a, 0.6);
  ctx.shadowBlur = 16;
  // ردا
  ctx.beginPath();
  ctx.moveTo(mx, my - 92);
  ctx.quadraticCurveTo(mx - 34, my - 50, mx - 28, my);
  ctx.lineTo(mx + 28, my);
  ctx.quadraticCurveTo(mx + 30, my - 50, mx, my - 92);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(mx, my - 100, 13, 0, Math.PI * 2);
  ctx.fill();
  // بازوها رو به رود
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(mx - 8, my - 70);
  ctx.lineTo(mx - 40 - release * 10, my - 50 + release * 10);
  ctx.stroke();
  ctx.restore();

  // سبدِ کودک: از دستِ مادر به امواج، سپس با جریان به سمتِ چپ
  const drift = easeInOutCubic(span(t, 9, d * 0.82));
  const bx = lerp(lerp(1062, 980, release), 250, drift);
  const by = lerp(330, 372, release) + Math.sin(g * 1.8) * 6 * release;
  ctx.save();
  ctx.translate(bx, by);
  ctx.rotate(Math.sin(g * 1.4) * 0.08 * release);
  const halo = ctx.createRadialGradient(0, 0, 4, 0, 0, 90);
  halo.addColorStop(0, withAlpha('#fde68a', 0.45 + e * 0.2));
  halo.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(0, 0, 90, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#b45309';
  ctx.strokeStyle = '#fde68a';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, 0, 38, 14, 0, 0, Math.PI);
  ctx.fill();
  ctx.stroke();
  for (let i = -3; i <= 3; i++) {
    ctx.strokeStyle = 'rgba(253,230,138,0.45)';
    ctx.beginPath();
    ctx.moveTo(i * 10, 0);
    ctx.lineTo(i * 8, 12);
    ctx.stroke();
  }
  ctx.fillStyle = '#fef3c7';
  ctx.beginPath();
  ctx.arc(-14, -6, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(226,232,240,0.85)';
  ctx.beginPath();
  ctx.ellipse(8, -4, 22, 8, 0, Math.PI, 0);
  ctx.fill();
  ctx.restore();

  // ردِ نور پشتِ سبد
  if (drift > 0.02) {
    drawGrowingPath(
      ctx,
      [
        [980, 380],
        [bx + 30, 380],
      ],
      1,
      withAlpha('#fde68a', 0.35),
      3,
      [8, 10],
    );
  }

  // دو ترس که خاموش می‌شوند
  const fearOff = easeOutCubic(span(t, d * 0.42, d * 0.55));
  ['ترس', 'غم'].forEach((w, i) => {
    const p = span(t, 5 + i * 0.8, 6 + i * 0.8);
    if (p <= 0) return;
    ctx.save();
    ctx.globalAlpha = clamp01(p * 1.5) * (1 - fearOff);
    drawKineticPill(ctx, 820 - i * 150, 210, w, p, '#fb7185', '✕', 0.9 * (1 - fearOff * 0.4), 17);
    ctx.restore();
  });
  drawKineticPill(ctx, 760, 210, 'توکل • بالاترین درجهٔ ایمان', (t - d * 0.52) / 1.2, a, '✦', 1, 18);

  // بازگشتِ کودک به آغوشِ مادر — قوسِ نورِ برگشت
  const back = easeOutQuint(span(t, d * 0.8, d * 0.93));
  if (back > 0.02) {
    ctx.save();
    ctx.strokeStyle = withAlpha('#fde68a', 0.7);
    ctx.lineWidth = 3;
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 16;
    ctx.beginPath();
    const steps = 40;
    for (let i = 0; i <= steps * back; i++) {
      const k = i / steps;
      const x = lerp(250, 1100, k);
      const y = 330 - Math.sin(k * Math.PI) * 170;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
    drawPopText(ctx, 'و خدا کودک را به او بازگرداند', 680, 186, `700 20px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - d * 0.86) / 1);
  }

  drawVerseCard(ctx, 640, 524, 'فَأَلْقِيهِ فِي الْيَمِّ وَلَا تَخَافِي وَلَا تَحْزَنِي', 'او را به دریا بسپار؛ نترس و غمگین مباش', 'سورهٔ قصص • آیهٔ ۷', (t - 6) / 1.4, a, 780);
};

/* ══════════ ۵ — فانوسِ دریایی: هم‌جهتیِ ذهن ══════════ */
export const sceneLighthouse: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'ذهن، هم‌جهت مثلِ فانوس', t, a, 104);
  drawWaterWaves(ctx, 420, 1280, g, b, a, 3, 10);

  // ساحلِ چپ و فانوس
  const lhx = 210;
  const lhy = 420;
  ctx.save();
  ctx.fillStyle = 'rgba(15,23,42,0.95)';
  ctx.beginPath();
  ctx.moveTo(0, 430);
  ctx.quadraticCurveTo(160, 380, 330, 430);
  ctx.lineTo(330, 720);
  ctx.lineTo(0, 720);
  ctx.fill();
  // بدنهٔ راه‌راه
  for (let i = 0; i < 5; i++) {
    const y0 = lhy - 40 - i * 40;
    const w0 = 46 - i * 4;
    ctx.fillStyle = i % 2 ? '#e2e8f0' : '#ef4444';
    ctx.beginPath();
    ctx.moveTo(lhx - w0 / 2, y0 + 40);
    ctx.lineTo(lhx - (w0 - 4) / 2, y0);
    ctx.lineTo(lhx + (w0 - 4) / 2, y0);
    ctx.lineTo(lhx + w0 / 2, y0 + 40);
    ctx.closePath();
    ctx.fill();
  }
  ctx.fillStyle = '#fde68a';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 30;
  ctx.fillRect(lhx - 16, lhy - 254, 32, 34);
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.moveTo(lhx - 24, lhy - 254);
  ctx.lineTo(lhx, lhy - 284);
  ctx.lineTo(lhx + 24, lhy - 254);
  ctx.fill();
  ctx.restore();

  // پرتوی گردان
  const align = easeInOutCubic(span(t, d * 0.3, d * 0.6));
  const sweep = lerp(Math.sin(g * 0.9) * 0.9, 0.0, align) + 0.12;
  const beamLen = 1100;
  ctx.save();
  ctx.translate(lhx, lhy - 237);
  ctx.rotate(sweep);
  const bg = ctx.createLinearGradient(0, 0, beamLen, 0);
  bg.addColorStop(0, withAlpha('#fde68a', 0.55 + e * 0.15));
  bg.addColorStop(1, 'rgba(253,230,138,0)');
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(beamLen, -lerp(110, 46, align));
  ctx.lineTo(beamLen, lerp(110, 46, align));
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // ردیفِ چراغ‌های راهنما روی آب — پراکنده ← در یک خط
  for (let i = 0; i < 7; i++) {
    const k = i / 6;
    const tx = lerp(1150, 380, k);
    const scatterY = 300 + (seeded(i * 4.7) - 0.5) * 220;
    const lineY = lhy - 237 + Math.tan(0.12) * (tx - lhx) + 30;
    const y = lerp(scatterY, lineY, align) + Math.sin(g * 2 + i) * 3;
    const lp = easeOutBack(span(t, 2 + i * 0.4, 3 + i * 0.4));
    ctx.save();
    ctx.globalAlpha *= lp;
    ctx.fillStyle = align > 0.6 ? '#fde68a' : '#fb7185';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(tx, y, 6 + e * 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // کشتی که با هم‌جهت شدن به ساحل می‌رسد
  const sail = easeInOutCubic(span(t, d * 0.45, d * 0.92));
  const lostWob = (1 - align) * Math.sin(g * 1.7) * 70;
  const sx = lerp(1120, 380, sail);
  const sy = 410 + lostWob * 0.5;
  drawBoat(ctx, sx, sy, 1.05, (1 - align) * Math.sin(g * 1.9) * 0.2, align > 0.5 ? a : '#fb7185', g * 2, align > 0.7, 0.3 * (1 - align));

  drawKineticPill(ctx, 900, 186, 'ذهنِ پراکنده • در اختلاف', (t - 2.5) / 1.1, '#fb7185', '✕', 0.9, 16);
  if (align > 0.5) drawKineticPill(ctx, 820, 186, 'ذهنِ مهارشده = تقوا', (t - d * 0.55) / 1.1, a, '✦', 1, 18);

  quoteBeat(ctx, 'ذهن و روح که هم‌جهت شوند، هدف نزدیک می‌شود', t, d * 0.7, d - 0.5, 560, a, 26);
};

/* ══════════ ۶ — دستگاهِ بی‌سیم: ارسالِ فرکانس و صبر ══════════ */
export const sceneWirelessPatience: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'ما فرکانس می‌فرستیم', t, a, 104);

  // فرستنده (انسان) در راست، جهان (مدار) در چپ
  const hx = 1020;
  const hy = 380;
  drawFigure(ctx, hx, hy + 60, 110, '#fde68a', 0, true);
  // آنتنِ دست
  ctx.save();
  ctx.strokeStyle = '#fde68a';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(hx + 18, hy + 20);
  ctx.lineTo(hx + 30, hy - 40);
  ctx.stroke();
  ctx.restore();
  drawRadioWaves(ctx, hx + 30, hy - 40, g, a, 4, 140, 0.6, easeOutCubic(span(t, 2, 3)));

  // جهان: هستهٔ پردازش با مدارهای ابر، باد، خورشید، فلک
  const ux = 380;
  const uy = 330;
  const up = easeOutBack(span(t, 1, 2.6));
  drawSacredMandala(ctx, ux, uy, 120 * up, g * 0.2, b, 0.3);
  drawAudioAuraRing(ctx, ux, uy, 54 * up, g, 0.3 + e, b);
  drawGlowingText(ctx, 'جهانِ هستی', ux, uy, `800 19px ${VZ}`, '#e0f2fe', withAlpha(b, 0.7), 14);
  const agents = ['ابر', 'باد', 'خورشید', 'فلک'];
  agents.forEach((ag, i) => {
    const ang = g * 0.35 + (i / 4) * Math.PI * 2;
    const p = span(t, 3 + i * 0.5, 4 + i * 0.5);
    drawNodeBadge(ctx, ux + Math.cos(ang) * 150 * up, uy + Math.sin(ang) * 110 * up, ag, p, i % 2 ? a : b, 18);
  });
  drawOrbitRing(ctx, ux, uy, 150 * up, g * 0.35, b, 0.25, false);

  // ۱) ارسال ← ۲) پردازش ← ۳) بازگشت
  const send = span(t, 5, 7);
  if (send > 0) drawFlowPulse(ctx, hx - 10, hy - 50, ux + 70, uy - 30, g, a, 5, 0.5);
  const ret = span(t, d * 0.5, d * 0.5 + 2);
  if (ret > 0) drawFlowPulse(ctx, ux + 70, uy + 40, hx - 20, hy + 20, g, '#86efac', 5, 0.4);

  drawKineticPill(ctx, 700, 196, '۱ • ارسالِ فرکانس', (t - 5) / 1, a, '↗', 0.88, 15);
  drawKineticPill(ctx, 380, 492, '۲ • پردازش', (t - 8) / 1, b, '⟳', 0.88, 15);
  drawKineticPill(ctx, 760, 470, '۳ • بازگشتِ پاسخ', (t - d * 0.5) / 1, '#86efac', '↙', 0.88, 15);

  // نوارِ زمانیِ صبر: فاصلهٔ ارسال تا رسیدن
  const patP = easeOutCubic(span(t, d * 0.62, d * 0.68));
  if (patP > 0) {
    const x0 = 300;
    const x1 = 980;
    const y = 562;
    const fill = easeInOutCubic(span(t, d * 0.66, d * 0.95));
    ctx.save();
    ctx.globalAlpha *= patP;
    drawRoundedRect(ctx, x0, y - 7, x1 - x0, 14, 7);
    ctx.fillStyle = 'rgba(148,163,184,0.16)';
    ctx.fill();
    const fg = ctx.createLinearGradient(x1, 0, x0, 0);
    fg.addColorStop(0, a);
    fg.addColorStop(1, '#86efac');
    ctx.fillStyle = fg;
    drawRoundedRect(ctx, x1 - (x1 - x0) * fill, y - 7, (x1 - x0) * fill, 14, 7);
    ctx.fill();
    ctx.font = `700 15px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fde68a';
    ctx.fillText('ارسال', x1, y - 22);
    ctx.fillStyle = '#bbf7d0';
    ctx.fillText('رسیدن به هدف', x0, y - 22);
    ctx.restore();
    drawPopText(ctx, 'صبر = زمانِ میانِ ارسال و رسیدن', 640, 530, `800 22px ${VZ}`, '#fff7ed', withAlpha(a, 0.6), (t - d * 0.68) / 1);
    // آنچه در صبر نیست
    ['عجله', 'طمع', 'حسد', 'ترس'].forEach((w, i) => {
      const p = span(t, d * 0.75 + i * 0.5, d * 0.75 + i * 0.5 + 0.8);
      if (p <= 0) return;
      ctx.save();
      ctx.globalAlpha = (1 - p * 0.6) * patP;
      drawGlowingText(ctx, w, 420 + i * 150, 612, `700 15px ${VZ}`, '#fecaca', 'rgba(0,0,0,0)', 0);
      ctx.strokeStyle = withAlpha('#fde68a', p);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(420 + i * 150 - 26, 612);
      ctx.lineTo(420 + i * 150 - 26 + 52 * p, 612);
      ctx.stroke();
      ctx.restore();
    });
  }

  drawVerseCard(ctx, 640, 300, 'كُلَّ يَوْمٍ هُوَ فِي شَأْنٍ', 'او هر روز و هر لحظه در کاری است', 'سورهٔ رحمن • آیهٔ ۲۹', (t - 10) / 1.2, b, 460);
  if (t > d * 0.48) {
    ctx.save();
    ctx.globalAlpha = 1 - span(t, d * 0.48, d * 0.5);
    drawVerseCard(ctx, 640, 300, 'كُلَّ يَوْمٍ هُوَ فِي شَأْنٍ', '', '', 1, b, 1);
    ctx.restore();
  }
};

/* ══════════ ۷ — یک قدم تو، ده قدم جهان ══════════ */
export const sceneTenSteps: SceneFn = (ctx, t, d, g, _e, a, b) => {
  title(ctx, 'یک قدم تو، ده قدم جهان', t, a, 104);

  const y = 330;
  // یک قدمِ انسان (راست)
  const myStep = easeOutBack(span(t, 2, 3.2));
  drawFigure(ctx, 1080 - myStep * 70, y + 60, 100, '#fde68a', myStep * 3, true);
  drawFootprint(ctx, 1080, y + 70, -Math.PI / 2, 1.2, '#fde68a', myStep);
  drawCounter(ctx, '۱', 1040, y - 80, `900 52px ${VZ}`, '#fde68a', withAlpha(a, 0.7), span(t, 2.4, 3.2));

  // ده قدمِ جهان (از چپ به سوی او)
  for (let i = 0; i < 10; i++) {
    const p = easeOutCubic(span(t, 4 + i * 0.32, 4.6 + i * 0.32));
    if (p <= 0) continue;
    const x = 150 + i * 78;
    drawFootprint(ctx, x, y + 70 + (i % 2 ? -14 : 14), Math.PI / 2, 1.05, i % 2 ? b : a, p * 0.95);
    if (p > 0.6) {
      ctx.save();
      ctx.globalAlpha = (p - 0.6) / 0.4;
      drawGlowingText(ctx, toFaDigits(i + 1), x, y + 22, `800 16px ${VZ}`, withAlpha(i % 2 ? b : a, 1), 'rgba(0,0,0,0)', 0);
      ctx.restore();
    }
  }
  drawCounter(ctx, '۱۰', 420, y - 80, `900 52px ${VZ}`, '#e0f2fe', withAlpha(b, 0.7), span(t, 7.2, 8));

  // سیستم: ورودی ← پردازش ← خروجی
  const sysP = easeOutCubic(span(t, d * 0.45, d * 0.55));
  if (sysP > 0) {
    const boxes: Array<[string, string, string]> = [
      ['ورودی', 'باور و فرکانس', a],
      ['پردازش', 'سیستمِ قانونمندِ جهان', b],
      ['خروجی', 'اتفاق', '#86efac'],
    ];
    boxes.forEach(([h1, h2, col], i) => {
      const p = span(t, d * 0.45 + i * 1.2, d * 0.45 + i * 1.2 + 1);
      if (p <= 0) return;
      const bx = 900 - i * 260;
      const by = 520;
      ctx.save();
      ctx.globalAlpha *= easeOutCubic(p);
      ctx.translate(bx, by + (1 - easeOutBack(p)) * 26);
      drawRoundedRect(ctx, -100, -42, 200, 84, 18);
      ctx.fillStyle = 'rgba(9,15,34,0.94)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(col, 0.7);
      ctx.lineWidth = 1.8;
      ctx.stroke();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `800 21px ${VZ}`;
      ctx.fillStyle = col;
      ctx.fillText(h1, 0, -12);
      ctx.font = `500 13px ${VZ}`;
      ctx.fillStyle = 'rgba(203,213,225,0.85)';
      ctx.fillText(h2, 0, 16);
      ctx.restore();
      if (i < 2 && p > 0.6) drawFlowPulse(ctx, bx - 104, by, bx - 156, by, g, col, 3, 0.8);
    });
  }

  quoteBeat(ctx, 'این قانون در کلِ عالم صادق است', t, d * 0.8, d - 0.4, 200, b, 24);
};

/* ══════════ ۸ — ذهن مثلِ درخت • خدا ظالم نیست (فینال) ══════════ */
export const sceneMindTree: SceneFn = (ctx, t, d, g, e, a, b) => {
  title(ctx, 'ذهنت مثلِ یک درخت است', t, a, 104);

  const gx = 640;
  const gy = 520;
  // خاک
  const soilP = easeOutCubic(span(t, 1, 2.4));
  ctx.save();
  ctx.globalAlpha *= soilP;
  const sg = ctx.createLinearGradient(0, gy, 0, gy + 60);
  sg.addColorStop(0, 'rgba(120,53,15,0.85)');
  sg.addColorStop(1, 'rgba(41,20,5,0)');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.ellipse(gx, gy + 10, 320 * soilP, 34, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // تنه و شاخه‌ها (بازگشتی)
  const growth = easeInOutCubic(span(t, 2.4, 14));
  const sway = Math.sin(g * 0.9) * 0.03;
  const leaves: Array<[number, number]> = [];
  const branch = (x: number, y: number, len: number, ang: number, depth: number, gp: number) => {
    if (depth === 0 || gp <= 0) return;
    const L = len * clamp01(gp);
    const x2 = x + Math.cos(ang) * L;
    const y2 = y + Math.sin(ang) * L;
    ctx.strokeStyle = depth > 3 ? '#a16207' : withAlpha('#ca8a04', 0.9);
    ctx.lineWidth = depth * 2.6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    if (depth <= 2 && gp >= 1) leaves.push([x2, y2]);
    const next = (gp - 1) * 1.6 + 0.6;
    branch(x2, y2, len * 0.72, ang - 0.46 + sway, depth - 1, gp >= 1 ? next : 0);
    branch(x2, y2, len * 0.72, ang + 0.42 + sway, depth - 1, gp >= 1 ? next : 0);
  };
  branch(gx, gy, 120, -Math.PI / 2 + sway, 6, growth * 4.2);

  // برگ‌ها و میوه
  const fruitP = span(t, 15.5, 19.5);
  leaves.forEach(([lx, ly], i) => {
    drawLeaf(ctx, lx, ly, 9, g * 0.6 + i, i % 3 === 0 ? b : a, 0.85);
    if (i % 4 === 0 && fruitP > 0) {
      const fp = easeOutBack(clamp01(fruitP * 2 - (i % 8) * 0.05));
      ctx.save();
      ctx.fillStyle = '#f97316';
      ctx.shadowColor = '#fde68a';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.arc(lx + 4, ly + 10, 6 * fp, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  });

  // آب، نور، مراقبت — ورودی‌های درخت
  const inputs: Array<[string, number, number, string]> = [
    ['نور', 1060, 200, '#fde68a'],
    ['آب', 220, 260, '#7dd3fc'],
    ['مراقبت', 1080, 420, '#86efac'],
    ['خاکِ خوب', 200, 470, '#d97706'],
  ];
  inputs.forEach(([txt, x, y, col], i) => {
    const p = span(t, 2.5 + i * 0.9, 3.5 + i * 0.9);
    drawNodeBadge(ctx, x, y, txt, p, col, 20);
    if (p >= 1 && growth < 1) drawFlowPulse(ctx, x, y, gx, gy - 120, g + i, col, 3, 0.5);
  });

  // جمع‌بندی: آنچه فرستادیم برمی‌گردد
  const finale = easeOutCubic(span(t, 21.2, 22.8));
  if (finale > 0) {
    ctx.save();
    ctx.globalAlpha = finale * 0.88;
    ctx.fillStyle = 'rgba(4,7,18,0.8)';
    ctx.fillRect(0, 150, 1280, 420);
    ctx.restore();
    drawSacredMandala(ctx, 640, 340, 200 * finale, g * 0.12, a, 0.2 * finale);
    drawStar8(ctx, 640, 340, 24 + e * 14, '#fde68a', g * 0.6, true, finale);
    ctx.save();
    ctx.globalAlpha = finale;
    drawStaggerWords(ctx, 'خداوند ظالم نیست', 640, 252, `900 44px ${VZ}`, '#fde68a', withAlpha(a, 0.8), t, 21.6, 0.16, 16);
    drawStaggerWords(ctx, 'آنچه فرستادیم، جهان به خودمان بازمی‌گرداند', 640, 430, `700 24px ${VZ}`, '#e0f2fe', withAlpha(b, 0.6), t, 29.8, 0.1, 12);
    drawPopText(ctx, 'قانونِ کنش و واکنش', 640, 478, `600 18px ${VZ}`, '#bbf7d0', 'rgba(52,211,153,0.5)', (t - 33) / 1);
    ctx.restore();
  }
  void d;

  void AR;
  void drawWaveform;
  void easeOutQuint;
};
