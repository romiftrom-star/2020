/* ------------------------------------------------------------------
   recorder.ts — ضبطِ زندهٔ تایم‌لاین به فایلِ ویدیویی
   MP4 (H.264) در صورتِ پشتیبانیِ مرورگر، در غیرِ این صورت WebM (VP9)
------------------------------------------------------------------ */

export interface CodecChoice {
  mime: string;
  ext: 'mp4' | 'webm';
  label: string;
  hasAudioCodec: boolean;
}

const CANDIDATES: CodecChoice[] = [
  { mime: 'video/mp4;codecs="avc1.640028,mp4a.40.2"', ext: 'mp4', label: 'MP4 • H.264 High + AAC', hasAudioCodec: true },
  { mime: 'video/mp4;codecs="avc1.42E01E,mp4a.40.2"', ext: 'mp4', label: 'MP4 • H.264 + AAC', hasAudioCodec: true },
  { mime: 'video/mp4', ext: 'mp4', label: 'MP4', hasAudioCodec: true },
  { mime: 'video/webm;codecs="vp9,opus"', ext: 'webm', label: 'WebM • VP9 + Opus', hasAudioCodec: true },
  { mime: 'video/webm;codecs="vp8,opus"', ext: 'webm', label: 'WebM • VP8 + Opus', hasAudioCodec: true },
  { mime: 'video/webm', ext: 'webm', label: 'WebM', hasAudioCodec: false },
];

export function supportedCodecs(): CodecChoice[] {
  if (typeof MediaRecorder === 'undefined') return [];
  return CANDIDATES.filter((c) => MediaRecorder.isTypeSupported(c.mime));
}

export function pickCodec(preferMp4 = true): CodecChoice | null {
  const list = supportedCodecs();
  if (!list.length) return null;
  if (preferMp4) return list.find((c) => c.ext === 'mp4') ?? list[0];
  return list[0];
}

export interface RecordResult {
  blob: Blob;
  mime: string;
  ext: 'mp4' | 'webm';
  seconds: number;
  sizeMB: number;
}

export interface RecorderHandle {
  stop: () => void;
  cancel: () => void;
  promise: Promise<RecordResult>;
}

export interface RecordConfig {
  duration: number;
  fps: number;
  videoBitrate: number;
  audioBitrate: number;
  codec: CodecChoice;
  audioStream?: MediaStream | null;
  /** رندرِ یک فریم در زمانِ t */
  render: (t: number) => void;
  onProgress?: (t: number, pct: number) => void;
  onFinish?: () => void;
}

export function startRecording(canvas: HTMLCanvasElement, cfg: RecordConfig): RecorderHandle {
  const stream = canvas.captureStream(cfg.fps);

  if (cfg.audioStream) {
    cfg.audioStream.getAudioTracks().forEach((tr) => {
      try {
        stream.addTrack(tr);
      } catch {
        /* ترکِ صوتی اضافه نشد — ویدیو بی‌صدا ضبط می‌شود */
      }
    });
  }

  let recorder: MediaRecorder;
  try {
    recorder = new MediaRecorder(stream, {
      mimeType: cfg.codec.mime,
      videoBitsPerSecond: cfg.videoBitrate,
      audioBitsPerSecond: cfg.audioBitrate,
    });
  } catch {
    recorder = new MediaRecorder(stream, {
      videoBitsPerSecond: cfg.videoBitrate,
      audioBitsPerSecond: cfg.audioBitrate,
    });
  }

  const chunks: BlobPart[] = [];
  let cancelled = false;
  let raf = 0;
  let startedAt = 0;

  const promise = new Promise<RecordResult>((resolve, reject) => {
    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunks.push(ev.data);
    };
    recorder.onerror = () => reject(new Error('خطای ضبط در مرورگر رخ داد.'));
    recorder.onstop = () => {
      cancelAnimationFrame(raf);
      if (cancelled) {
        reject(new Error('ضبط لغو شد.'));
        return;
      }
      const blob = new Blob(chunks, { type: cfg.codec.mime.split(';')[0] });
      resolve({
        blob,
        mime: cfg.codec.mime.split(';')[0],
        ext: cfg.codec.ext,
        seconds: (performance.now() - startedAt) / 1000,
        sizeMB: blob.size / 1048576,
      });
      cfg.onFinish?.();
    };
  });

  recorder.start(250);
  startedAt = performance.now();

  const tick = () => {
    const t = (performance.now() - startedAt) / 1000;
    if (t >= cfg.duration) {
      cfg.render(cfg.duration);
      cfg.onProgress?.(cfg.duration, 1);
      if (recorder.state !== 'inactive') recorder.stop();
      return;
    }
    cfg.render(t);
    cfg.onProgress?.(t, t / cfg.duration);
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  return {
    stop: () => {
      if (recorder.state !== 'inactive') recorder.stop();
    },
    cancel: () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      if (recorder.state !== 'inactive') recorder.stop();
    },
    promise,
  };
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 12000);
  return url;
}

/** برآوردِ حجم بر حسبِ مگابایت */
export function estimateMB(bitrate: number, seconds: number) {
  return (bitrate * seconds) / 8 / 1048576;
}
