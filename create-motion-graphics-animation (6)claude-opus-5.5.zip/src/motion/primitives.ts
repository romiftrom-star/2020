/* ------------------------------------------------------------------
   primitives.ts — هستهٔ مشترکِ رسم
   easingها، رنگ، هندسهٔ اسلامی، ذرات کیهانی، تایپوگرافیِ نورانی
------------------------------------------------------------------ */

export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const inv = (a: number, b: number, v: number) => (b === a ? 0 : (v - a) / (b - a));

export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp01(t), 3);
export const easeInCubic = (t: number) => Math.pow(clamp01(t), 3);
export const easeInOutCubic = (t: number) => {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
export const easeOutQuint = (t: number) => 1 - Math.pow(1 - clamp01(t), 5);
export const easeInOutQuint = (t: number) => {
  const x = clamp01(t);
  return x < 0.5 ? 16 * x * x * x * x * x : 1 - Math.pow(-2 * x + 2, 5) / 2;
};
export const easeOutBack = (t: number) => {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const easeOutElastic = (t: number) => {
  const x = clamp01(t);
  if (x <= 0 || x >= 1) return x;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
};
export const easeOutExpo = (t: number) => (clamp01(t) >= 1 ? 1 : 1 - Math.pow(2, -10 * clamp01(t)));

/** پنجرهٔ زمانیِ محلی: از a تا b با نرمال‌سازی ۰..۱ */
export const span = (t: number, a: number, b: number) => clamp01((t - a) / Math.max(0.0001, b - a));

export function toFaDigits(input: string | number): string {
  const map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(input).replace(/\d/g, (d) => map[Number(d)]);
}

export function formatTimeFa(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${toFaDigits(String(m).padStart(2, '0'))}:${toFaDigits(String(r).padStart(2, '0'))}`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const n = parseInt(full, 16);
  if (Number.isNaN(n)) return [255, 255, 255];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function lerpColor(hexA: string, hexB: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  const k = clamp01(t);
  return `rgb(${Math.round(lerp(r1, r2, k))}, ${Math.round(lerp(g1, g2, k))}, ${Math.round(
    lerp(b1, b2, k),
  )})`;
}

export function withAlpha(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${clamp01(alpha)})`;
}

export function seeded(i: number): number {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

export const VZ = '"Vazirmatn", sans-serif';
export const AR = '"Amiri", serif';

export function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

export function drawGlowingText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glowColor: string,
  glowBlur = 18,
  align: CanvasTextAlign = 'center',
) {
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  if (glowBlur > 0) {
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = glowBlur;
  }
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
  ctx.restore();
}

/* ══════════════ هندسهٔ مقدس ══════════════ */

export function drawSacredMandala(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  rot: number,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.002) return;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.84, 0, Math.PI * 2);
  ctx.stroke();

  for (let s = 0; s < 2; s++) {
    ctx.save();
    ctx.rotate((s * Math.PI) / 4);
    const side = radius * 1.18;
    ctx.strokeRect(-side / 2, -side / 2, side, side);
    ctx.restore();
  }

  ctx.beginPath();
  for (let i = 0; i < 12; i++) {
    const a = (i * Math.PI * 2) / 12;
    ctx.moveTo(Math.cos(a) * radius * 0.42, Math.sin(a) * radius * 0.42);
    ctx.lineTo(Math.cos(a) * radius * 0.96, Math.sin(a) * radius * 0.96);
  }
  ctx.stroke();

  ctx.beginPath();
  for (let i = 0; i <= 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    const r = i % 2 === 0 ? radius * 0.42 : radius * 0.24;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

/** ستارهٔ هشت‌پر — امضای بصری جریانِ نور */
export function drawStar8(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  color: string,
  rot: number,
  glow = false,
  alpha = 1,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.globalAlpha *= clamp01(alpha);
  ctx.fillStyle = withAlpha(color, 0.9);
  if (glow) {
    ctx.shadowColor = color;
    ctx.shadowBlur = 26;
  }
  ctx.beginPath();
  for (let k = 0; k < 2; k++) {
    ctx.save();
    ctx.rotate((k * Math.PI) / 4);
    ctx.rect(-r / 1.414, -r / 1.414, r * 1.414, r * 1.414);
    ctx.restore();
  }
  ctx.fill('evenodd');
  ctx.restore();
}

export function drawCosmicParticles(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  timeSec: number,
  accent: string,
  energy: number,
  count = 64,
) {
  for (let i = 0; i < count; i++) {
    const px = seeded(i * 3 + 1) * w;
    const py = (((seeded(i * 3 + 2) * h - timeSec * (4 + seeded(i) * 10)) % h) + h) % h;
    const sz = 0.8 + seeded(i * 5) * 2.2;
    const twinkle = 0.22 + 0.58 * (0.5 + 0.5 * Math.sin(timeSec * (1.1 + seeded(i * 7) * 2.6) + i));
    ctx.fillStyle =
      i % 4 === 0
        ? withAlpha(accent, twinkle * (0.7 + energy * 0.45))
        : `rgba(226, 232, 240, ${twinkle * 0.48})`;
    ctx.beginPath();
    ctx.arc(px, py, sz, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function drawAudioAuraRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  baseRadius: number,
  timeSec: number,
  energy: number,
  color: string,
) {
  ctx.save();
  const r = baseRadius + energy * 18;
  const grad = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.45);
  grad.addColorStop(0, withAlpha(color, 0.24 + energy * 0.16));
  grad.addColorStop(0.6, withAlpha(color, 0.07));
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.45, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = withAlpha(color, 0.42 + energy * 0.35);
  ctx.lineWidth = 2;
  ctx.beginPath();
  const pts = 64;
  for (let i = 0; i <= pts; i++) {
    const a = (i / pts) * Math.PI * 2;
    const wave =
      Math.sin(a * 6 + timeSec * 3.5) * (3 + energy * 11) +
      Math.cos(a * 10 - timeSec * 2.2) * (2 + energy * 7);
    const rr = r + wave;
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

export function drawOrbitRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  rot: number,
  color: string,
  alpha: number,
  node = true,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;
  ctx.setLineDash([7, 9]);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  if (node) {
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(r, 0, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/* ══════════════ اجزای رابطِ صحنه ══════════════ */

export function drawKineticPill(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  label: string,
  progress: number,
  accent: string,
  iconText?: string,
  scaleMult = 1,
  fontSize = 19,
) {
  const p = clamp01(progress);
  if (p <= 0.01) return;
  const s = easeOutBack(p) * scaleMult;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(p * 1.6);

  ctx.font = `700 ${fontSize}px ${VZ}`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  const tw = ctx.measureText(label).width;
  const iconSpace = iconText ? fontSize + 16 : 0;
  const padX = 22;
  const w = tw + padX * 2 + iconSpace;
  const h = fontSize + 24;

  ctx.shadowColor = withAlpha(accent, 0.42);
  ctx.shadowBlur = 16;
  drawRoundedRect(ctx, -w / 2, -h / 2, w, h, h / 2);
  ctx.fillStyle = 'rgba(9, 14, 32, 0.9)';
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.lineWidth = 1.6;
  ctx.strokeStyle = withAlpha(accent, 0.78);
  ctx.stroke();

  if (iconText) {
    ctx.fillStyle = accent;
    ctx.font = `700 ${fontSize}px ${VZ}`;
    ctx.fillText(iconText, -w / 2 + padX / 2 + 6, 1);
    ctx.fillStyle = '#f1f5f9';
    ctx.font = `700 ${fontSize}px ${VZ}`;
    ctx.fillText(label, iconSpace / 2 - 4, 1);
  } else {
    ctx.fillStyle = '#f1f5f9';
    ctx.fillText(label, 0, 1);
  }
  ctx.restore();
}

export function drawNodeBadge(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  label: string,
  progress: number,
  accent: string,
  radius = 26,
) {
  const p = clamp01(progress);
  if (p <= 0.01) return;
  const s = easeOutBack(p);
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(p * 1.7);

  const g = ctx.createRadialGradient(0, 0, 2, 0, 0, radius * 1.9);
  g.addColorStop(0, withAlpha(accent, 0.45));
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, radius * 1.9, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(6, 11, 26, 0.94)';
  ctx.strokeStyle = withAlpha(accent, 0.85);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = accent;
  ctx.shadowColor = accent;
  ctx.shadowBlur = 12;
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.34, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  if (label) {
    ctx.font = `700 15px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e8eef8';
    ctx.fillText(label, 0, radius + 22);
  }
  ctx.restore();
}

export function drawVerseCard(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  arabic: string,
  translation: string,
  ref: string,
  progress: number,
  accent: string,
  width = 720,
) {
  const p = clamp01(progress);
  if (p <= 0.01) return;
  const slide = (1 - easeOutQuint(p)) * 34;
  ctx.save();
  ctx.globalAlpha *= easeOutCubic(p);
  ctx.translate(cx + slide, cy);

  const h = translation ? 118 : 92;
  drawRoundedRect(ctx, -width / 2, -h / 2, width, h, 20);
  const bg = ctx.createLinearGradient(-width / 2, 0, width / 2, 0);
  bg.addColorStop(0, 'rgba(6, 11, 26, 0.62)');
  bg.addColorStop(0.5, 'rgba(9, 16, 36, 0.94)');
  bg.addColorStop(1, 'rgba(6, 11, 26, 0.62)');
  ctx.fillStyle = bg;
  ctx.fill();
  ctx.strokeStyle = withAlpha(accent, 0.5);
  ctx.lineWidth = 1.4;
  ctx.stroke();

  // نگین‌های کناری
  drawStar8(ctx, -width / 2 + 2, 0, 7, accent, ref.length * 0.13, false, 0.9);
  drawStar8(ctx, width / 2 - 2, 0, 7, accent, -ref.length * 0.13, false, 0.9);

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = withAlpha(accent, 0.55);
  ctx.shadowBlur = 16;
  ctx.fillStyle = '#f8fafc';
  ctx.font = `700 27px ${AR}`;
  ctx.fillText(arabic, 0, translation ? -26 : -12);
  ctx.shadowBlur = 0;

  if (translation) {
    ctx.font = `600 17px ${VZ}`;
    ctx.fillStyle = withAlpha(accent, 0.95);
    ctx.fillText(translation, 0, 14);
  }
  ctx.font = `500 13px ${VZ}`;
  ctx.fillStyle = 'rgba(203, 213, 225, 0.72)';
  ctx.fillText(ref, 0, translation ? 42 : 28);
  ctx.restore();
}

export function drawSpectrumBars(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  bars: number,
  width: number,
  timeSec: number,
  energy: number,
  color: string,
  alpha = 0.5,
  levels?: Float32Array | number[],
) {
  const gap = 3;
  const bw = Math.max(1.6, (width - gap * (bars - 1)) / bars);
  ctx.save();
  ctx.globalAlpha = alpha;
  for (let i = 0; i < bars; i++) {
    const lv =
      levels && levels.length
        ? clamp01(Number(levels[Math.min(levels.length - 1, Math.floor((i / bars) * levels.length))]) * 2.1)
        : 0.18 +
          0.5 *
            Math.abs(
              Math.sin(timeSec * 2.4 + i * 0.55) * 0.6 + Math.sin(timeSec * 5.1 + i * 1.7) * 0.4,
            ) *
            (0.35 + energy);
    const h = 4 + lv * 26;
    ctx.fillStyle = withAlpha(i % 5 === 0 ? '#fde68a' : color, 0.55 + lv * 0.45);
    drawRoundedRect(ctx, x + i * (bw + gap), y - h / 2, bw, h, bw / 2);
    ctx.fill();
  }
  ctx.restore();
}

/** کمانِ پیشرفت (گِیج) */
export function drawArcProgress(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  value: number,
  color: string,
  lineWidth = 8,
  startAngle = Math.PI * 0.75,
  sweep = Math.PI * 1.5,
) {
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineWidth = lineWidth;
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.16)';
  ctx.beginPath();
  ctx.arc(cx, cy, r, startAngle, startAngle + sweep);
  ctx.stroke();

  const v = clamp01(value);
  if (v > 0.001) {
    ctx.strokeStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.arc(cx, cy, r, startAngle, startAngle + sweep * v);
    ctx.stroke();
  }
  ctx.restore();
}

/** خطی که خودش را می‌کشد */
export function drawGrowingPath(
  ctx: CanvasRenderingContext2D,
  pts: Array<[number, number]>,
  progress: number,
  color: string,
  lineWidth = 3,
  dash?: number[],
) {
  const p = clamp01(progress);
  if (p <= 0 || pts.length < 2) return;
  const total = pts.length - 1;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (dash) ctx.setLineDash(dash);
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) {
    const seg = clamp01(p * total - (i - 1));
    if (seg <= 0) break;
    ctx.lineTo(lerp(pts[i - 1][0], pts[i][0], seg), lerp(pts[i - 1][1], pts[i][1], seg));
  }
  ctx.stroke();
  ctx.restore();
}

/** موجِ انرژی که در طولِ یک مسیر حرکت می‌کند */
export function drawFlowPulse(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  timeSec: number,
  color: string,
  count = 5,
  speed = 0.42,
) {
  ctx.save();
  ctx.lineCap = 'round';
  for (let i = 0; i < count; i++) {
    const prog = ((timeSec * speed + i / count) % 1);
    const x = lerp(x1, x2, prog);
    const y = lerp(y1, y2, prog);
    const a = Math.sin(prog * Math.PI);
    ctx.strokeStyle = withAlpha(color, 0.9 * a);
    ctx.lineWidth = 2.4;
    const dx = (x2 - x1) / Math.hypot(x2 - x1 || 1, y2 - y1 || 1);
    const dy = (y2 - y1) / Math.hypot(x2 - x1 || 1, y2 - y1 || 1);
    ctx.beginPath();
    ctx.moveTo(x + dx * 15, y + dy * 15);
    ctx.lineTo(x - dx * 13, y - dy * 13);
    ctx.stroke();
    ctx.fillStyle = withAlpha('#fff7ed', 0.85 * a);
    ctx.beginPath();
    ctx.arc(x + dx * 15, y + dy * 15, 2.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawGlassCard(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  w: number,
  h: number,
  progress: number,
  accent: string,
  radius = 18,
) {
  const p = clamp01(progress);
  if (p <= 0.01) return;
  ctx.save();
  ctx.globalAlpha *= easeOutCubic(p);
  const lift = (1 - easeOutQuint(p)) * 26;
  ctx.translate(cx, cy + lift);
  drawRoundedRect(ctx, -w / 2, -h / 2, w, h, radius);
  const g = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
  g.addColorStop(0, 'rgba(14, 22, 48, 0.86)');
  g.addColorStop(1, 'rgba(6, 11, 26, 0.9)');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = withAlpha(accent, 0.42);
  ctx.lineWidth = 1.4;
  ctx.stroke();
  ctx.fillStyle = withAlpha(accent, 0.9);
  drawRoundedRect(ctx, -w / 2, -h / 2, 4, h, 2);
  ctx.fill();
  ctx.restore();
}
