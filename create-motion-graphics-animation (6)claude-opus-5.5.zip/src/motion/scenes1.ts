/* ------------------------------------------------------------------
   scenes1.ts — صحنه‌های المان‌محورِ فصل ۱ تا ۴
   منطقهٔ امنِ بصری روی ۱۲۸۰×۷۲۰: y از ۱۰۰ تا ۵۹۰
------------------------------------------------------------------ */
import {
  VZ,
  clamp01,
  drawArcProgress,
  drawAudioAuraRing,
  drawCosmicParticles,
  drawFlowPulse,
  drawGlowingText,
  drawGrowingPath,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawStar8,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  span,
  withAlpha,
} from './primitives';
import {
  drawBoat,
  drawBrainMind,
  drawChainLink,
  drawCounter,
  drawFlower,
  drawHeart,
  drawLeaf,
  drawPopText,
  drawSailOnly,
  drawScissors,
  drawStaggerWords,
  drawWaterWaves,
  drawWipeText,
} from './fx';

/** t = زمانِ محلی، d = طولِ فصل، g = زمانِ کل، e = انرژیِ صدا */
export type SceneFn = (
  ctx: CanvasRenderingContext2D,
  t: number,
  d: number,
  g: number,
  e: number,
  a: string,
  b: string,
) => void;

/* ══════════ ۱ — دو مسیر و جریانِ نور ══════════ */
export const sceneTwoPathsBoat: SceneFn = (ctx, t, d, g, e, a, b) => {
  drawWaterWaves(ctx, 432, 1280, g * 1.1, b, a, 3, 12);

  // خورشیدِ اقیانوسِ رحمت در سمتِ چپ
  const sunP = span(t, 1.6, 3.6);
  const sunGlow = ctx.createRadialGradient(168, 322, 10, 168, 322, 268);
  sunGlow.addColorStop(0, withAlpha(a, (0.4 + e * 0.18) * easeOutCubic(sunP)));
  sunGlow.addColorStop(0.5, withAlpha(b, 0.14 * sunP));
  sunGlow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sunGlow;
  ctx.beginPath();
  ctx.arc(168, 322, 268, 0, Math.PI * 2);
  ctx.fill();
  drawStar8(ctx, 168, 322, (30 + e * 12) * easeOutBack(sunP), a, g * 0.45, true, sunP);
  drawPopText(
    ctx,
    'اقیانوسِ رحمت',
    168,
    388,
    `700 18px ${VZ}`,
    '#fde68a',
    withAlpha(a, 0.6),
    (t - 2.4) / 1.1,
  );

  // مسیرِ ۱: صراطِ مستقیم — رودخانهٔ نور از راست به چپ
  const straightP = easeOutCubic(span(t, 1.1, 4.1));
  ctx.save();
  const riverGrad = ctx.createLinearGradient(1140, 322, 200, 322);
  riverGrad.addColorStop(0, withAlpha(a, 0.08));
  riverGrad.addColorStop(0.45, withAlpha(a, 0.42));
  riverGrad.addColorStop(1, withAlpha(b, 0.66));
  ctx.strokeStyle = riverGrad;
  ctx.lineWidth = 44;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(1140, 322);
  ctx.lineTo(lerp(1140, 216, straightP), 322);
  ctx.stroke();
  ctx.restore();

  if (straightP > 0.05) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(216, 288, 924, 68);
    ctx.clip();
    drawFlowPulse(ctx, 1130, 322, 226, 322, g, '#fef08a', 6, 0.4);
    ctx.restore();
  }

  // مسیرِ ۲: زیگزاگِ قرمزِ پرانحراف
  const zigP = span(t, 4.2, 7.8);
  if (zigP > 0.01) {
    const pts: Array<[number, number]> = [
      [1096, 322],
      [980, 226],
      [848, 418],
      [706, 208],
      [572, 438],
      [452, 252],
    ];
    ctx.save();
    ctx.globalAlpha = 0.78 * easeOutCubic(zigP);
    drawGrowingPath(ctx, pts, easeOutCubic(zigP), '#fb7185', 3, [10, 8]);
    // جرقه‌های انحراف
    for (let i = 0; i < pts.length; i++) {
      const np = clamp01(zigP * (pts.length - 1) - i + 0.6);
      if (np <= 0) continue;
      ctx.fillStyle = withAlpha('#fb7185', 0.55 * np * (0.5 + 0.5 * Math.sin(g * 6 + i)));
      ctx.beginPath();
      ctx.arc(pts[i][0], pts[i][1], 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // قایق: نیمهٔ اول پراضطراب، نیمهٔ دوم هم‌جهت با نور
  const alignPhase = easeInOutCubic(span(t, d * 0.55, d * 0.55 + 5.4));
  const wobbleY = Math.sin(g * 2.8) * 60 * (1 - alignPhase);
  const boatX = lerp(948, 566, easeInOutCubic(span(t, 0.6, d - 1.4))) + Math.sin(g * 1.4) * 12;
  const boatY = 322 + wobbleY + Math.sin(g * 3.1) * 5;
  const tilt = Math.cos(g * 2.8) * 0.17 * (1 - alignPhase) + Math.sin(g * 2.1) * 0.03;
  drawBoat(
    ctx,
    boatX,
    boatY,
    0.94,
    tilt,
    alignPhase > 0.5 ? a : '#fb7185',
    g * 5.2,
    alignPhase > 0.72,
    1 - alignPhase * 0.68,
  );

  // تایپوگرافی
  drawWipeText(ctx, 'دو مسیر در زندگی', 640, 132, `800 42px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.7) / 1.7);
  drawKineticPill(ctx, 934, 198, 'راهِ مستقیم • هم‌جهت با نور', (t - 3.1) / 1.1, a, '✦', 0.95, 18);
  drawKineticPill(ctx, 452, 198, 'راهِ غیرمستقیم • تکیه بر توانِ خود', (t - 6.2) / 1.1, '#fb7185', '✕', 0.92, 17);

  drawStaggerWords(
    ctx,
    'با جریانِ خدا هم‌سو شو',
    640,
    244,
    `600 21px ${VZ}`,
    '#e2e8f0',
    withAlpha(b, 0.5),
    t,
    8.4,
    0.12,
  );

  drawVerseCard(ctx, 640, 520, 'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ', 'خداوند نورِ آسمان‌ها و زمین است', 'سورهٔ نور • آیهٔ ۳۵', (t - 9.4) / 1.4, a, 760);
};

/* ══════════ ۲ — تسلیم؛ پاروها را کنار بگذار ══════════ */
export const sceneSurrenderOcean: SceneFn = (ctx, t, d, g, e, a, b) => {
  const horizon = 400;
  drawWaterWaves(ctx, horizon, 1280, g * 0.85, a, b, 4, 9);

  // آسمانِ مقصد و اقیانوسِ رحمت
  const destP = easeOutCubic(span(t, 2.2, 6));
  const sky = ctx.createRadialGradient(150, 250, 20, 150, 250, 420);
  sky.addColorStop(0, withAlpha(b, 0.3 * destP + e * 0.1));
  sky.addColorStop(0.55, withAlpha(a, 0.1 * destP));
  sky.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sky;
  ctx.beginPath();
  ctx.arc(150, 250, 420, 0, Math.PI * 2);
  ctx.fill();
  drawStar8(ctx, 150, 246, 34 * destP + e * 8, b, g * 0.3, true, destP);

  // کانالِ جریان — سه لایه خطِ نور
  for (let L = 0; L < 3; L++) {
    const y = horizon - 26 + L * 26;
    const p = easeOutQuint(span(t, 0.8 + L * 0.5, 4 + L * 0.5));
    ctx.save();
    ctx.globalAlpha = 0.5 - L * 0.12;
    ctx.strokeStyle = withAlpha(L === 1 ? b : a, 0.85);
    ctx.lineWidth = 2.4 - L * 0.5;
    ctx.beginPath();
    ctx.moveTo(1210, y);
    ctx.lineTo(lerp(1210, 170, p), y);
    ctx.stroke();
    ctx.restore();
    if (p > 0.06) {
      ctx.save();
      ctx.globalAlpha = 0.75 - L * 0.18;
      drawFlowPulse(ctx, 1200, y, 180, y, g + L * 0.4, '#fde68a', 5, 0.3 + L * 0.06);
      ctx.restore();
    }
  }

  // قایقِ رها — آرام به سمتِ اقیانوس
  const drift = easeInOutCubic(span(t, 0.5, d - 1));
  const bx = lerp(1010, 330, drift);
  const by = horizon - 34 + Math.sin(g * 1.6) * 6;
  const calm = span(t, 3.4, 6.4);
  drawBoat(ctx, bx, by, 0.86 + drift * 0.14, Math.sin(g * 1.2) * 0.035, a, g * 1.1, calm > 0.4, 0);

  // دو پارو که جدا می‌شوند، می‌افتند و در آب فرو می‌روند
  for (let i = 0; i < 2; i++) {
    const drop = span(t, 2.6 + i * 0.45, 5.6 + i * 0.45);
    if (drop <= 0) continue;
    const sx = bx + (i === 0 ? 40 : -40);
    const sy = by - 10;
    const px = sx + (i === 0 ? 1 : -1) * drop * 132;
    const py = sy + easeIn(drop) * 150 + Math.sin(drop * 6) * 8;
    const rot = (i === 0 ? 1 : -1) * drop * 3.1 + 0.6;
    const sink = span(drop, 0.72, 1);
    ctx.save();
    ctx.globalAlpha = 1 - sink;
    ctx.translate(px, py);
    ctx.rotate(rot);
    ctx.strokeStyle = 'rgba(226, 232, 240, 0.9)';
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-34, 0);
    ctx.lineTo(30, 0);
    ctx.stroke();
    ctx.fillStyle = 'rgba(148, 163, 184, 0.95)';
    ctx.beginPath();
    ctx.ellipse(38, 0, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // حلقهٔ برخورد با آب
    if (drop > 0.7 && drop < 0.98) {
      const rp = (drop - 0.7) / 0.28;
      ctx.strokeStyle = withAlpha('#e0f2fe', (1 - rp) * 0.7);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(px, horizon - 6, 12 + rp * 46, 4 + rp * 12, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // جنگ ← تسلیم
  const warP = span(t, 1.2, 2.4);
  const strikeP = easeOutCubic(span(t, 4.2, 5.6));
  if (warP > 0) {
    ctx.save();
    ctx.globalAlpha = 1 - span(t, 5.4, 6.6);
    drawKineticPill(ctx, 1000, 176, 'باید بجنگی!', warP, '#fb7185', '✕', 0.9, 18);
    ctx.restore();
    if (strikeP > 0) {
      ctx.save();
      ctx.strokeStyle = '#fde68a';
      ctx.lineWidth = 3.4;
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.moveTo(1000 + 88 - strikeP * 176, 176);
      ctx.lineTo(1000 + 88, 176);
      ctx.stroke();
      ctx.restore();
    }
  }
  drawKineticPill(ctx, 640, 226, 'تسلیم = هم‌جهت شدن با جریان', (t - 6.1) / 1.2, a, '✦', 1.06, 21);

  drawWipeText(ctx, 'پاروها را بگذار کنار', 640, 132, `800 40px ${VZ}`, '#fde68a', withAlpha(b, 0.62), (t - 0.6) / 1.6);

  // گِیجِ مسافتِ طی‌شده تا اقیانوس
  ctx.save();
  ctx.translate(1150, 262);
  drawArcProgress(ctx, 0, 0, 44, drift, b, 7);
  drawGlowingText(ctx, 'اقیانوس', 0, -2, `700 15px ${VZ}`, '#e0f2fe', withAlpha(b, 0.5), 8);
  drawGlowingText(ctx, `${Math.round(drift * 100)}٪`, 0, 18, `800 16px ${VZ}`, '#fde68a', withAlpha(a, 0.5), 8);
  ctx.restore();

  // آدمی که در قایق دراز کشیده
  const layP = easeOutCubic(span(t, 5.4, 7.4));
  if (layP > 0.02) {
    ctx.save();
    ctx.globalAlpha = layP;
    ctx.translate(bx - 4, by - 20);
    ctx.rotate(-0.1);
    ctx.scale(0.42 * layP, 0.42 * layP);
    ctx.strokeStyle = '#fde68a';
    ctx.fillStyle = '#fde68a';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.shadowColor = withAlpha(b, 0.8);
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.arc(-46, -6, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-34, -2);
    ctx.lineTo(26, 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-6, 2);
    ctx.lineTo(14, 16);
    ctx.moveTo(-2, 4);
    ctx.lineTo(10, -14);
    ctx.stroke();
    ctx.restore();
  }

  drawSailOnly(ctx, 150, 336, 0.62 * destP, b, g);
  drawVerseCard(ctx, 640, 522, 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', 'ما را به راهِ مستقیم هدایت کن', 'سورهٔ فاتحه • آیهٔ ۶', (t - 9.6) / 1.4, b, 740);
};

function easeIn(t: number) {
  return Math.pow(clamp01(t), 2);
}

/* ══════════ ۳ — هم‌جهت‌سازیِ ذهن و روح ══════════ */
export const sceneMindSoulAlign: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  const cy = 282;
  const gapX = 178;

  const misalign = lerp(1.32, 0, easeInOutCubic(span(t, 3.4, 9.6)));
  const aligned = 1 - clamp01(misalign / 0.12);

  // دو قطب: ذهن (چپ) و روح (راست)
  drawAudioAuraRing(ctx, cx - gapX, cy, 78, g, e * 0.6 + 0.1, b);
  drawAudioAuraRing(ctx, cx + gapX, cy, 78, g * 1.2, e * 0.6 + 0.1, a);

  drawBrainMind(ctx, cx - gapX, cy, 62, b, g, aligned);
  ctx.save();
  ctx.strokeStyle = withAlpha(b, 0.5);
  ctx.lineWidth = 1.6;
  ctx.setLineDash([5, 7]);
  ctx.beginPath();
  ctx.arc(cx - gapX, cy, 74, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  drawGlowingText(ctx, 'ذهن', cx - gapX, cy + 100, `800 22px ${VZ}`, '#e0f2fe', withAlpha(b, 0.6), 14);
  drawGlowingText(ctx, 'جایگاهِ ورودی‌ها', cx - gapX, cy + 126, `500 14px ${VZ}`, 'rgba(203,213,225,0.8)', 'rgba(0,0,0,0)', 0);

  drawHeart(ctx, cx + gapX, cy, 52, a, 0.5 + 0.5 * Math.sin(g * 4.2) * (0.4 + e), 0.95);
  ctx.save();
  ctx.strokeStyle = withAlpha(a, 0.45);
  ctx.lineWidth = 1.6;
  ctx.setLineDash([5, 7]);
  ctx.beginPath();
  ctx.arc(cx + gapX, cy, 74, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  drawGlowingText(ctx, 'روح و قلب', cx + gapX, cy + 100, `800 22px ${VZ}`, '#fde68a', withAlpha(a, 0.6), 14);
  drawGlowingText(ctx, 'جایگاهِ خدا', cx + gapX, cy + 126, `500 14px ${VZ}`, 'rgba(203,213,225,0.8)', 'rgba(0,0,0,0)', 0);

  // دو بردارِ جهت + کمانِ زاویهٔ انحراف
  const drawVector = (x: number, y: number, ang: number, color: string, len: number, p: number) => {
    if (p <= 0) return;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = 16;
    const L = len * easeOutQuint(p);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(L, 0);
    ctx.stroke();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(L + 12, 0);
    ctx.lineTo(L - 4, -8);
    ctx.lineTo(L - 4, 8);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };
  const vP = span(t, 1.8, 3.4);
  drawVector(cx - gapX, cy - 96, -misalign * 0.62, b, 92, vP);
  drawVector(cx + gapX, cy - 96, Math.PI + misalign * 0.62, a, 92, vP);

  // کمانِ زاویه بین دو بردار
  if (vP > 0.2) {
    ctx.save();
    ctx.translate(cx, cy - 96);
    ctx.strokeStyle = withAlpha('#fde68a', 0.5 * vP);
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 6]);
    ctx.beginPath();
    ctx.arc(0, 0, 118, Math.PI - misalign * 0.62, misalign * -0.62, false);
    ctx.stroke();
    ctx.restore();
  }

  const deg = Math.round((misalign * 0.62 * 180) / Math.PI);
  drawCounter(
    ctx,
    `زاویهٔ انحراف: ${String(deg).replace(/\d/g, (x) => '۰۱۲۳۴۵۶۷۸۹'[Number(x)])}°`,
    cx,
    158,
    `700 19px ${VZ}`,
    deg > 6 ? '#fecaca' : '#bbf7d0',
    deg > 6 ? 'rgba(251,113,133,0.5)' : 'rgba(52,211,153,0.5)',
    span(t, 2.4, 3.4),
  );

  // پلِ نور هنگامِ انطباق
  if (aligned > 0.02) {
    ctx.save();
    ctx.globalAlpha = aligned;
    const beam = ctx.createLinearGradient(cx - gapX, cy, cx + gapX, cy);
    beam.addColorStop(0, withAlpha(b, 0.75));
    beam.addColorStop(0.5, withAlpha('#fde68a', 0.95));
    beam.addColorStop(1, withAlpha(a, 0.75));
    ctx.strokeStyle = beam;
    ctx.lineWidth = 6 + e * 6;
    ctx.lineCap = 'round';
    ctx.shadowColor = '#fde68a';
    ctx.shadowBlur = 30;
    ctx.beginPath();
    ctx.moveTo(cx - gapX + 66, cy);
    ctx.lineTo(cx + gapX - 66, cy);
    ctx.stroke();
    ctx.restore();
    drawStar8(ctx, cx, cy, (26 + e * 16) * easeOutBack(aligned), '#fde68a', g * 0.7, true, aligned);
    drawPopText(ctx, 'هم‌جهت شد', cx, cy - 62, `800 24px ${VZ}`, '#fde68a', 'rgba(251,191,36,0.7)', (t - 9.8) / 1);
  }

  drawWipeText(ctx, 'تربیتِ ذهن؛ کلِ قرآن', cx, 116, `800 38px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.5) / 1.5);

  // زنجیرِ مومنتومِ منفی و قیچی
  const chainY = 448;
  const cutP = easeOutCubic(span(t, 5.2, 6.6));
  const links = 9;
  for (let i = 0; i < links; i++) {
    const lx = cx - 168 + i * 42;
    const broken = i < links / 2 ? clamp01((cutP - (links / 2 - 1 - i) * 0.06) * 3) : clamp01((cutP - (i - links / 2) * 0.06) * 3);
    const fall = broken * broken;
    ctx.save();
    ctx.translate(0, fall * 34);
    ctx.globalAlpha = 1 - fall * 0.85;
    drawChainLink(ctx, lx, chainY, fall * (i % 2 ? 0.7 : -0.7), 11, broken > 0.15 ? withAlpha('#fb7185', 0.5) : '#fb7185', broken);
    ctx.restore();
  }
  drawScissors(ctx, cx, chainY - 24 + cutP * 24, 0.9, 1 - cutP, '#fde68a');
  drawKineticPill(ctx, 296, chainY, 'قطعِ مومنتومِ منفی', (t - 5) / 1, '#fb7185', '✂', 0.88, 16);
  drawKineticPill(ctx, 984, chainY, 'تقویتِ مومنتومِ مثبت', (t - 6.2) / 1, a, '✦', 0.88, 16);

  drawKineticPill(ctx, 250, 214, 'صدّق بالحُسنی', (t - 7.2) / 1.1, b, '✦', 0.92, 17);
  drawKineticPill(ctx, 1030, 214, 'اعراض از نازیبایی‌ها', (t - 8.2) / 1.1, a, '✧', 0.92, 17);

  drawVerseCard(
    ctx,
    cx,
    528,
    'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    'نیکی را تصدیق کرد، پس او را به آسانی می‌گماریم',
    'سورهٔ لیل • آیات ۶ و ۷',
    (t - 10.4) / 1.3,
    a,
    800,
  );
};

/* ══════════ ۴ — فراوانی؛ مدارِ نعمت ══════════ */
const BLESS_INNER = ['چشم', 'گوش', 'زبان', 'قلب'];
const BLESS_NATURE = ['خورشید', 'ابر و باد', 'جنگل', 'اقیانوس', 'کوه'];
const BLESS_HUMAN = ['جاده', 'تیرِ برق', 'بازار', 'ساختمان'];

export const sceneAbundanceOrbit: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 430;
  const cy = 312;

  // هستهٔ شکرگزاری
  drawAudioAuraRing(ctx, cx, cy, 58, g, 0.25 + e, a);
  drawHeart(ctx, cx, cy, 34, a, 0.5 + 0.5 * Math.sin(g * 3.1) * (0.5 + e), 1);
  drawStar8(ctx, cx, cy, 76 + e * 8, b, g * 0.16, false, 0.13);

  const rings = [
    { r: 88, items: BLESS_INNER, color: a, speed: 0.26, at: 1.4, label: 'نعمت‌های درون' },
    { r: 132, items: BLESS_NATURE, color: b, speed: -0.19, at: 3.6, label: 'جهانِ پیرامون' },
    { r: 176, items: BLESS_HUMAN, color: '#fde68a', speed: 0.14, at: 6.2, label: 'ساختهٔ دستِ انسان' },
  ];

  rings.forEach((ring) => {
    const rp = easeOutCubic(span(t, ring.at, ring.at + 2));
    if (rp <= 0.01) return;
    drawOrbitRing(ctx, cx, cy, ring.r * rp, g * ring.speed, ring.color, 0.3 * rp, false);
    ring.items.forEach((label, i) => {
      const ip = span(t, ring.at + 0.5 + i * 0.42, ring.at + 1.5 + i * 0.42);
      if (ip <= 0.01) return;
      const ang = g * ring.speed + (i / ring.items.length) * Math.PI * 2;
      const nx = cx + Math.cos(ang) * ring.r * rp;
      const ny = cy + Math.sin(ang) * ring.r * rp;
      drawNodeBadge(ctx, nx, ny, label, ip, ring.color, 20);
    });
  });

  // ستونِ راست: شمارندهٔ فراوانی
  const px = 968;
  drawGlowingText(ctx, 'فراوانی', px, 132, `800 32px ${VZ}`, '#fde68a', withAlpha(a, 0.6), 22);
  const countP = easeOutCubic(span(t, 2.6, 11));
  const n = Math.floor(countP * 999999);
  drawCounter(
    ctx,
    countP >= 1 ? '∞' : String(n).replace(/\d/g, (x) => '۰۱۲۳۴۵۶۷۸۹'[Number(x)]),
    px,
    190,
    `900 52px ${VZ}`,
    '#fff7ed',
    withAlpha(a, 0.7),
    span(t, 2.4, 3.2),
  );
  drawGlowingText(ctx, 'نعمتی که شمرده نمی‌شود', px, 228, `600 15px ${VZ}`, 'rgba(203,213,225,0.9)', 'rgba(0,0,0,0)', 0);

  // میلهٔ «ورودیِ ذهن» که از زیبایی پر می‌شود
  const barP = easeOutQuint(span(t, 5.2, 12));
  const bw = 268;
  ctx.save();
  ctx.translate(px - bw / 2, 266);
  drawRoundedRectBar(ctx, 0, 0, bw, 18, 9, 'rgba(148,163,184,0.16)');
  const grad = ctx.createLinearGradient(0, 0, bw, 0);
  grad.addColorStop(0, b);
  grad.addColorStop(1, a);
  ctx.save();
  ctx.shadowColor = withAlpha(a, 0.7);
  ctx.shadowBlur = 16;
  ctx.fillStyle = grad;
  drawRoundedRectBarPath(ctx, 0, 0, bw * barP, 18, 9);
  ctx.fill();
  ctx.restore();
  // سرِ درخشانِ میله
  if (barP > 0.02) {
    ctx.fillStyle = '#fff7ed';
    ctx.beginPath();
    ctx.arc(bw * barP, 9, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  drawGlowingText(ctx, 'ورودیِ ذهن سرشار از زیبایی', px, 302, `600 14px ${VZ}`, '#bbf7d0', withAlpha(b, 0.4), 8);

  // راهنمایِ سه حلقهٔ مدارِ نعمت
  rings.forEach((ring, i) => {
    const lp = easeOutCubic(span(t, ring.at + 0.9, ring.at + 1.9));
    if (lp <= 0.01) return;
    const ly = 340 + i * 30;
    ctx.save();
    ctx.globalAlpha = lp;
    ctx.fillStyle = ring.color;
    ctx.shadowColor = ring.color;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(px + 132, ly, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.font = `600 14px ${VZ}`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(226,232,240,0.88)';
    ctx.fillText(ring.label, px + 118, ly + 1);
    ctx.restore();
  });

  // شکوفه‌ها در باندِ چپ و برگ‌های شناورِ بالارونده
  drawFlower(ctx, 198, 424, 27, span(t, 7.4, 9), a, g * 0.4);
  drawFlower(ctx, 142, 470, 19, span(t, 8.2, 9.8), b, -g * 0.3);
  for (let i = 0; i < 6; i++) {
    const lp = span(t, 8 + i * 0.5, 9 + i * 0.5);
    if (lp <= 0) continue;
    const lx = 78 + ((seeded(i) * 120 + g * (14 + seeded(i * 3) * 20)) % 150);
    const ly = 512 - lp * 104 + Math.sin(g * 2 + i) * 9;
    drawLeaf(ctx, lx, ly, 12, g * 0.8 + i, i % 2 ? b : a, (1 - lp) * 0.9);
  }
  drawPopText(ctx, 'دیدنِ فراوانی = تربیتِ ذهن', px, 444, `700 17px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 10.2) / 1.1);

  drawWipeText(ctx, 'هر روز شکرگزاری کن', 640, 104, `800 36px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.5) / 1.5);

  drawCosmicParticles(ctx, 1280, 720, g, a, e, 26);
  drawVerseCard(
    ctx,
    640,
    528,
    'وَإِن تَعُدُّوا نِعْمَتَ اللَّهِ لَا تُحْصُوهَا',
    'اگر نعمتِ خدا را بشمارید، هرگز برنمی‌آید',
    'سورهٔ ابراهیم • آیهٔ ۳۴',
    (t - 11.6) / 1.3,
    a,
    800,
  );
};

function drawRoundedRectBar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill: string,
) {
  if (w <= 0) return;
  ctx.save();
  ctx.fillStyle = fill;
  drawRoundedRectBarPath(ctx, x, y, w, h, r);
  ctx.fill();
  ctx.restore();
}

function drawRoundedRectBarPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.max(0, Math.min(r, Math.max(w, 0.001) / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}
