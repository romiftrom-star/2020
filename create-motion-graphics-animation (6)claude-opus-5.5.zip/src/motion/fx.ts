/* ------------------------------------------------------------------
   fx.ts — المان‌های تصویرسازی‌شدهٔ موشن گرافیک
   هر تابع یک «المان» است: قایق، قطب‌نما، موج، چراغ، دروازه، قلب، …
------------------------------------------------------------------ */
import {
  VZ,
  clamp01,
  drawRoundedRect,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  withAlpha,
} from './primitives';

/* ═══════════ تایپوگرافیِ جنبشی ═══════════ */

export function drawWipeText(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  align: CanvasTextAlign = 'center',
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  const w = ctx.measureText(text).width;
  const h = parseFloat(font) * 1.5;
  const x0 = align === 'center' ? cx - w / 2 : align === 'right' ? cx - w : cx;

  // پردهٔ رنگی که از راست به چپ باز می‌شود (RTL)
  ctx.save();
  ctx.beginPath();
  ctx.rect(x0 + w * (1 - easeOutQuint(p)), cy - h / 2, w + 8, h);
  ctx.clip();
  ctx.shadowColor = glow;
  ctx.shadowBlur = 24;
  ctx.fillStyle = fill;
  ctx.fillText(text, cx, cy);
  ctx.restore();

  // لبهٔ نورانیِ پرده
  if (p < 1) {
    const ex = x0 + w * (1 - easeOutQuint(p));
    ctx.strokeStyle = withAlpha('#fff7ed', 0.85);
    ctx.lineWidth = 2.6;
    ctx.shadowColor = glow;
    ctx.shadowBlur = 20;
    ctx.beginPath();
    ctx.moveTo(ex, cy - h / 2 + 4);
    ctx.lineTo(ex, cy + h / 2 - 4);
    ctx.stroke();
  }
  ctx.restore();
}

export function drawPopText(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  align: CanvasTextAlign = 'center',
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  const s = easeOutBack(p);
  ctx.save();
  ctx.globalAlpha *= clamp01(p * 1.8);
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  ctx.shadowColor = glow;
  ctx.shadowBlur = 22;
  ctx.fillStyle = fill;
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

/** کلمه‌به‌کلمه با تأخیر پلکانی — برای جملات کلیدی */
export function drawStaggerWords(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  t: number,
  startAt: number,
  step = 0.14,
  gap = 14,
) {
  const words = text.split(' ');
  ctx.save();
  ctx.font = font;
  ctx.textBaseline = 'middle';
  const widths = words.map((w) => ctx.measureText(w).width);
  const total = widths.reduce((s, w) => s + w, 0) + gap * (words.length - 1);
  // RTL: از راست شروع می‌کنیم
  let x = cx + total / 2;
  for (let i = 0; i < words.length; i++) {
    const p = clamp01((t - startAt - i * step) / 0.7);
    if (p > 0) {
      const e = easeOutQuint(p);
      ctx.save();
      ctx.globalAlpha = e;
      ctx.textAlign = 'center';
      ctx.shadowColor = glow;
      ctx.shadowBlur = 18 * e;
      ctx.fillStyle = fill;
      ctx.translate(x - widths[i] / 2, cy + (1 - e) * 26);
      ctx.fillText(words[i], 0, 0);
      ctx.restore();
    }
    x -= widths[i] + gap;
  }
  ctx.restore();
}

/* ═══════════ آب و آسمان ═══════════ */

export function drawWaterWaves(
  ctx: CanvasRenderingContext2D,
  baseY: number,
  width: number,
  timeSec: number,
  color: string,
  color2: string,
  layers = 3,
  amp = 12,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  for (let L = 0; L < layers; L++) {
    const k = L / Math.max(1, layers - 1);
    const y = baseY + L * 26;
    const a = amp * (1 - k * 0.45);
    const speed = 0.55 + k * 0.5;
    ctx.beginPath();
    ctx.moveTo(0, y);
    for (let x = 0; x <= width; x += 8) {
      const yy =
        y +
        Math.sin(x * 0.011 + timeSec * speed * 2.1 + L * 1.7) * a +
        Math.sin(x * 0.027 - timeSec * speed * 1.4 + L) * (a * 0.42);
      ctx.lineTo(x, yy);
    }
    ctx.lineTo(width, 760);
    ctx.lineTo(0, 760);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, y - a, 0, y + 130);
    g.addColorStop(0, withAlpha(L % 2 === 0 ? color : color2, 0.2 - k * 0.09));
    g.addColorStop(1, 'rgba(2, 5, 14, 0)');
    ctx.fillStyle = g;
    ctx.fill();

    ctx.strokeStyle = withAlpha(L % 2 === 0 ? color : color2, 0.42 - k * 0.16);
    ctx.lineWidth = 1.8 - k * 0.5;
    ctx.beginPath();
    for (let x = 0; x <= width; x += 8) {
      const yy =
        y +
        Math.sin(x * 0.011 + timeSec * speed * 2.1 + L * 1.7) * a +
        Math.sin(x * 0.027 - timeSec * speed * 1.4 + L) * (a * 0.42);
      if (x === 0) ctx.moveTo(x, yy);
      else ctx.lineTo(x, yy);
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function drawBoat(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  tilt: number,
  color: string,
  timeSec: number,
  sailUp: boolean,
  rowEnergy: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(tilt);
  ctx.scale(scale, scale);

  // بازتابِ نور زیر قایق
  const rg = ctx.createRadialGradient(0, 26, 4, 0, 26, 92);
  rg.addColorStop(0, withAlpha(color, 0.4));
  rg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = rg;
  ctx.beginPath();
  ctx.ellipse(0, 26, 92, 26, 0, 0, Math.PI * 2);
  ctx.fill();

  // پاروها
  const row = Math.sin(timeSec * 3.4) * 0.5 * rowEnergy;
  for (const s of [-1, 1]) {
    ctx.save();
    ctx.translate(s * 26, 2);
    ctx.rotate(s * (0.62 + row));
    ctx.strokeStyle = 'rgba(203, 213, 225, 0.82)';
    ctx.lineWidth = 3.4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(s * 42, 12);
    ctx.stroke();
    ctx.fillStyle = 'rgba(148, 163, 184, 0.9)';
    ctx.beginPath();
    ctx.ellipse(s * 46, 13, 9, 4.6, s * 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // بدنه
  ctx.beginPath();
  ctx.moveTo(-58, 0);
  ctx.quadraticCurveTo(0, 40, 58, 0);
  ctx.quadraticCurveTo(0, 16, -58, 0);
  ctx.closePath();
  const hg = ctx.createLinearGradient(0, 0, 0, 32);
  hg.addColorStop(0, withAlpha(color, 0.95));
  hg.addColorStop(1, withAlpha(color, 0.35));
  ctx.fillStyle = hg;
  ctx.shadowColor = color;
  ctx.shadowBlur = 22;
  ctx.fill();
  ctx.shadowBlur = 0;

  // دکل و بادبان
  ctx.strokeStyle = 'rgba(226, 232, 240, 0.85)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 2);
  ctx.lineTo(0, -62);
  ctx.stroke();

  const sway = Math.sin(timeSec * 1.6) * 4;
  ctx.beginPath();
  ctx.moveTo(0, -60);
  ctx.quadraticCurveTo(34 + sway, -34, 2, -6);
  ctx.closePath();
  const sg = ctx.createLinearGradient(0, -60, 34, -6);
  sg.addColorStop(0, sailUp ? 'rgba(253, 230, 138, 0.96)' : 'rgba(148, 163, 184, 0.5)');
  sg.addColorStop(1, sailUp ? withAlpha(color, 0.72) : 'rgba(100, 116, 139, 0.28)');
  ctx.fillStyle = sg;
  if (sailUp) {
    ctx.shadowColor = color;
    ctx.shadowBlur = 20;
  }
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.restore();
}

export function drawSailOnly(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  color: string,
  timeSec: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.rotate(Math.sin(timeSec * 1.3) * 0.05);
  ctx.strokeStyle = 'rgba(226, 232, 240, 0.8)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 40);
  ctx.lineTo(0, -50);
  ctx.stroke();
  const sway = Math.sin(timeSec * 1.8) * 6;
  ctx.beginPath();
  ctx.moveTo(0, -48);
  ctx.quadraticCurveTo(40 + sway, -18, 2, 30);
  ctx.closePath();
  const sg = ctx.createLinearGradient(0, -48, 40, 30);
  sg.addColorStop(0, 'rgba(253, 230, 138, 0.95)');
  sg.addColorStop(1, withAlpha(color, 0.6));
  ctx.fillStyle = sg;
  ctx.shadowColor = color;
  ctx.shadowBlur = 24;
  ctx.fill();
  ctx.restore();
}

/* ═══════════ قطب‌نما و جهت ═══════════ */

export function drawCompass(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  needleAngle: number,
  accent: string,
  timeSec: number,
  jitter = 0,
) {
  ctx.save();
  ctx.translate(cx, cy);

  const g = ctx.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
  g.addColorStop(0, 'rgba(12, 20, 42, 0.94)');
  g.addColorStop(1, 'rgba(4, 8, 20, 0.98)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = withAlpha(accent, 0.7);
  ctx.lineWidth = 2.4;
  ctx.shadowColor = accent;
  ctx.shadowBlur = 18;
  ctx.stroke();
  ctx.shadowBlur = 0;

  ctx.strokeStyle = 'rgba(148, 163, 184, 0.24)';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.58, 0, Math.PI * 2);
  ctx.stroke();

  for (let i = 0; i < 36; i++) {
    const a = (i / 36) * Math.PI * 2;
    const long = i % 9 === 0;
    ctx.strokeStyle = long ? withAlpha(accent, 0.85) : 'rgba(203, 213, 225, 0.34)';
    ctx.lineWidth = long ? 2.4 : 1.2;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * r * (long ? 0.82 : 0.9), Math.sin(a) * r * (long ? 0.82 : 0.9));
    ctx.lineTo(Math.cos(a) * r * 0.97, Math.sin(a) * r * 0.97);
    ctx.stroke();
  }

  // عقربه
  ctx.save();
  ctx.rotate(needleAngle + Math.sin(timeSec * 9) * jitter);
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.72);
  ctx.lineTo(r * 0.1, 0);
  ctx.lineTo(0, r * 0.72);
  ctx.lineTo(-r * 0.1, 0);
  ctx.closePath();
  const ng = ctx.createLinearGradient(0, -r * 0.72, 0, r * 0.72);
  ng.addColorStop(0, '#fde68a');
  ng.addColorStop(0.5, accent);
  ng.addColorStop(1, 'rgba(251, 113, 133, 0.85)');
  ctx.fillStyle = ng;
  ctx.shadowColor = accent;
  ctx.shadowBlur = 20;
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.075, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ═══════════ انسان، قلب و ذهن ═══════════ */

export function drawFigure(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  color: string,
  walk: number,
  glow = true,
) {
  ctx.save();
  ctx.translate(x, y);
  const s = h / 100;
  ctx.scale(s, s);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  if (glow) {
    ctx.shadowColor = color;
    ctx.shadowBlur = 18;
  }
  ctx.beginPath();
  ctx.arc(0, -78, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(0, -66);
  ctx.lineTo(0, -22);
  ctx.stroke();
  const sw = Math.sin(walk) * 22;
  ctx.beginPath();
  ctx.moveTo(0, -56);
  ctx.lineTo(-18 + sw * 0.4, -34);
  ctx.moveTo(0, -56);
  ctx.lineTo(18 - sw * 0.4, -34);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -22);
  ctx.lineTo(-14 + sw, 0);
  ctx.moveTo(0, -22);
  ctx.lineTo(14 - sw, 0);
  ctx.stroke();
  ctx.restore();
}

export function drawHeart(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  color: string,
  beat: number,
  alpha = 1,
) {
  const s = 1 + beat * 0.16;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha *= alpha;
  ctx.beginPath();
  ctx.moveTo(0, r * 0.78);
  ctx.bezierCurveTo(-r * 1.25, -r * 0.1, -r * 0.62, -r * 1.1, 0, -r * 0.42);
  ctx.bezierCurveTo(r * 0.62, -r * 1.1, r * 1.25, -r * 0.1, 0, r * 0.78);
  ctx.closePath();
  const g = ctx.createRadialGradient(0, -r * 0.2, r * 0.1, 0, 0, r * 1.4);
  g.addColorStop(0, '#fff1f2');
  g.addColorStop(0.35, color);
  g.addColorStop(1, withAlpha(color, 0.28));
  ctx.fillStyle = g;
  ctx.shadowColor = color;
  ctx.shadowBlur = 26 * (0.6 + beat);
  ctx.fill();
  ctx.restore();
}

export function drawBrainMind(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  color: string,
  timeSec: number,
  charge: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = withAlpha(color, 0.85);
  ctx.lineWidth = 2.6;
  ctx.shadowColor = color;
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.arc(0, 0, r, Math.PI * 0.15, Math.PI * 1.85);
  ctx.stroke();
  for (let i = 0; i < 4; i++) {
    const rr = r * (0.78 - i * 0.17);
    const off = Math.sin(timeSec * 1.6 + i) * 4;
    ctx.beginPath();
    ctx.moveTo(-rr * 0.9, off);
    ctx.bezierCurveTo(-rr * 0.3, -rr * 0.55 + off, rr * 0.35, rr * 0.5 + off, rr * 0.9, off * 0.4);
    ctx.stroke();
  }
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + timeSec * 0.6;
    const rr = r * (0.4 + seeded(i) * 0.5);
    ctx.fillStyle = withAlpha('#fde68a', 0.35 + charge * 0.6);
    ctx.beginPath();
    ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr, 2.6 + charge * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/* ═══════════ نور، چراغ و نیروگاه ═══════════ */

export function drawLightBulb(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  lit: number,
  color: string,
  timeSec: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  if (lit > 0.02) {
    const g = ctx.createRadialGradient(0, -r * 0.1, r * 0.1, 0, 0, r * (3 + lit * 1.6));
    g.addColorStop(0, withAlpha('#fde68a', 0.42 * lit));
    g.addColorStop(0.4, withAlpha(color, 0.18 * lit));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r * (3 + lit * 1.6), 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = withAlpha('#fde68a', 0.5 * lit);
    ctx.lineWidth = 1.6;
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 + timeSec * 0.3;
      const l = r * (1.5 + lit * 0.9 + Math.sin(timeSec * 4 + i) * 0.1);
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r * 1.35, Math.sin(a) * r * 1.35);
      ctx.lineTo(Math.cos(a) * l, Math.sin(a) * l);
      ctx.stroke();
    }
  }
  ctx.beginPath();
  ctx.arc(0, -r * 0.16, r * 0.78, Math.PI * 0.85, Math.PI * 2.15);
  ctx.lineTo(r * 0.3, r * 0.6);
  ctx.lineTo(-r * 0.3, r * 0.6);
  ctx.closePath();
  const bg = ctx.createLinearGradient(0, -r, 0, r * 0.6);
  bg.addColorStop(0, withAlpha('#fde68a', 0.22 + lit * 0.72));
  bg.addColorStop(1, withAlpha(color, 0.14 + lit * 0.4));
  ctx.fillStyle = bg;
  ctx.shadowColor = withAlpha(color, 0.9);
  ctx.shadowBlur = 12 + lit * 34;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha(color, 0.85);
  ctx.lineWidth = 2.4;
  ctx.stroke();

  ctx.fillStyle = 'rgba(148, 163, 184, 0.9)';
  drawRoundedRect(ctx, -r * 0.28, r * 0.62, r * 0.56, r * 0.36, 4);
  ctx.fill();

  ctx.strokeStyle = withAlpha('#fde68a', 0.55 + lit * 0.45);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-r * 0.2, r * 0.4);
  ctx.lineTo(0, -r * 0.05);
  ctx.lineTo(r * 0.2, r * 0.4);
  ctx.stroke();
  ctx.restore();
}

export function drawPowerPlant(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  accent: string,
  timeSec: number,
  output: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);
  ctx.strokeStyle = withAlpha(accent, 0.8);
  ctx.fillStyle = 'rgba(8, 14, 32, 0.92)';
  ctx.lineWidth = 2.6;

  // دو برج خنک‌کننده
  for (const s of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(s * 16, 0);
    ctx.quadraticCurveTo(s * 30, -34, s * 22, -62);
    ctx.lineTo(s * 44, -62);
    ctx.quadraticCurveTo(s * 36, -34, s * 50, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // بدنهٔ مرکزی
  ctx.beginPath();
  ctx.rect(-22, -34, 44, 34);
  ctx.fill();
  ctx.stroke();

  // بخارِ نور
  for (let i = 0; i < 6; i++) {
    const p = ((timeSec * 0.35 + i / 6) % 1);
    const s = [-1, 1][i % 2];
    ctx.fillStyle = withAlpha('#fde68a', (1 - p) * 0.28 * (0.4 + output));
    ctx.beginPath();
    ctx.arc(s * 33 + Math.sin(p * 6 + i) * 7, -66 - p * 54, 6 + p * 16, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = withAlpha('#fde68a', 0.5 + output * 0.5);
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 14 * (0.4 + output);
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(-12 + i * 12, -18, 3.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawRadioWaves(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  timeSec: number,
  color: string,
  count = 5,
  maxR = 260,
  speed = 0.5,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  for (let i = 0; i < count; i++) {
    const p = (timeSec * speed + i / count) % 1;
    const r = p * maxR;
    ctx.strokeStyle = withAlpha(color, (1 - p) * 0.72);
    ctx.lineWidth = 2.6 * (1 - p * 0.5);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

/* ═══════════ دروازه، زنجیر، اثرِ قدم ═══════════ */

export function drawGate(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  w: number,
  h: number,
  openness: number,
  accent: string,
  label: string,
  index: number,
) {
  const o = clamp01(openness);
  ctx.save();
  ctx.translate(cx, cy);

  // قوس
  ctx.strokeStyle = withAlpha(accent, 0.75);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-w / 2, h / 2);
  ctx.lineTo(-w / 2, -h / 6);
  ctx.quadraticCurveTo(-w / 2, -h / 2, 0, -h / 2);
  ctx.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 6);
  ctx.lineTo(w / 2, h / 2);
  ctx.stroke();

  // نورِ داخلِ دروازه
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-w / 2 + 3, h / 2);
  ctx.lineTo(-w / 2 + 3, -h / 6);
  ctx.quadraticCurveTo(-w / 2 + 3, -h / 2 + 3, 0, -h / 2 + 3);
  ctx.quadraticCurveTo(w / 2 - 3, -h / 2 + 3, w / 2 - 3, -h / 6);
  ctx.lineTo(w / 2 - 3, h / 2);
  ctx.closePath();
  ctx.clip();
  const g = ctx.createLinearGradient(0, h / 2, 0, -h / 2);
  g.addColorStop(0, withAlpha(accent, 0.5 * o));
  g.addColorStop(0.6, withAlpha('#fde68a', 0.22 * o));
  g.addColorStop(1, 'rgba(3, 6, 16, 0.9)');
  ctx.fillStyle = g;
  ctx.fillRect(-w / 2, -h / 2, w, h);

  // لتهای در بسته
  const slats = 5;
  for (let i = 0; i < slats; i++) {
    const sy = -h / 2 + (i / slats) * h + (h / slats) * 0.5;
    const shrink = o * (w / 2);
    ctx.fillStyle = 'rgba(6, 11, 26, 0.94)';
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.28)';
    ctx.lineWidth = 1.2;
    drawRoundedRect(ctx, -w / 2 + shrink, sy - 6, w - shrink * 2, 12, 5);
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();

  ctx.font = `700 15px ${VZ}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = o > 0.5 ? '#fde68a' : 'rgba(203, 213, 225, 0.8)';
  ctx.fillText(label, 0, h / 2 + 24);
  ctx.font = `600 12px ${VZ}`;
  ctx.fillStyle = withAlpha(accent, 0.75);
  ctx.fillText(`دروازهٔ ${index}`, 0, -h / 2 - 20);
  ctx.restore();
}

export function drawFootprint(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rot: number,
  scale: number,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.01) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(scale, scale);
  ctx.globalAlpha *= alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(0, 0, 7, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(-5 + i * 3.4, -16 - (i === 1 || i === 2 ? 2 : 0), 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawChainLink(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rot: number,
  r: number,
  color: string,
  broken: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.strokeStyle = color;
  ctx.lineWidth = 4.4;
  ctx.lineCap = 'round';
  const gap = clamp01(broken) * 1.1;
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 1.5, r, 0, gap, Math.PI * 2 - gap);
  ctx.stroke();
  ctx.restore();
}

/* ═══════════ شکوفه، برگ، آینه ═══════════ */

export function drawFlower(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  bloom: number,
  color: string,
  rot: number,
) {
  const b = clamp01(bloom);
  if (b <= 0.01) return;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.scale(easeOutBack(b), easeOutBack(b));
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    ctx.save();
    ctx.rotate(a);
    const g = ctx.createLinearGradient(0, 0, 0, -r);
    g.addColorStop(0, withAlpha(color, 0.85));
    g.addColorStop(1, withAlpha('#fde68a', 0.28));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, -r * 0.58, r * 0.26, r * 0.56, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.fillStyle = '#fff7ed';
  ctx.shadowColor = color;
  ctx.shadowBlur = 18;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawLeaf(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  rot: number,
  color: string,
  alpha = 1,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.globalAlpha *= alpha;
  ctx.beginPath();
  ctx.moveTo(0, -r);
  ctx.quadraticCurveTo(r * 0.72, 0, 0, r);
  ctx.quadraticCurveTo(-r * 0.72, 0, 0, -r);
  ctx.closePath();
  const g = ctx.createLinearGradient(-r * 0.4, -r, r * 0.4, r);
  g.addColorStop(0, withAlpha(color, 0.9));
  g.addColorStop(1, withAlpha(color, 0.3));
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = 'rgba(240, 253, 244, 0.55)';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.9);
  ctx.lineTo(0, r * 0.9);
  ctx.stroke();
  ctx.restore();
}

export function drawMirror(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  shine: number,
  accent: string,
  timeSec: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.72, r, 0, 0, Math.PI * 2);
  const g = ctx.createLinearGradient(-r, -r, r, r);
  g.addColorStop(0, 'rgba(226, 240, 255, 0.16)');
  g.addColorStop(0.45, withAlpha(accent, 0.1));
  g.addColorStop(1, 'rgba(6, 11, 26, 0.85)');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = withAlpha(accent, 0.75);
  ctx.lineWidth = 3;
  ctx.shadowColor = accent;
  ctx.shadowBlur = 18;
  ctx.stroke();
  ctx.shadowBlur = 0;

  ctx.save();
  ctx.clip();
  const sx = lerp(-r * 1.4, r * 1.4, clamp01(shine));
  const sg = ctx.createLinearGradient(sx - 40, -r, sx + 40, r);
  sg.addColorStop(0, 'rgba(255,255,255,0)');
  sg.addColorStop(0.5, `rgba(255,255,255,${0.5 * Math.sin(clamp01(shine) * Math.PI)})`);
  sg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = sg;
  ctx.fillRect(-r, -r, r * 2, r * 2);
  ctx.restore();

  ctx.strokeStyle = withAlpha('#fde68a', 0.25 + 0.2 * Math.sin(timeSec * 2));
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.5, r * 0.74, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

export function drawWaveform(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  timeSec: number,
  color: string,
  amp: number,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 0; i <= w; i += 4) {
    const k = i / w;
    const yy =
      y +
      Math.sin(k * 22 + timeSec * 4) * amp * Math.sin(k * Math.PI) +
      Math.sin(k * 47 - timeSec * 6.5) * amp * 0.35 * Math.sin(k * Math.PI);
    if (i === 0) ctx.moveTo(x + i, yy);
    else ctx.lineTo(x + i, yy);
  }
  ctx.stroke();
  ctx.restore();
}

export function drawScissors(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  open: number,
  color: string,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.strokeStyle = color;
  ctx.lineWidth = 3.4;
  ctx.lineCap = 'round';
  const a = lerp(0.06, 0.5, clamp01(open));
  for (const s of [-1, 1]) {
    ctx.save();
    ctx.rotate(s * a);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -34);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(s * 7, 12, 8, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, 3.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** عددِ شمارنده با ارقامِ فارسی */
export function drawCounter(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  color: string,
  glow: string,
  progress: number,
) {
  const p = easeOutCubic(clamp01(progress));
  if (p <= 0.01) return;
  ctx.save();
  ctx.globalAlpha *= p;
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = glow;
  ctx.shadowBlur = 26;
  ctx.fillStyle = color;
  ctx.fillText(text, cx, cy + (1 - p) * 12);
  ctx.restore();
}
