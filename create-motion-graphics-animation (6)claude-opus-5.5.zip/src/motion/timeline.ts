/* ------------------------------------------------------------------
   timeline.ts — «فرکانسِ شکر» • منتخبِ ۵ دقیقه‌ای
   منبع: جلسهٔ سوم، بخشِ سوم (j 3-3.mp3 • ۱۹:۲۱) — استاد حاج نصرالله باستین
   ۹ برشِ صوتی با هم‌پوشانیِ ۰٫۳۵ ثانیه، نرمال‌سازیِ بلندی ‎-15 LUFS
   زمان‌بندی از رونویسیِ Whisper، متنِ زیرنویس از متنِ ویرایش‌شدهٔ جلسه
------------------------------------------------------------------ */

/** صوتِ برش‌خورده؛ در App با داده‌ی محلی جایگزین می‌شود */
export const AUDIO_URL = '';

export const TOTAL_DURATION = 300;
export const INTRO_CARD = 4.1;
export const OUTRO_LENGTH = 4.6;

export const SOURCE_CUTS: Array<{ from: string; to: string; label: string }> = [
  { from: '01:11', to: '01:43', label: 'شکرگزاری؛ نزدیک‌ترین فرکانس' },
  { from: '02:55', to: '03:29', label: 'تشت ← اقیانوس' },
  { from: '04:20', to: '04:40', label: 'احساسِ خوب = اتفاقِ خوب' },
  { from: '04:43', to: '05:41', label: 'مادرِ موسی' },
  { from: '07:29', to: '08:14', label: 'فانوسِ دریایی' },
  { from: '12:31', to: '13:08', label: 'بی‌سیم و صبر' },
  { from: '15:36', to: '16:10', label: 'یک قدم، ده قدم' },
  { from: '17:28', to: '17:50', label: 'ذهن مثلِ درخت' },
  { from: '18:42', to: '19:02', label: 'خدا ظالم نیست' },
];

export type SceneKey =
  | 'gratitude_frequency'
  | 'vessel_ocean'
  | 'good_feeling'
  | 'moses_mother'
  | 'lighthouse'
  | 'wireless_patience'
  | 'ten_steps'
  | 'mind_tree';

export interface MotionChapter {
  id: number;
  sceneKey: SceneKey;
  title: string;
  subtitle: string;
  badge: string;
  start: number;
  end: number;
  accent: string;
  accentSecondary: string;
  bgTop: string;
  bgBottom: string;
}

export interface CaptionCue {
  start: number;
  end: number;
  text: string;
  highlight?: boolean;
}

export const CHAPTERS: MotionChapter[] = [
  { id: 1, sceneKey: 'gratitude_frequency', title: 'نزدیک‌ترین فرکانس به خدا', subtitle: 'شکرگزاری تا ملکهٔ ذهن شود؛ برعکسِ آن، کفر و ناسپاسی', badge: 'فصل ۱', start: 0, end: 32.39, accent: '#fbbf24', accentSecondary: '#38bdf8', bgTop: '#060a18', bgBottom: '#0c1b33' },
  { id: 2, sceneKey: 'vessel_ocean', title: 'تشتی که اقیانوس می‌شود', subtitle: 'نعمت مثلِ باران همیشه هست؛ آنچه زیاد می‌شود ظرفیتِ ماست', badge: 'فصل ۲', start: 32.39, end: 66.98, accent: '#38bdf8', accentSecondary: '#fbbf24', bgTop: '#040c1c', bgBottom: '#092438' },
  { id: 3, sceneKey: 'good_feeling', title: 'اول به حسِ خوب برس', subtitle: 'احساسِ خوب با اتفاقِ خوب، احساسِ بد با اتفاقِ بد', badge: 'فصل ۳', start: 66.98, end: 86.17, accent: '#f472b6', accentSecondary: '#fbbf24', bgTop: '#120818', bgBottom: '#24112c' },
  { id: 4, sceneKey: 'moses_mother', title: 'مادرِ موسی و رودِ نیل', subtitle: 'نترس، غمگین مباش — توکل، بالاترین درجهٔ ایمان', badge: 'فصل ۴', start: 86.17, end: 144.56, accent: '#fbbf24', accentSecondary: '#22d3ee', bgTop: '#030a1a', bgBottom: '#0a2236' },
  { id: 5, sceneKey: 'lighthouse', title: 'فانوسِ دریایی', subtitle: 'ذهنِ پراکنده ← ذهنِ هم‌جهت با روح؛ مهارِ ذهن یعنی تقوا', badge: 'فصل ۵', start: 144.56, end: 189.65, accent: '#fde047', accentSecondary: '#60a5fa', bgTop: '#050a1c', bgBottom: '#0d1a33' },
  { id: 6, sceneKey: 'wireless_patience', title: 'بی‌سیم و صبر', subtitle: 'ارسال، پردازش، بازگشت؛ صبر یعنی زمانِ میانِ ارسال و رسیدن', badge: 'فصل ۶', start: 189.65, end: 226.84, accent: '#facc15', accentSecondary: '#22d3ee', bgTop: '#0a0f1e', bgBottom: '#101c2e' },
  { id: 7, sceneKey: 'ten_steps', title: 'یک قدم تو، ده قدم جهان', subtitle: 'جهان سیستمی است: ورودی، پردازش، خروجی', badge: 'فصل ۷', start: 226.84, end: 260.63, accent: '#34d399', accentSecondary: '#fbbf24', bgTop: '#051218', bgBottom: '#0b2622' },
  { id: 8, sceneKey: 'mind_tree', title: 'ذهن مثلِ درخت', subtitle: 'خاک، آب، نور، مراقبت ← میوه؛ خدا ظالم نیست', badge: 'فصل ۸', start: 260.63, end: 300, accent: '#a3e635', accentSecondary: '#fbbf24', bgTop: '#08120a', bgBottom: '#17240f' },
];

export const CAPTIONS: CaptionCue[] = [
  { start: 4.0, end: 7.2, text: 'آن‌قدر شکرگزاری کنیم تا ملکهٔ ذهن شود…' },
  { start: 7.2, end: 17.6, text: 'نزدیک‌ترین فرکانس به خداوند، فرکانسِ شکرگزاری است.', highlight: true },
  { start: 17.8, end: 20.7, text: 'و برعکسِ آن، کفر و ناسپاسی.' },
  { start: 20.7, end: 27.6, text: 'خداوند فرمود: «لَئِنْ شَکَرْتُمْ لَأَزِیدَنَّکُمْ»', highlight: true },
  { start: 27.7, end: 32.3, text: 'اگر شکر کنیم، خدا می‌افزاید…' },

  { start: 32.5, end: 36.9, text: 'چون توجهِ ما به سمتِ خدا می‌رود — این توجه خیلی مهم است.' },
  { start: 36.9, end: 40.1, text: 'رو به کمبود باشی، کمبود را تجربه می‌کنی.' },
  { start: 40.3, end: 43.5, text: 'رو به فراوانی باشی، نعمت‌ها بیشتر می‌شود.', highlight: true },
  { start: 43.5, end: 46.9, text: 'ما مثلِ تشتی هستیم؛ باران همیشه هست.' },
  { start: 46.9, end: 56.3, text: 'هرچه تشت وسیع‌تر شود: حوض، استخر، دریا… و اقیانوس می‌شود.', highlight: true },
  { start: 56.3, end: 62.6, text: 'باید ظرفِ وجودمان را بزرگ کنیم.' },
  { start: 62.7, end: 66.9, text: '«لَأَزِیدَنَّکُمْ» — یعنی وجودِ شما را می‌افزاییم.', highlight: true },

  { start: 67.1, end: 71.4, text: 'خلاصه: قبل از اینکه لباس بپوشی و سرِ کار بروی…' },
  { start: 71.4, end: 77.4, text: 'باید به یک احساسِ خوب برسی.', highlight: true },
  { start: 77.4, end: 86.1, text: 'احساسِ خوب با اتفاقاتِ خوب، و احساسِ بد با اتفاقاتِ بد همراه است.' },

  { start: 86.3, end: 94.3, text: 'اگر مادرِ موسی غم می‌خورد، ممکن بود فرزندش را از دست بدهد.', highlight: true },
  { start: 94.3, end: 102.3, text: '«حُزن» یعنی چه؟ یعنی احساسِ بد.' },
  { start: 102.3, end: 111.0, text: 'خیلی سخت است مادری فرزندِ شیرخوارش را به رود بسپارد…' },
  { start: 111.0, end: 119.1, text: 'اگر نمی‌توانست احساسش را کنترل کند، اتفاقِ بد می‌افتاد.' },
  { start: 119.1, end: 124.1, text: 'به خدا توکل کرد و رهایش کرد.', highlight: true },
  { start: 124.1, end: 139.9, text: 'به بالاترین درجهٔ ایمان رسید: اعتماد به خدا — و خدا کودک را به او برگرداند.', highlight: true },
  { start: 139.9, end: 144.5, text: 'این همان حُزن است؛ احساسِ بد که قرآن نکوهشش می‌کند.' },

  { start: 144.7, end: 147.2, text: 'مثلِ فانوسِ دریایی…', highlight: true },
  { start: 147.2, end: 153.4, text: 'چراغ‌هایی که در یک راستا قرار می‌گیرند تا کشتی را هدایت کنند.' },
  { start: 153.6, end: 165.7, text: 'از دور در دریا نمی‌بیند ساحل کجاست؛ این چراغ‌ها جهتش می‌دهند.' },
  { start: 165.9, end: 172.9, text: 'ذهنِ شما پراکنده است، دائم در اختلاف؛ هم‌جهت با خدا نیست.' },
  { start: 172.9, end: 178.9, text: 'مثلِ چراغ‌های دریا، ذهن باید هم‌جهت با خدا شود.' },
  { start: 178.9, end: 185.9, text: 'ذهن با روح هم‌جهت شود — این مهار را «تقوا» می‌گویند؛ کنترلِ ذهن.', highlight: true },
  { start: 185.9, end: 189.6, text: 'وقتی ذهن و روح هم‌جهت شدند، به هدف می‌رسی.' },

  { start: 189.8, end: 196.9, text: 'ما مثلِ یک بی‌سیم هستیم؛ پیام می‌فرستیم و پاسخ برمی‌گردد.', highlight: true },
  { start: 197.1, end: 203.1, text: 'اگر بی‌سیم خاموش باشد، پاسخ را دریافت نمی‌کنیم.' },
  { start: 203.1, end: 210.0, text: 'باید صبر کنیم تا پاسخ برسد.' },
  { start: 210.1, end: 216.0, text: 'صبر یعنی زمانِ رسیدن به هدف: تو فرکانس فرستادی، جهان پردازش می‌کند.', highlight: true },
  { start: 216.1, end: 219.9, text: 'پس دیگر عجله‌ای نیست، طمعی نیست…' },
  { start: 220.1, end: 223.0, text: 'غم و ترس و نگرانی نیست.' },
  { start: 223.1, end: 226.7, text: 'این زمان باید طی شود تا به هدف برسیم.', highlight: true },

  { start: 227.0, end: 230.8, text: 'به هدف نزدیک‌تر می‌شوید؛ درهای رحمتِ خدا باز می‌شود.' },
  { start: 231.0, end: 236.7, text: 'از عالمِ غیب کمک می‌رسد — دستانِ خدا.' },
  { start: 236.8, end: 240.7, text: 'یک قدم به سمتِ هدف برداری، هر روز تلاش کنی…' },
  { start: 240.8, end: 245.2, text: 'هدف ده قدم به سمتِ تو می‌آید!', highlight: true },
  { start: 245.3, end: 253.8, text: 'چون جهان سیستمی است: یک ورودی دارد، یک پردازش…' },
  { start: 253.9, end: 260.5, text: '…و یک خروجی. این قانون در کلِ عالم صادق است.', highlight: true },

  { start: 260.8, end: 266.6, text: 'ذهن مثلِ یک درخت است؛ اگر خاکِ خوبی داشته باشد…', highlight: true },
  { start: 266.7, end: 271.0, text: 'آبِ خوب، نورِ خوب و مراقبت…' },
  { start: 271.1, end: 276.7, text: 'از گرما و گرد و غبار حفظش کنیم.' },
  { start: 276.8, end: 282.0, text: 'این پردازش است؛ و خروجی‌اش میوهٔ خوب.' },
  { start: 282.2, end: 290.4, text: 'پس اگر اتفاقی دیدیم، چه مثبت چه منفی، بدانیم خداوند ظالم نیست.', highlight: true },
  { start: 290.6, end: 296.4, text: 'خودمان پیش فرستادیم؛ جهان به خودمان بازگرداند.', highlight: true },
];

export function getChapterAt(t: number): MotionChapter {
  for (const c of CHAPTERS) if (t >= c.start && t < c.end) return c;
  return t < CHAPTERS[0].start ? CHAPTERS[0] : CHAPTERS[CHAPTERS.length - 1];
}

export function getCaptionAt(t: number): CaptionCue | null {
  for (const c of CAPTIONS) if (t >= c.start && t < c.end) return c;
  return null;
}

export const FIVE_STEPS = ['شکرگزاری', 'حسِ خوب', 'توکل', 'هم‌جهتی', 'صبر'];
