/* ------------------------------------------------------------------
   renderer.ts — موتورِ اصلیِ رندرِ فریم‌های «جریانِ نور» (نسخهٔ ۲ دقیقه‌ای)
   فضای طراحی: ۱۲۸۰×۷۲۰ • خروجی: هر قطعیتی با حفظِ نسبت و پس‌زمینهٔ پیوسته
------------------------------------------------------------------ */
import {
  AR,
  VZ,
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  drawSacredMandala,
  drawSpectrumBars,
  drawStar8,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  lerpColor,
  toFaDigits,
  withAlpha,
} from './primitives';
import type { SceneFn } from './scenes1';
import {
  sceneGoodFeeling,
  sceneGratitudeFrequency,
  sceneLighthouse,
  sceneMindTree,
  sceneMosesMother,
  sceneTenSteps,
  sceneVesselOcean,
  sceneWirelessPatience,
} from './scenes3';
import {
  CHAPTERS,
  INTRO_CARD,
  OUTRO_LENGTH,
  TOTAL_DURATION,
  getChapterAt,
  type CaptionCue,
  type MotionChapter,
  type SceneKey,
} from './timeline';

export const VW = 1280;
export const VH = 720;

const SCENES: Record<SceneKey, SceneFn> = {
  gratitude_frequency: sceneGratitudeFrequency,
  vessel_ocean: sceneVesselOcean,
  good_feeling: sceneGoodFeeling,
  moses_mother: sceneMosesMother,
  lighthouse: sceneLighthouse,
  wireless_patience: sceneWirelessPatience,
  ten_steps: sceneTenSteps,
  mind_tree: sceneMindTree,
};

export interface RenderOptions {
  showSubtitles: boolean;
  showHud: boolean;
  captions: CaptionCue[];
  title?: string;
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, max: number, maxLines = 2): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width <= max) cur = test;
    else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, maxLines);
}

export interface Layout {
  scale: number;
  ox: number;
  oy: number;
}

export function computeLayout(w: number, h: number): Layout {
  const scale = Math.min(w / VW, h / VH);
  return { scale, ox: (w - VW * scale) / 2, oy: (h - VH * scale) / 2 };
}

export function drawMotionFrame(
  ctx: CanvasRenderingContext2D,
  t: number,
  w: number,
  h: number,
  energy: number,
  levels: Float32Array | number[] | undefined,
  opts: RenderOptions,
) {
  const ch = getChapterAt(t);
  const idx = CHAPTERS.findIndex((c) => c.id === ch.id);
  const next = CHAPTERS[Math.min(CHAPTERS.length - 1, idx + 1)];
  const toEnd = ch.end - t;
  const blend = toEnd < 2.2 && next.id !== ch.id ? easeInOutCubic(1 - toEnd / 2.2) : 0;

  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, w, h);
  if ('direction' in ctx) ctx.direction = 'rtl';

  /* ---------- پس‌زمینهٔ پیوسته در فضای دستگاه ---------- */
  const bg = ctx.createLinearGradient(0, 0, w * 0.35, h);
  bg.addColorStop(0, lerpColor(ch.bgTop, next.bgTop, blend));
  bg.addColorStop(1, lerpColor(ch.bgBottom, next.bgBottom, blend));
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  const accent = blend > 0.5 ? next.accent : ch.accent;
  const accent2 = blend > 0.5 ? next.accentSecondary : ch.accentSecondary;

  const L = computeLayout(w, h);

  const rad = ctx.createRadialGradient(w * 0.5, h * 0.46, 20, w * 0.5, h * 0.46, Math.max(w, h) * 0.72);
  rad.addColorStop(0, withAlpha(accent, 0.13 + energy * 0.1));
  rad.addColorStop(0.55, withAlpha(accent2, 0.045));
  rad.addColorStop(1, 'rgba(3, 6, 18, 0.78)');
  ctx.fillStyle = rad;
  ctx.fillRect(0, 0, w, h);

  ctx.save();
  ctx.translate(L.ox, L.oy);
  ctx.scale(L.scale, L.scale);

  // ماندالای هندسی و ذراتِ کیهانی در پس‌زمینه
  drawSacredMandala(ctx, 640, 352, 322, t * 0.032, accent, 0.062);
  drawSacredMandala(ctx, 640, 352, 212, -t * 0.048, accent2, 0.052);
  drawCosmicParticles(ctx, VW, VH, t, accent, energy, 70);

  /* ---------- صحنهٔ اختصاصیِ فصل ---------- */
  const local = Math.max(0, t - ch.start);
  const fadeIn = clamp01(local / 0.75);
  const fadeOut = toEnd < 0.7 && next.id !== ch.id ? clamp01(toEnd / 0.7) : 1;
  ctx.save();
  ctx.globalAlpha = Math.min(fadeIn, fadeOut);
  SCENES[ch.sceneKey](ctx, local, ch.end - ch.start, t, energy, ch.accent, ch.accentSecondary);
  ctx.restore();

  // فلشِ انتقالِ فصل
  if (local < 0.5 && idx > 0) {
    ctx.save();
    ctx.globalAlpha = (1 - local / 0.5) * 0.28;
    ctx.fillStyle = ch.accent;
    ctx.fillRect(0, 0, VW, VH);
    ctx.restore();
  }
  ctx.restore();

  /* ---------- وینیتِ سینمایی + دانهٔ فیلم ---------- */
  const vig = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.24, w / 2, h / 2, Math.max(w, h) * 0.74);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(2, 4, 12, 0.74)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, w, h);

  ctx.save();
  ctx.globalAlpha = 0.05;
  ctx.globalCompositeOperation = 'overlay';
  const gn = 3;
  for (let i = 0; i < 120; i++) {
    const gx = ((i * 977.13 + t * 613.7) % w + w) % w;
    const gy = ((i * 613.71 + t * 977.3) % h + h) % h;
    ctx.fillStyle = i % 2 ? '#fff' : '#000';
    ctx.fillRect(gx, gy, gn, gn);
  }
  ctx.restore();

  ctx.save();
  ctx.translate(L.ox, L.oy);
  ctx.scale(L.scale, L.scale);

  /* ---------- کارتِ آغازین ---------- */
  if (t < INTRO_CARD) {
    const al = t < INTRO_CARD - 1.1 ? 1 : 1 - clamp01((t - (INTRO_CARD - 1.1)) / 1.1);
    const pop = easeOutBack(clamp01(t / 0.8));
    ctx.save();
    ctx.globalAlpha = al;
    ctx.fillStyle = 'rgba(4, 7, 18, 0.97)';
    ctx.fillRect(0, 0, VW, VH);
    ctx.translate(640, 330);
    ctx.scale(pop, pop);
    drawSacredMandala(ctx, 0, 0, 226, t * 0.5, '#fbbf24', 0.24);
    drawSacredMandala(ctx, 0, 0, 148, -t * 0.38, '#38bdf8', 0.17);
    drawStar8(ctx, 0, -186, 13, '#fde68a', t * 1.4, true, 0.9);
    drawGlowingText(ctx, 'فرکانسِ شکر', 0, -66, `900 86px ${VZ}`, '#fde68a', 'rgba(251,191,36,0.72)', 36);
    drawGlowingText(
      ctx,
      'منتخبِ سخنانِ استاد حاج نصرالله باستین',
      0,
      18,
      `700 25px ${VZ}`,
      '#e2e8f0',
      'rgba(56,189,248,0.45)',
      14,
    );
    drawGlowingText(
      ctx,
      'موشن گرافیکِ المان‌محور • ۸ فصل • ۰۵:۰۰',
      0,
      62,
      `500 17px ${VZ}`,
      '#94a3b8',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  /* ---------- تیتراژِ پایانی ---------- */
  const outroStart = TOTAL_DURATION - OUTRO_LENGTH;
  if (t > outroStart) {
    const cp = easeOutCubic(clamp01((t - outroStart) / 2));
    ctx.save();
    ctx.globalAlpha = cp * 0.98;
    ctx.fillStyle = 'rgba(4, 8, 18, 0.97)';
    ctx.fillRect(0, 0, VW, VH);
    drawSacredMandala(ctx, 640, 292, 234, t * 0.16, '#fbbf24', 0.24 * cp);
    drawSacredMandala(ctx, 640, 292, 156, -t * 0.24, '#34d399', 0.2 * cp);
    drawStar8(ctx, 640, 292, 26 + energy * 12, '#fde68a', t * 0.6, true, cp);
    drawGlowingText(
      ctx,
      'شکر ← حسِ خوب ← توکل ← هم‌جهتی ← صبر',
      640,
      434,
      `900 44px ${VZ}`,
      '#fde68a',
      'rgba(251,191,36,0.65)',
      26,
    );
    drawGlowingText(
      ctx,
      'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ',
      640,
      500,
      `700 31px ${AR}`,
      '#bbf7d0',
      'rgba(52,211,153,0.52)',
      18,
    );
    drawGlowingText(
      ctx,
      'منتخبِ ۵ دقیقه از جلسهٔ سوم • شکرگزاری، فرکانسِ خدا و سیستمِ جهان',
      640,
      562,
      `600 18px ${VZ}`,
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
    drawGlowingText(
      ctx,
      'استاد حاج نصرالله باستین • موشن گرافیکِ المان‌محور',
      640,
      608,
      `400 14px ${VZ}`,
      'rgba(148,163,184,0.85)',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  /* ---------- HUD ---------- */
  if (opts.showHud) {
    const top = ctx.createLinearGradient(0, 0, 0, 86);
    top.addColorStop(0, 'rgba(4, 7, 18, 0.86)');
    top.addColorStop(1, 'rgba(4, 7, 18, 0)');
    ctx.fillStyle = top;
    ctx.fillRect(0, 0, VW, 86);

    ctx.save();
    ctx.font = `700 16px ${VZ}`;
    const label = `فصل ${toFaDigits(ch.id)}  •  ${ch.title}`;
    const bw = Math.min(680, ctx.measureText(label).width + 56);
    drawRoundedRect(ctx, VW - bw - 32, 20, bw, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.84)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(ch.accent, 0.65);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.fillStyle = ch.accent;
    ctx.shadowColor = ch.accent;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(VW - 50, 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f1f5f9';
    ctx.fillText(label, VW - 66, 41);
    ctx.restore();

    ctx.save();
    drawRoundedRect(ctx, 32, 20, 182, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.84)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.34)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = `700 15px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(t)} / ${formatTimeFa(TOTAL_DURATION)}`, 123, 41);
    ctx.restore();

    drawSpectrumBars(ctx, 320, 60, 26, 190, t, energy, ch.accent, 0.55, levels);

    const pct = clamp01(t / TOTAL_DURATION);
    ctx.fillStyle = 'rgba(255,255,255,0.09)';
    ctx.fillRect(0, 0, VW, 5);
    const bar = ctx.createLinearGradient(VW, 0, 0, 0);
    bar.addColorStop(0, ch.accent);
    bar.addColorStop(1, ch.accentSecondary);
    ctx.fillStyle = bar;
    ctx.fillRect(VW * (1 - pct), 0, VW * pct, 5);
    CHAPTERS.forEach((c) => {
      ctx.fillStyle = 'rgba(2, 6, 16, 0.9)';
      ctx.fillRect(VW * (1 - c.start / TOTAL_DURATION) - 1, 0, 2, 5);
    });

    ctx.font = `600 13px ${VZ}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(203, 213, 225, 0.78)';
    ctx.fillText(`فصل ${toFaDigits(ch.id)} از ${toFaDigits(CHAPTERS.length)}`, 32, 78);
  }

  /* ---------- زیرنویسِ همگامِ فارسی ---------- */
  if (opts.showSubtitles && t >= INTRO_CARD - 0.2 && t <= TOTAL_DURATION - OUTRO_LENGTH + 1.5) {
    let cue: CaptionCue | null = null;
    for (const c of opts.captions) if (t >= c.start && t < c.end) cue = c;
    if (cue) {
      const cp = clamp01((t - cue.start) / 0.4);
      const op = clamp01((cue.end - t) / 0.3);
      ctx.save();
      ctx.globalAlpha = easeOutCubic(cp) * op;
      ctx.translate(0, (1 - easeOutCubic(cp)) * 16);
      ctx.font = `600 22px ${VZ}`;
      const lines = wrapLines(ctx, cue.text, 940);
      const boxH = lines.length === 2 ? 82 : 54;
      const boxY = VH - boxH - 12;
      const boxW = Math.min(1080, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 78);
      const boxX = (VW - boxW) / 2;
      drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 18);
      ctx.fillStyle = 'rgba(5, 9, 22, 0.9)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(ch.accent, 0.52);
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = ch.accent;
      ctx.fillRect(boxX + boxW - 4, boxY + 12, 4, boxH - 24);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.65)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = cue.highlight ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      else {
        ctx.fillText(lines[0], 640, boxY + 26);
        ctx.fillText(lines[1], 640, boxY + 56);
      }
      ctx.restore();
    }
  }

  ctx.restore();
  ctx.restore();
}

/** بندانگشتیِ فصل برای نوارِ تایم‌لاین */
export function drawChapterThumb(ctx: CanvasRenderingContext2D, ch: MotionChapter, w: number, h: number) {
  const sampleT = Math.max(INTRO_CARD + 0.4, ch.start + (ch.end - ch.start) * 0.62);
  drawMotionFrame(ctx, sampleT, w, h, 0.3, undefined, {
    showSubtitles: false,
    showHud: false,
    captions: [],
  });
}
