/* ------------------------------------------------------------------
   uploader.ts — انتشارِ فایلِ خروجی روی سرویس‌های عمومی
   tmpfiles.org و gofile.io (هر دو CORS باز دارند، پس آپلود از مرورگرِ
   شما انجام می‌شود و فایل هیچ‌گاه به سرورِ واسطه نمی‌رود)
------------------------------------------------------------------ */

export type Host = 'tmpfiles.org' | 'gofile.io';

export interface HostedLink {
  host: Host;
  pageUrl: string;
  directUrl: string | null;
  note: string;
  sizeMB: number;
}

export type UploadProgress = (percent: number, loadedMB: number, totalMB: number) => void;

function postForm(
  url: string,
  file: Blob,
  filename: string,
  onProgress?: UploadProgress,
  headers?: Record<string, string>,
) {
  return new Promise<{ status: number; text: string }>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.append('file', file, filename);
    xhr.open('POST', url, true);
    Object.entries(headers ?? {}).forEach(([k, v]) => xhr.setRequestHeader(k, v));
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        onProgress?.((e.loaded / e.total) * 100, e.loaded / 1048576, e.total / 1048576);
      }
    };
    xhr.onload = () => resolve({ status: xhr.status, text: xhr.responseText });
    xhr.onerror = () => reject(new Error('خطای شبکه در ارسالِ فایل (قطعیِ اینترنت یا مسدود بودنِ CORS).'));
    xhr.ontimeout = () => reject(new Error('زمانِ ارسالِ فایل به پایان رسید.'));
    xhr.timeout = 20 * 60 * 1000;
    xhr.send(form);
  });
}

export async function uploadToTmpfiles(
  blob: Blob,
  filename: string,
  onProgress?: UploadProgress,
): Promise<HostedLink> {
  const res = await postForm('https://tmpfiles.org/api/v1/upload', blob, filename, onProgress);
  let json: { status?: string; data?: { url?: string } } = {};
  try {
    json = JSON.parse(res.text);
  } catch {
    /* پاسخ غیرِ JSON */
  }
  if (res.status !== 200 || json.status !== 'success' || !json.data?.url) {
    throw new Error(`tmpfiles.org پاسخِ موفق نداد (کد ${res.status}).`);
  }
  const page = json.data.url;
  // لینکِ مستقیمِ tmpfiles امضای زمان‌دار دارد و فقط داخلِ صفحه ساخته می‌شود
  const direct: string | null = null;
  return {
    host: 'tmpfiles.org',
    pageUrl: page,
    directUrl: direct,
    note: 'صفحه را باز کنید و Download را بزنید • نگه‌داری حدودِ ۶۰ دقیقه',
    sizeMB: blob.size / 1048576,
  };
}

async function gofileGuestToken(): Promise<string | null> {
  try {
    const r = await fetch('https://api.gofile.io/accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const j = (await r.json()) as { status?: string; data?: { token?: string } };
    return j.data?.token ?? null;
  } catch {
    return null;
  }
}

export async function uploadToGofile(
  blob: Blob,
  filename: string,
  onProgress?: UploadProgress,
): Promise<HostedLink> {
  let server: string | undefined;
  try {
    const serversRes = await fetch('https://api.gofile.io/servers');
    const serversJson = (await serversRes.json()) as { data?: { servers?: Array<{ name: string }> } };
    server = serversJson.data?.servers?.[0]?.name;
  } catch {
    server = undefined;
  }
  if (!server) throw new Error('gofile.io سرورِ آپلودی در اختیار نگذاشت.');

  const token = await gofileGuestToken();
  const url = `https://${server}.gofile.io/contents/uploadfile`;
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await postForm(url, blob, filename, onProgress, headers);
  let json: {
    status?: string;
    data?: { downloadPage?: string; directLink?: string; code?: string };
  } = {};
  try {
    json = JSON.parse(res.text);
  } catch {
    /* noop */
  }
  if (json.status !== 'ok' || !json.data?.downloadPage) {
    throw new Error(`gofile.io آپلود را نپذیرفت (${json.status ?? 'HTTP ' + res.status}).`);
  }
  return {
    host: 'gofile.io',
    pageUrl: json.data.downloadPage,
    directUrl: json.data.directLink ?? null,
    note: json.data.code ? `کدِ دسترسیِ پوشه: ${json.data.code}` : 'صفحهٔ دانلودِ gofile.io آماده است.',
    sizeMB: blob.size / 1048576,
  };
}

export async function uploadTo(host: Host, blob: Blob, filename: string, onProgress?: UploadProgress) {
  return host === 'tmpfiles.org'
    ? uploadToTmpfiles(blob, filename, onProgress)
    : uploadToGofile(blob, filename, onProgress);
}
