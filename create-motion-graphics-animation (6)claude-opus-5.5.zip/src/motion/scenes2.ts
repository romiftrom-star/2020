/* ------------------------------------------------------------------
   scenes2.ts — صحنه‌های المان‌محورِ فصل ۵ تا ۸
------------------------------------------------------------------ */
import {
  AR,
  VZ,
  clamp01,
  drawArcProgress,
  drawAudioAuraRing,
  drawGlowingText,
  drawGrowingPath,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawSacredMandala,
  drawStar8,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  span,
  withAlpha,
} from './primitives';
import {
  drawCompass,
  drawCounter,
  drawFigure,
  drawFootprint,
  drawGate,
  drawLightBulb,
  drawPopText,
  drawPowerPlant,
  drawRadioWaves,
  drawStaggerWords,
  drawWaterWaves,
  drawWaveform,
  drawWipeText,
} from './fx';
import { drawFlowPulse } from './primitives';
import type { SceneFn } from './scenes1';
import { FIVE_STEPS } from './timeline';

/* ══════════ اسبِ چموش — المانِ تصویرسازی‌شده ══════════ */
function drawHorse(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  gallop: number,
  color: string,
  tame: number,
  timeSec: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * (gallop > 0 ? 1 : 1), scale);
  const run = Math.sin(gallop) * (1 - tame * 0.75);
  const bounce = Math.abs(Math.cos(gallop)) * 12 * (1 - tame * 0.8);
  ctx.translate(0, -bounce);
  ctx.rotate(run * 0.05);

  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 9;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.shadowColor = color;
  ctx.shadowBlur = 22;

  // بدن
  ctx.beginPath();
  ctx.ellipse(0, -58, 62, 26, 0.06, 0, Math.PI * 2);
  ctx.globalAlpha = 0.9;
  ctx.fill();
  ctx.globalAlpha = 1;

  // گردن و سر
  ctx.beginPath();
  ctx.moveTo(46, -70);
  ctx.quadraticCurveTo(76, -104, 92, -128);
  ctx.lineWidth = 17;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(88, -124);
  ctx.quadraticCurveTo(116, -132, 124, -122);
  ctx.quadraticCurveTo(112, -112, 90, -112);
  ctx.closePath();
  ctx.fill();
  // گوش
  ctx.beginPath();
  ctx.moveTo(94, -130);
  ctx.lineTo(98, -146);
  ctx.lineTo(104, -130);
  ctx.closePath();
  ctx.fill();

  // یال
  ctx.lineWidth = 5;
  ctx.strokeStyle = withAlpha('#fde68a', 0.72);
  for (let i = 0; i < 7; i++) {
    const k = i / 6;
    const sx = lerp(44, 88, k);
    const sy = lerp(-72, -126, k);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.quadraticCurveTo(sx - 22 - Math.sin(timeSec * 6 + i) * 8, sy + 8, sx - 34 - run * 16, sy + 26 + k * 8);
    ctx.stroke();
  }

  // دم
  ctx.strokeStyle = withAlpha('#fde68a', 0.6);
  ctx.lineWidth = 6;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(-58, -62 + i * 4);
    ctx.quadraticCurveTo(-92 - i * 6, -54 + i * 12 + Math.sin(timeSec * 5 + i) * 8, -108 - i * 8, -30 + i * 16 - run * 20);
    ctx.stroke();
  }

  // چهار پا با گامِ دو‌ضرب
  ctx.strokeStyle = color;
  ctx.lineWidth = 8;
  const legs: Array<[number, number, number]> = [
    [34, -44, 0],
    [46, -44, Math.PI],
    [-34, -44, Math.PI * 0.5],
    [-46, -44, Math.PI * 1.5],
  ];
  legs.forEach(([lx, ly, ph]) => {
    const sw = Math.sin(gallop + ph) * (1 - tame * 0.7);
    const knee = lx + sw * 20;
    const hoof = lx + sw * 36;
    const lift = Math.max(0, Math.cos(gallop + ph)) * 18 * (1 - tame * 0.6);
    ctx.beginPath();
    ctx.moveTo(lx, ly);
    ctx.quadraticCurveTo(knee, ly + 26 - lift * 0.4, hoof, ly + 52 - lift);
    ctx.stroke();
    ctx.fillStyle = withAlpha('#fde68a', 0.5);
    ctx.beginPath();
    ctx.arc(hoof, ly + 54 - lift, 4.4, 0, Math.PI * 2);
    ctx.fill();
  });

  // افسار
  ctx.strokeStyle = withAlpha('#fde68a', 0.55 + tame * 0.45);
  ctx.lineWidth = 2.6;
  ctx.setLineDash([6, 5]);
  ctx.beginPath();
  ctx.moveTo(112, -120);
  ctx.quadraticCurveTo(40, -104 - tame * 20, -60, -96 - tame * 26);
  ctx.stroke();
  ctx.setLineDash([]);

  // چشم
  ctx.fillStyle = '#04060e';
  ctx.beginPath();
  ctx.arc(104, -122, 2.8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ══════════ ۵ — اسبِ چموش و قطب‌نمای درون ══════════ */
export const sceneHorseCompass: SceneFn = (ctx, t, d, g, e, a, b) => {
  const tame = easeInOutCubic(span(t, 4.2, 11));
  const gallopSpeed = lerp(9.5, 1.4, tame);

  // زمینِ شنیِ روان
  ctx.save();
  const ground = ctx.createLinearGradient(0, 430, 0, 560);
  ground.addColorStop(0, withAlpha(a, 0.14));
  ground.addColorStop(1, 'rgba(2,5,14,0)');
  ctx.fillStyle = ground;
  ctx.fillRect(0, 430, 1280, 130);
  ctx.strokeStyle = withAlpha(a, 0.34);
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let x = 0; x <= 1280; x += 10) {
    const yy = 432 + Math.sin(x * 0.014 + g * 1.4) * 5;
    if (x === 0) ctx.moveTo(x, yy);
    else ctx.lineTo(x, yy);
  }
  ctx.stroke();
  ctx.restore();

  // گرد و غبارِ سم
  for (let i = 0; i < 10; i++) {
    const p = ((g * (1.6 - tame) + i / 10) % 1);
    ctx.fillStyle = withAlpha('#fde68a', (1 - p) * 0.16 * (1 - tame * 0.7));
    ctx.beginPath();
    ctx.arc(300 - p * 210 - i * 6, 452 - p * 24 + Math.sin(i) * 8, 5 + p * 22, 0, Math.PI * 2);
    ctx.fill();
  }

  drawHorse(ctx, 372, 420, 1.02, g * gallopSpeed, tame > 0.55 ? a : b, tame, g);

  drawWipeText(ctx, 'مهارِ اسبِ چموشِ ذهن', 640, 116, `800 38px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.5) / 1.5);
  drawKineticPill(ctx, 320, 176, 'تقوا = مهارِ افسار', (t - 2.2) / 1.1, b, '✦', 0.94, 17);
  drawKineticPill(ctx, 962, 176, 'احساسِ خوب = قطب‌نما', (t - 6.6) / 1.1, a, '✧', 0.94, 17);

  // قطب‌نمای بزرگ در سمتِ چپِ بالا
  const cP = easeOutBack(span(t, 1.6, 3));
  if (cP > 0.01) {
    ctx.save();
    ctx.globalAlpha = cP;
    const jitter = lerp(0.5, 0.02, tame);
    const wob = Math.sin(g * 2.6) * jitter + Math.sin(g * 7.3) * jitter * 0.4;
    drawCompass(ctx, 1046, 330, 92 * cP, -Math.PI / 2 + wob + (1 - tame) * 1.5, a, g, jitter * 0.5);
    ctx.restore();
    drawGlowingText(ctx, 'قطب‌نمای درون', 1046, 452, `800 20px ${VZ}`, '#fde68a', withAlpha(a, 0.6), 14);
    drawGlowingText(
      ctx,
      tame > 0.6 ? 'آرام — در صراطِ مستقیم' : 'منحرف — از صراط بیرون',
      1046,
      478,
      `600 15px ${VZ}`,
      tame > 0.6 ? '#bbf7d0' : '#fecaca',
      'rgba(0,0,0,0)',
      0,
    );
  }

  // گِیجِ اضطراب ← آرامش
  ctx.save();
  ctx.translate(700, 350);
  drawArcProgress(ctx, 0, 0, 74, 1 - tame, '#fb7185', 8, Math.PI * 0.8, Math.PI * 1.4);
  drawArcProgress(ctx, 0, 0, 74, tame, a, 8, Math.PI * 0.8, Math.PI * 1.4);
  drawGlowingText(ctx, 'اضطراب', -86, 52, `600 14px ${VZ}`, 'rgba(254,202,202,0.85)', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'آرامش', 86, 52, `600 14px ${VZ}`, 'rgba(187,247,208,0.9)', 'rgba(0,0,0,0)', 0);
  drawCounter(
    ctx,
    `${String(Math.round(tame * 100)).replace(/\d/g, (x) => '۰۱۲۳۴۵۶۷۸۹'[Number(x)])}٪`,
    0,
    -4,
    `900 30px ${VZ}`,
    '#fff7ed',
    withAlpha(a, 0.6),
    span(t, 2, 3),
  );
  drawGlowingText(ctx, 'هم‌جهتی با روح', 0, 26, `500 13px ${VZ}`, 'rgba(203,213,225,0.75)', 'rgba(0,0,0,0)', 0);
  ctx.restore();

  // ضربانِ قلب هنگامِ آرامش
  if (tame > 0.5) {
    drawAudioAuraRing(ctx, 700, 350, 104, g, (tame - 0.5) * (0.6 + e), a);
  }

  drawVerseCard(ctx, 640, 522, 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ', 'با یادِ خدا دل‌ها آرام می‌گیرد', 'سورهٔ رعد • آیهٔ ۲۸', (t - 8.6) / 1.3, a, 760);
  void d;
};

/* ══════════ ۶ — پنج دروازهٔ ذهن و خطواتِ شیطان ══════════ */
const GATES = ['چشم', 'گوش', 'زبان', 'گذشته', 'آینده'];

export const sceneGatesFootsteps: SceneFn = (ctx, t, d, g, e, a, b) => {
  drawWipeText(ctx, 'پنج دروازهٔ ذهن', 640, 104, `800 36px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.4) / 1.4);
  drawGlowingText(ctx, 'هر ورودی را که دل را مکدر می‌کند، ببند', 640, 144, `500 15px ${VZ}`, 'rgba(226,232,240,0.85)', 'rgba(0,0,0,0)', 0);

  // ردیفِ پنج دروازه
  const gateY = 262;
  const gateW = 104;
  const gateH = 120;
  GATES.forEach((label, i) => {
    const gx = 640 + (i - 2) * 152;
    const open = span(t, 1 + i * 0.42, 2 + i * 0.42);
    const close = span(t, 5.4 + i * 0.3, 6.6 + i * 0.3);
    const openness = open * (1 - close);
    // نشتِ نور به بیرون
    if (openness > 0.05) {
      const leak = ctx.createRadialGradient(gx, gateY, 4, gx, gateY, 120);
      leak.addColorStop(0, withAlpha(b, 0.26 * openness));
      leak.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = leak;
      ctx.beginPath();
      ctx.arc(gx, gateY, 120, 0, Math.PI * 2);
      ctx.fill();
    }
    drawGate(ctx, gx, gateY, gateW, gateH, openness, close > 0.5 ? b : a, label, i + 1);
    if (close > 0.85) {
      drawStar8(ctx, gx, gateY - gateH / 2 - 26, 8, b, g * 0.9 + i, true, (close - 0.85) / 0.15);
    }
  });

  // سایهٔ وسوسه که نزدیک می‌شود و با نور پس زده می‌شود
  const creep = easeInOutCubic(span(t, 2.2, 6));
  const repel = easeOutCubic(span(t, 7.4, 9.2));
  const sx = lerp(-40, 300, creep) + repel * -360;
  ctx.save();
  ctx.globalAlpha = (0.62 * creep) * (1 - repel);
  const sh = ctx.createRadialGradient(sx, 268, 6, sx, 268, 130);
  sh.addColorStop(0, 'rgba(190, 24, 60, 0.55)');
  sh.addColorStop(0.6, 'rgba(76, 5, 25, 0.28)');
  sh.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sh;
  ctx.beginPath();
  ctx.ellipse(sx, 262, 116, 92, Math.sin(g) * 0.12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // مسیرِ خطا با اثرِ قدم‌های شیطان
  const path: Array<[number, number]> = [
    [1180, 470],
    [1010, 424],
    [840, 482],
    [670, 420],
    [500, 478],
    [330, 424],
    [180, 470],
  ];
  const pathP = easeOutQuint(span(t, 3, 8));
  drawGrowingPath(ctx, path, pathP, withAlpha(a, 0.55), 2.6, [9, 9]);

  for (let i = 0; i < 16; i++) {
    const k = i / 15;
    if (k > pathP) break;
    const seg = Math.min(path.length - 2, Math.floor(k * (path.length - 1)));
    const local = k * (path.length - 1) - seg;
    const fx0 = lerp(path[seg][0], path[seg + 1][0], local);
    const fy0 = lerp(path[seg][1], path[seg + 1][1], local);
    const erased = easeOutCubic(span(t, 9.4 + i * 0.12, 10.6 + i * 0.12));
    drawFootprint(
      ctx,
      fx0,
      fy0,
      Math.sin(i * 1.3) * 0.4 + (i % 2 ? 0.3 : -0.3),
      0.85 + seeded(i) * 0.3,
      erased > 0 ? withAlpha(b, 0.8) : '#fb7185',
      (1 - erased) * 0.85,
    );
  }

  // جاروی نور که قدم‌ها را پاک می‌کند
  const sweepP = span(t, 9.2, 12.4);
  if (sweepP > 0 && sweepP < 1) {
    const swx = lerp(1220, 140, easeInOutCubic(sweepP));
    ctx.save();
    const sw = ctx.createLinearGradient(swx - 90, 0, swx + 90, 0);
    sw.addColorStop(0, 'rgba(253,230,138,0)');
    sw.addColorStop(0.5, withAlpha(b, 0.5));
    sw.addColorStop(1, 'rgba(253,230,138,0)');
    ctx.fillStyle = sw;
    ctx.fillRect(swx - 90, 388, 180, 130);
    ctx.restore();
  }

  // برچسب‌های پکیجِ شیطان که خط می‌خورند
  const tags = ['خشم', 'مقایسه', 'عجله', 'غیبت', 'خودبرتربینی'];
  tags.forEach((tag, i) => {
    const p = (t - 1.8 - i * 0.55) / 0.9;
    const kill = easeOutCubic(span(t, 8 + i * 0.24, 9 + i * 0.24));
    if (p <= 0) return;
    const tx = 288 + i * 176;
    const ty = 396;
    ctx.save();
    ctx.globalAlpha = clamp01(p * 1.6) * (1 - kill * 0.72);
    drawKineticPill(ctx, tx, ty, tag, p, '#fb7185', '✕', 0.86, 15);
    if (kill > 0) {
      ctx.strokeStyle = withAlpha('#fde68a', kill);
      ctx.lineWidth = 2.6;
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(tx - 62 + (1 - kill) * 124, ty);
      ctx.lineTo(tx + 62, ty);
      ctx.stroke();
    }
    ctx.restore();
  });

  drawAudioAuraRing(ctx, 640, 262, 214, g, e * 0.5, b);
  drawVerseCard(ctx, 640, 548, 'وَلَا تَتَّبِعُوا خُطُوَاتِ الشَّيْطَانِ', 'از گام‌های شیطان پیروی نکنید', 'سورهٔ نور • آیهٔ ۲۱', (t - 10.8) / 1.2, a, 720);
  void d;
};

/* ══════════ ۷ — قانونِ دقیقِ جهان؛ لامپ و نیروگاه ══════════ */
export const sceneLampPowerplant: SceneFn = (ctx, t, d, g, e, a, b) => {
  drawWipeText(ctx, 'سیستمِ قانونمندِ جهان', 640, 112, `800 38px ${VZ}`, '#fde68a', withAlpha(a, 0.6), (t - 0.4) / 1.4);

  // نیروگاه در سمتِ راست
  const outP = easeOutCubic(span(t, 3.6, 6.2));
  drawPowerPlant(ctx, 1092, 372, 1.25, b, g, outP);
  drawGlowingText(ctx, 'منبعِ بی‌پایان', 1092, 410, `700 16px ${VZ}`, '#e0f2fe', withAlpha(b, 0.5), 10);

  // سیم از نیروگاه تا کلید تا لامپ
  const wire: Array<[number, number]> = [
    [1030, 340],
    [900, 340],
    [840, 286],
    [700, 286],
    [640, 340],
    [520, 340],
    [430, 300],
    [298, 300],
  ];
  const wireP = easeOutQuint(span(t, 0.9, 3.4));
  ctx.save();
  ctx.shadowColor = withAlpha(b, 0.5);
  ctx.shadowBlur = 10;
  drawGrowingPath(ctx, wire, wireP, 'rgba(148,163,184,0.75)', 3.4);
  ctx.restore();

  // کلید
  const switchP = easeOutBack(span(t, 3.2, 4));
  const flipped = span(t, 4.2, 4.7);
  ctx.save();
  ctx.translate(700, 286);
  ctx.globalAlpha = switchP;
  ctx.fillStyle = 'rgba(8,14,32,0.96)';
  ctx.strokeStyle = withAlpha(a, 0.8);
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.arc(0, 0, 22, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.save();
  ctx.rotate(lerp(-0.9, 0.55, flipped));
  ctx.strokeStyle = flipped > 0.5 ? '#fde68a' : 'rgba(203,213,225,0.9)';
  ctx.lineWidth = 4.5;
  ctx.lineCap = 'round';
  if (flipped > 0.5) {
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 16;
  }
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(26, 0);
  ctx.stroke();
  ctx.restore();
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(ctx, 'کلیدِ هدایت', 700, 236, `600 14px ${VZ}`, flipped > 0.5 ? '#fde68a' : 'rgba(203,213,225,0.7)', 'rgba(0,0,0,0)', 0);

  // جریانِ برق پس از زدنِ کلید
  const flow = span(t, 4.6, 6.4);
  if (flow > 0) {
    ctx.save();
    ctx.globalAlpha = 0.95;
    drawFlowPulse(ctx, 1030, 340, 360, 300, (g - 4.6) * 1.35, '#fde68a', 7, 0.55);
    ctx.restore();
  }

  // لامپ
  const lit = easeOutCubic(span(t, 5.4, 7.6)) * (0.82 + e * 0.3);
  drawLightBulb(ctx, 248, 300, 50, lit, a, g);
  drawGlowingText(ctx, 'لامپِ زندگیِ تو', 248, 392, `700 16px ${VZ}`, lit > 0.4 ? '#fde68a' : 'rgba(203,213,225,0.7)', withAlpha(a, 0.5), 10);

  // ترازوی قانونِ دقیق — یک گرم جابه‌جایی ندارد
  const balP = easeOutCubic(span(t, 2, 3.4));
  ctx.save();
  ctx.translate(330, 190);
  ctx.globalAlpha = balP;
  ctx.strokeStyle = withAlpha(b, 0.8);
  ctx.lineWidth = 3;
  const tiltA = Math.sin(g * 2.2) * 0.02 * (1 - span(t, 6, 8));
  ctx.beginPath();
  ctx.moveTo(0, 26);
  ctx.lineTo(0, -18);
  ctx.stroke();
  ctx.save();
  ctx.rotate(tiltA);
  ctx.beginPath();
  ctx.moveTo(-70, -18);
  ctx.lineTo(70, -18);
  ctx.stroke();
  for (const s of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(s * 70, -18);
    ctx.lineTo(s * 70, 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(s * 70, 8, 13, 0, Math.PI);
    ctx.stroke();
  }
  ctx.restore();
  ctx.fillStyle = withAlpha(b, 0.9);
  ctx.beginPath();
  ctx.arc(0, -18, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(ctx, 'بدونِ خطا • بدونِ تخلف', 330, 240, `600 14px ${VZ}`, 'rgba(224,242,254,0.85)', 'rgba(0,0,0,0)', 0);

  // سه کاشیِ قانون
  const tiles = [
    { title: 'هم‌جنس', sub: 'هرچه فرستادی، همان بازمی‌گردد', icon: '≡' },
    { title: 'تسخیر', sub: 'جهان در خدمتِ توست', icon: '✦' },
    { title: 'نشانه', sub: 'لحظه‌به‌لحظه عرضه می‌شود', icon: '◈' },
  ];
  tiles.forEach((tile, i) => {
    const p = span(t, 7.6 + i * 1.1, 8.8 + i * 1.1);
    if (p <= 0) return;
    const tx = 470 + i * 176;
    const ty = 452;
    ctx.save();
    ctx.globalAlpha = easeOutCubic(p);
    ctx.translate(tx, ty + (1 - easeOutBack(p)) * 30);
    const skew = (1 - easeOutQuint(p)) * 0.4;
    ctx.transform(1, 0, skew, 1, 0, 0);
    ctx.fillStyle = 'rgba(9,15,34,0.94)';
    ctx.strokeStyle = withAlpha(i % 2 ? b : a, 0.62);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.roundRect(-76, -52, 152, 104, 16);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = i % 2 ? b : a;
    ctx.font = `700 26px ${VZ}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = withAlpha(i % 2 ? b : a, 0.7);
    ctx.shadowBlur = 14;
    ctx.fillText(tile.icon, 0, -26);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#f8fafc';
    ctx.font = `800 19px ${VZ}`;
    ctx.fillText(tile.title, 0, 2);
    ctx.fillStyle = 'rgba(203,213,225,0.78)';
    ctx.font = `500 12px ${VZ}`;
    ctx.fillText(tile.sub, 0, 26);
    ctx.restore();
  });

  drawWaveform(ctx, 470, 372, 460, g, withAlpha(b, 0.5), 8 + e * 12, outP);
  drawVerseCard(ctx, 640, 556, 'كُن فَيَكُونُ', 'فرمانِ ما برای هر چیز تنها یک «باش» است', 'سورهٔ نحل • آیهٔ ۴۰', (t - 11) / 1.2, a, 720);
  void d;
};

/* ══════════ ۸ — فرکانسِ نور و گام بر آب ══════════ */
export const sceneFrequencyWaterFinale: SceneFn = (ctx, t, d, g, e, a, b) => {
  const horizon = 372;
  drawWaterWaves(ctx, horizon, 1280, g * 0.9, a, b, 4, 10);

  // فرستندهٔ مرکزی — کتابِ نور
  const tx = 640;
  const ty = 214;
  drawRadioWaves(ctx, tx, ty, g, a, 6, 320, 0.42, 0.9);
  drawAudioAuraRing(ctx, tx, ty, 58, g, 0.3 + e, b);

  ctx.save();
  ctx.translate(tx, ty);
  ctx.rotate(Math.sin(g * 0.7) * 0.05);
  const bookP = easeOutBack(span(t, 0.6, 2));
  ctx.scale(bookP, bookP);
  ctx.fillStyle = 'rgba(8,14,32,0.96)';
  ctx.strokeStyle = withAlpha(b, 0.85);
  ctx.lineWidth = 2.6;
  ctx.shadowColor = withAlpha(b, 0.8);
  ctx.shadowBlur = 22;
  ctx.beginPath();
  ctx.moveTo(-46, -28);
  ctx.quadraticCurveTo(-22, -38, 0, -28);
  ctx.quadraticCurveTo(22, -38, 46, -28);
  ctx.lineTo(46, 26);
  ctx.quadraticCurveTo(22, 16, 0, 26);
  ctx.quadraticCurveTo(-22, 16, -46, 26);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.beginPath();
  ctx.moveTo(0, -28);
  ctx.lineTo(0, 26);
  ctx.strokeStyle = withAlpha('#fde68a', 0.7);
  ctx.lineWidth = 1.8;
  ctx.stroke();
  for (let i = 0; i < 4; i++) {
    ctx.strokeStyle = withAlpha('#fde68a', 0.3);
    ctx.beginPath();
    ctx.moveTo(-38, -16 + i * 10);
    ctx.lineTo(-10, -20 + i * 10);
    ctx.moveTo(10, -20 + i * 10);
    ctx.lineTo(38, -16 + i * 10);
    ctx.stroke();
  }
  ctx.restore();
  drawGlowingText(ctx, 'فرکانسِ نور', tx, ty + 76, `800 20px ${VZ}`, '#fde68a', withAlpha(a, 0.6), 16);

  drawWipeText(ctx, 'نشانه‌ها را ببین', 640, 108, `800 36px ${VZ}`, '#fde68a', withAlpha(b, 0.6), (t - 0.3) / 1.3);

  // آدمی که بر آب گام برمی‌دارد
  const walkP = easeInOutCubic(span(t, 2.4, d - 2));
  const wx = lerp(1120, 300, walkP);
  const steps = 9;
  for (let i = 0; i < steps; i++) {
    const sxp = lerp(1120, 300, i / (steps - 1));
    const passed = sxp > wx;
    if (!passed) continue;
    const age = clamp01((wx - sxp) / 220);
    ctx.save();
    ctx.globalAlpha = (1 - age) * 0.75;
    const pad = ctx.createRadialGradient(sxp, horizon + 16, 2, sxp, horizon + 16, 46);
    pad.addColorStop(0, withAlpha(b, 0.7));
    pad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = pad;
    ctx.beginPath();
    ctx.ellipse(sxp, horizon + 16, 46, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.save();
  const bob = Math.sin(g * 3.4) * 5;
  drawFigure(ctx, wx, horizon - 6 + bob, 104, '#fde68a', g * 5.4, true);
  ctx.restore();
  drawGlowingText(ctx, 'هدایتِ لحظه‌به‌لحظه', wx, horizon - 132, `700 16px ${VZ}`, '#e0f2fe', withAlpha(a, 0.5), 12);

  // پنج گامِ زنده به‌صورت گره‌های مداری
  const orbitP = easeOutCubic(span(t, 6.4, 8.4));
  if (orbitP > 0.02) {
    drawOrbitRing(ctx, 640, 300, 232 * orbitP, g * 0.1, b, 0.28, false);
    FIVE_STEPS.forEach((s, i) => {
      const p = span(t, 7 + i * 0.62, 8 + i * 0.62);
      if (p <= 0) return;
      const ang = -Math.PI / 2 + (i / FIVE_STEPS.length) * Math.PI * 2 + g * 0.1;
      const nx = 640 + Math.cos(ang) * 232 * orbitP;
      const ny = 300 + Math.sin(ang) * 118 * orbitP;
      drawNodeBadge(ctx, nx, ny, `${i + 1}`.replace(/\d/g, (x) => '۰۱۲۳۴۵۶۷۸۹'[Number(x)]), p, i % 2 ? a : b, 17);
      drawGlowingText(ctx, s, nx, ny + 36, `600 13px ${VZ}`, withAlpha(i % 2 ? a : b, 0.95), 'rgba(0,0,0,0)', 0);
    });
  }

  // ماندالای پایانی که سرِ هم بسته می‌شود
  const mandP = easeOutQuint(span(t, 10.4, 13.4));
  drawSacredMandala(ctx, 640, 330, 212 * mandP, g * 0.09, a, 0.13 * mandP);
  drawSacredMandala(ctx, 640, 330, 140 * mandP, -g * 0.13, b, 0.11 * mandP);
  drawStar8(ctx, 640, 336, (44 + e * 22) * mandP, '#fde68a', g * 0.5, true, mandP * 0.9);

  drawStaggerWords(
    ctx,
    'تسلیم • هم‌جهتی • نشانه • هدایت',
    640,
    522,
    `800 26px ${VZ}`,
    '#fde68a',
    withAlpha(a, 0.7),
    t,
    11.6,
    0.18,
    12,
  );
  drawPopText(ctx, 'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ', 640, 574, `700 25px ${AR}`, '#bbf7d0', 'rgba(52,211,153,0.6)', (t - 13.4) / 1.2);
  void d;
};
