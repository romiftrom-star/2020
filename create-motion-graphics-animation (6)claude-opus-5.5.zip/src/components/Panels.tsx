import { useEffect, useRef, useState } from 'react';
import { CHAPTERS, TOTAL_DURATION, type CaptionCue } from '../motion/timeline';
import { drawChapterThumb } from '../motion/renderer';
import { formatTimeFa, toFaDigits } from '../motion/primitives';
import type { AudioState } from '../audio/engine';

/* ═══════════════ ریلِ فصل‌ها ═══════════════ */

function Thumb({ id }: { id: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ch = CHAPTERS.find((x) => x.id === id);
    if (!ch) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = 176 * dpr;
    c.height = 99 * dpr;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawChapterThumb(ctx, ch, 176, 99);
  }, [id]);
  return <canvas ref={ref} className="h-full w-full object-cover" style={{ width: 176, height: 99 }} />;
}

export function ChapterRail({
  activeId,
  onSeek,
  timeRef,
}: {
  activeId: number;
  onSeek: (t: number) => void;
  timeRef: React.RefObject<number>;
}) {
  const progressRefs = useRef<Array<HTMLSpanElement | null>>([]);
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const t = timeRef.current ?? 0;
      CHAPTERS.forEach((c, i) => {
        const el = progressRefs.current[i];
        if (!el) return;
        const p = Math.max(0, Math.min(1, (t - c.start) / (c.end - c.start)));
        el.style.transform = `scaleX(${p})`;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [timeRef]);

  return (
    <section className="panel rounded-3xl p-5 sm:p-6">
      <header className="mb-4 flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl leading-none text-amber-200">هشت فصلِ منتخب</h2>
          <p className="mt-2 text-[13px] text-slate-400">
            هر فصل یک استعارهٔ بصریِ مستقل دارد؛ روی هرکدام بزنید تا تایم‌لاین همان‌جا بپرد.
          </p>
        </div>
        <span className="tabular shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-bold text-slate-400">
          {toFaDigits(TOTAL_DURATION)} ثانیه
        </span>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {CHAPTERS.map((c, i) => {
          const active = c.id === activeId;
          return (
            <button
              key={c.id}
              onClick={() => onSeek(c.start + 0.05)}
              className={`panel-hover group flex gap-3 overflow-hidden rounded-2xl border p-2.5 text-right transition-all duration-300 ${
                active ? 'border-amber-300/55 bg-amber-400/[0.07]' : 'border-white/10 bg-white/[0.02]'
              }`}
            >
              <span className="relative block h-[74px] w-[132px] shrink-0 overflow-hidden rounded-xl border border-white/10 bg-[#04060e]">
                <span className="block h-full w-full transition-transform duration-500 group-hover:scale-110">
                  <Thumb id={c.id} />
                </span>
                <span
                  className="absolute inset-x-0 bottom-0 h-1 origin-right"
                  style={{ background: c.accent }}
                  ref={(el) => {
                    progressRefs.current[i] = el;
                  }}
                />
              </span>
              <span className="flex min-w-0 flex-1 flex-col justify-center">
                <span className="flex items-center gap-2">
                  <span
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{ background: c.accent, boxShadow: `0 0 10px ${c.accent}` }}
                  />
                  <span className="text-[11px] font-bold text-slate-500">{c.badge}</span>
                  <span className="tabular text-[10.5px] text-slate-600">
                    {formatTimeFa(c.start)}–{formatTimeFa(c.end)}
                  </span>
                </span>
                <span
                  className={`mt-1 truncate text-[14px] font-extrabold transition-colors ${
                    active ? 'text-amber-200' : 'text-slate-200 group-hover:text-amber-100'
                  }`}
                >
                  {c.title}
                </span>
                <span className="mt-1 line-clamp-2 text-[11.5px] leading-5 text-slate-500">{c.subtitle}</span>
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

/* ═══════════════ پنلِ صوت ═══════════════ */

export function AudioPanel({
  state,
  error,
  duration,
  sourceLabel,
  onLoadDefault,
  onPickFile,
  busy,
}: {
  state: AudioState;
  error: string | null;
  duration: number;
  sourceLabel: string;
  onLoadDefault: () => void;
  onPickFile: (f: File) => void;
  busy: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const stateLabel: Record<AudioState, string> = {
    idle: 'آمادهٔ بارگذاری',
    loading: 'در حالِ بارگذاری…',
    ready: 'آماده',
    playing: 'در حالِ پخش',
    paused: 'متوقف',
    error: 'خطا',
  };
  const tone =
    state === 'error'
      ? 'border-rose-400/40 bg-rose-500/10 text-rose-200'
      : state === 'playing'
        ? 'border-emerald-400/40 bg-emerald-500/10 text-emerald-200'
        : state === 'ready' || state === 'loading'
          ? 'border-sky-300/35 bg-sky-400/10 text-sky-200'
          : 'border-white/12 bg-white/5 text-slate-400';

  return (
    <section className="panel rounded-3xl p-5 sm:p-6">
      <header className="mb-4">
        <h2 className="font-display text-2xl leading-none text-amber-200">روایتِ صوتی</h2>
        <p className="mt-2 text-[13px] leading-6 text-slate-400">
          صوت هم پخش می‌شود، هم با <span className="text-slate-200">AnalyserNode</span> تحلیل می‌شود تا المان‌ها با
          ضربِ صدا بجنبند، و هم به‌صورتِ هم‌زمان داخلِ فایلِ ویدیویی ضبط می‌شود.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2.5">
        <button
          onClick={onLoadDefault}
          disabled={busy || state === 'loading'}
          className="btn rounded-xl bg-sky-400 px-4 py-2.5 text-[13px] font-extrabold text-[#03121e] shadow-[0_14px_34px_-14px_rgba(56,189,248,0.8)]"
        >
          پخشِ منتخبِ ۵ دقیقه‌ای
        </button>
        <button
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="btn rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-[13px] font-bold text-slate-100 hover:border-amber-300/50"
        >
          فایلِ صوتیِ خودم را بدهم
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onPickFile(f);
            e.target.value = '';
          }}
        />
        <span className={`rounded-full border px-3 py-1.5 text-[11.5px] font-bold ${tone}`}>
          {stateLabel[state]}
          {duration > 0 ? ` • ${formatTimeFa(duration)}` : ''}
        </span>
      </div>

      <p className="mt-3 break-all text-[11px] leading-5 text-slate-500" dir="ltr">
        {sourceLabel}
      </p>

      {error && (
        <p className="mt-3 rounded-xl border border-rose-400/35 bg-rose-500/8 px-4 py-3 text-[12.5px] leading-6 text-rose-100">
          {error} — نگران نباشید: انیمیشن با انرژیِ شبیه‌سازی‌شده زنده می‌ماند و می‌توانید فایلِ صوتیِ خودتان را
          جایگزین کنید.
        </p>
      )}
    </section>
  );
}

/* ═══════════════ ویرایشگرِ زیرنویس ═══════════════ */

export function CaptionEditor({
  captions,
  onChange,
  onReset,
  disabled,
}: {
  captions: CaptionCue[];
  onChange: (c: CaptionCue[]) => void;
  onReset: () => void;
  disabled: boolean;
}) {
  const [open, setOpen] = useState(false);
  const update = (i: number, patch: Partial<CaptionCue>) =>
    onChange(captions.map((c, k) => (k === i ? { ...c, ...patch } : c)));

  return (
    <section className="panel rounded-3xl p-5 sm:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl leading-none text-amber-200">زیرنویسِ همگام</h2>
          <p className="mt-2 max-w-xl text-[13px] leading-6 text-slate-400">
            {toFaDigits(captions.length)} کپشنِ برگرفته از روایت؛ متن و زمانِ هرکدام را می‌توانید دقیقاً با صدایِ
            خودتان تنظیم کنید تا واژه‌به‌واژه بنشیند.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setOpen((o) => !o)}
            className="btn rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-[13px] font-bold text-slate-100 hover:border-sky-300/50"
          >
            {open ? 'بستنِ ویرایشگر' : 'ویرایشِ متن‌ها'}
          </button>
          <button
            onClick={onReset}
            disabled={disabled}
            className="btn rounded-xl border border-white/10 px-3 py-2.5 text-[13px] font-bold text-slate-400 hover:text-slate-200"
          >
            بازنشانی
          </button>
        </div>
      </header>

      {open && (
        <div className="mt-4 max-h-[420px] space-y-2 overflow-y-auto pl-1">
          {captions.map((c, i) => (
            <div key={i} className="rounded-xl border border-white/8 bg-white/[0.02] p-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="tabular rounded-md bg-white/8 px-2 py-1 text-[11px] font-bold text-amber-200">
                  {toFaDigits(i + 1)}
                </span>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-400">
                  از
                  <input
                    type="number"
                    step="0.1"
                    min={0}
                    max={TOTAL_DURATION}
                    value={c.start}
                    disabled={disabled}
                    onChange={(e) => update(i, { start: Number(e.target.value) })}
                    className="tabular w-20 rounded-md border border-white/12 bg-[#04060e] px-2 py-1 text-[12px] text-slate-100 outline-none focus:border-amber-300/60"
                  />
                </label>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-400">
                  تا
                  <input
                    type="number"
                    step="0.1"
                    min={0}
                    max={TOTAL_DURATION}
                    value={c.end}
                    disabled={disabled}
                    onChange={(e) => update(i, { end: Number(e.target.value) })}
                    className="tabular w-20 rounded-md border border-white/12 bg-[#04060e] px-2 py-1 text-[12px] text-slate-100 outline-none focus:border-amber-300/60"
                  />
                </label>
                <button
                  onClick={() => update(i, { highlight: !c.highlight })}
                  className={`rounded-md px-2 py-1 text-[11px] font-bold transition-colors ${
                    c.highlight ? 'bg-amber-400/20 text-amber-200' : 'bg-white/6 text-slate-400'
                  }`}
                >
                  {c.highlight ? 'کلیدی' : 'معمولی'}
                </button>
              </div>
              <textarea
                value={c.text}
                disabled={disabled}
                rows={2}
                onChange={(e) => update(i, { text: e.target.value })}
                className="mt-2 w-full resize-none rounded-lg border border-white/10 bg-[#04060e] px-3 py-2 text-[13px] leading-6 text-slate-100 outline-none transition-colors focus:border-amber-300/55"
              />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
