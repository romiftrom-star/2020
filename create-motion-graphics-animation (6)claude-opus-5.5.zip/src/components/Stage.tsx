import { useEffect, useRef } from 'react';
import { CHAPTERS, TOTAL_DURATION, type MotionChapter } from '../motion/timeline';
import { formatTimeFa, toFaDigits } from '../motion/primitives';

export interface StageProps {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  wrapRef: React.RefObject<HTMLDivElement | null>;
  timeRef: React.RefObject<number>;
  playing: boolean;
  muted: boolean;
  audioLabel: string;
  audioState: string;
  recording: boolean;
  recProgress: number;
  chapterRef: React.RefObject<MotionChapter>;
  energyRef: React.RefObject<number>;
  levelsRef: React.RefObject<Float32Array>;
  aspectCss: string;
  onTogglePlay: () => void;
  onSeek: (t: number) => void;
  onToggleMute: () => void;
  onFullscreen: () => void;
  onRestart: () => void;
}

const SEGMENTS = CHAPTERS.map((c) => ({
  id: c.id,
  left: (c.start / TOTAL_DURATION) * 100,
  width: ((c.end - c.start) / TOTAL_DURATION) * 100,
  accent: c.accent,
  title: c.title,
}));

export default function Stage(props: StageProps) {
  const {
    canvasRef,
    wrapRef,
    timeRef,
    playing,
    muted,
    audioLabel,
    audioState,
    recording,
    recProgress,
    chapterRef,
    energyRef,
    levelsRef,
    aspectCss,
    onTogglePlay,
    onSeek,
    onToggleMute,
    onFullscreen,
    onRestart,
  } = props;

  const playheadRef = useRef<HTMLDivElement>(null);
  const timecodeRef = useRef<HTMLSpanElement>(null);
  const chapterRef2 = useRef<HTMLSpanElement>(null);
  const meterRef = useRef<HTMLDivElement>(null);
  const barsRef = useRef<HTMLDivElement>(null);
  const scrubRef = useRef<HTMLInputElement>(null);
  const draggingRef = useRef(false);

  // حلقهٔ سبکِ UI — بدونِ رندرِ مجددِ ری‌اکت در ۶۰ فریم بر ثانیه
  useEffect(() => {
    let raf = 0;
    let lastBarDraw = 0;
    const tick = () => {
      const t = timeRef.current ?? 0;
      const pct = Math.max(0, Math.min(1, t / TOTAL_DURATION));
      if (playheadRef.current) playheadRef.current.style.left = `${pct * 100}%`;
      if (timecodeRef.current) {
        timecodeRef.current.textContent = `${formatTimeFa(t)} / ${formatTimeFa(TOTAL_DURATION)}`;
      }
      if (chapterRef2.current && chapterRef.current) {
        const label = `فصل ${toFaDigits(chapterRef.current.id)} — ${chapterRef.current.title}`;
        if (chapterRef2.current.textContent !== label) {
          chapterRef2.current.textContent = label;
          chapterRef2.current.style.color = chapterRef.current.accent;
        }
      }
      if (meterRef.current) {
        meterRef.current.style.transform = `scaleX(${0.06 + (energyRef.current ?? 0) * 0.94})`;
      }
      if (barsRef.current && levelsRef.current && t - lastBarDraw > 0.03) {
        lastBarDraw = t;
        const kids = barsRef.current.children;
        const lv = levelsRef.current;
        for (let i = 0; i < kids.length; i++) {
          const v = lv[Math.min(lv.length - 1, Math.floor((i / kids.length) * lv.length))] ?? 0;
          (kids[i] as HTMLElement).style.transform = `scaleY(${0.08 + v * 0.92})`;
        }
      }
      if (scrubRef.current && !draggingRef.current) {
        scrubRef.current.value = String(pct * 1000);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [timeRef, energyRef, levelsRef, chapterRef]);

  return (
    <div className="relative">
      {/* قابِ سینمایی */}
      <div
        ref={wrapRef}
        className="group relative w-full overflow-hidden rounded-[26px] border border-white/10 bg-[#04060e] shadow-[0_50px_120px_-50px_rgba(0,0,0,1),0_0_0_1px_rgba(251,191,36,0.08)]"
        style={{ aspectRatio: aspectCss }}
      >
        <canvas
          ref={canvasRef}
          className="block h-full w-full"
          onClick={onTogglePlay}
          role="img"
          aria-label="پیش‌نمایشِ موشن گرافیک"
        />

        {/* نشانه‌های گوشهٔ کادر */}
        {[
          'top-3 right-3 border-t-2 border-r-2',
          'top-3 left-3 border-t-2 border-l-2',
          'bottom-3 right-3 border-b-2 border-r-2',
          'bottom-3 left-3 border-b-2 border-l-2',
        ].map((cls) => (
          <span
            key={cls}
            className={`pointer-events-none absolute h-6 w-6 border-amber-300/45 transition-all duration-500 group-hover:h-9 group-hover:w-9 group-hover:border-amber-300/80 ${cls}`}
          />
        ))}

        {recording && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center bg-[#04060e]/55 backdrop-blur-[2px]">
            <div className="flex items-center gap-3 rounded-full border border-rose-400/40 bg-[#12060f]/90 px-6 py-3">
              <span className="rec-dot h-3 w-3 rounded-full" />
              <span className="text-sm font-bold text-rose-100">در حالِ ضبطِ هم‌زمان…</span>
              <span className="tabular text-sm font-extrabold text-amber-300">
                {toFaDigits(Math.round(recProgress * 100))}٪
              </span>
            </div>
            <div className="mt-4 h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-l from-rose-400 to-amber-300 transition-[width] duration-200"
                style={{ width: `${recProgress * 100}%` }}
              />
            </div>
            <p className="mt-4 max-w-sm text-center text-xs leading-6 text-slate-400">
              ضبط به‌صورتِ بلادرنگ انجام می‌شود؛ این برگه را در همین حالت بگذارید بماند و تا پایانِ
              {' '}
              {toFaDigits(5)} دقیقه سراغِ کامپیوتر نگردید.
            </p>
          </div>
        )}

        {!recording && !playing && (
          <button
            onClick={onTogglePlay}
            className="absolute inset-0 flex items-center justify-center bg-gradient-to-t from-[#04060e]/85 via-[#04060e]/25 to-transparent transition-colors"
            aria-label="پخش"
          >
            <span className="flex h-20 w-20 items-center justify-center rounded-full border border-amber-300/50 bg-[#0a1024]/85 shadow-[0_0_50px_rgba(251,191,36,0.35)] transition-transform duration-300 hover:scale-110">
              <svg viewBox="0 0 24 24" className="mr-[-3px] h-8 w-8 fill-amber-300">
                <path d="M8 5.5v13l11-6.5z" />
              </svg>
            </span>
          </button>
        )}
      </div>

      {/* نوارِ کنترل */}
      <div className="panel mt-4 rounded-2xl px-4 py-3.5 sm:px-5">
        <div className="flex items-center gap-4">
          <button
            onClick={onTogglePlay}
            className="btn btn-gold flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-amber-400 text-[#0a1024] shadow-[0_0_26px_rgba(251,191,36,0.4)]"
            aria-label={playing ? 'توقف' : 'پخش'}
          >
            {playing ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                <path d="M7 5h3.5v14H7zm6.5 0H17v14h-3.5z" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="mr-[-2px] h-5 w-5 fill-current">
                <path d="M8 5.5v13l11-6.5z" />
              </svg>
            )}
          </button>

          <button
            onClick={onRestart}
            className="btn flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/12 bg-white/5 text-slate-200 hover:border-sky-300/50 hover:text-sky-200"
            aria-label="از ابتدا"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
              <path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z" />
            </svg>
          </button>

          <div className="relative min-w-0 flex-1">
            {/* نوارِ فصل‌ها */}
            <div className="pointer-events-none absolute inset-x-0 top-[-9px] flex h-1.5 w-full overflow-hidden rounded-full bg-white/5">
              {SEGMENTS.map((s) => (
                <div
                  key={s.id}
                  className="h-full opacity-60 transition-opacity duration-300 hover:opacity-100"
                  style={{
                    width: `${s.width}%`,
                    background: `linear-gradient(90deg, ${s.accent}55, ${s.accent})`,
                  }}
                  title={s.title}
                />
              ))}
            </div>
            <input
              ref={scrubRef}
              type="range"
              min={0}
              max={1000}
              defaultValue={0}
              className="scrub relative z-10 w-full"
              onChange={(e) => onSeek((Number(e.target.value) / 1000) * TOTAL_DURATION)}
              onPointerDown={() => {
                draggingRef.current = true;
              }}
              onPointerUp={() => {
                draggingRef.current = false;
              }}
              onPointerCancel={() => {
                draggingRef.current = false;
              }}
              onKeyDown={() => {
                draggingRef.current = false;
              }}
              aria-label="جابه‌جایی در تایم‌لاین"
            />
            <div
              ref={playheadRef}
              className="pointer-events-none absolute top-[-13px] z-20 h-6 w-[2px] -translate-x-1/2 rounded bg-amber-200 shadow-[0_0_12px_rgba(251,191,36,0.9)]"
              style={{ left: '0%' }}
            />
          </div>

          <span ref={timecodeRef} className="tabular shrink-0 text-sm font-bold text-slate-300">
            ۰۰:۰۰ / ۰۵:۰۰
          </span>

          <button
            onClick={onToggleMute}
            className="btn flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/12 bg-white/5 text-slate-300 hover:border-emerald-300/50 hover:text-emerald-200"
            aria-label={muted ? 'باصدا' : 'بی‌صدا'}
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                <path d="M4 9v6h4l5 4V5L8 9H4zm15.5 3l2.2-2.2-1.4-1.4-2.2 2.2-2.2-2.2-1.4 1.4 2.2 2.2-2.2 2.2 1.4 1.4 2.2-2.2 2.2 2.2 1.4-1.4-2.2-2.2z" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                <path d="M4 9v6h4l5 4V5L8 9H4zm12.5 3a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z" />
              </svg>
            )}
          </button>

          <button
            onClick={onFullscreen}
            className="btn hidden h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/12 bg-white/5 text-slate-300 hover:border-amber-300/50 hover:text-amber-200 sm:flex"
            aria-label="تمام‌صفحه"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
              <path d="M4 9V4h5v2H6v3H4zm11-5h5v5h-2V6h-3V4zM4 15h2v3h3v2H4v-5zm14 0h2v5h-5v-2h3v-3z" />
            </svg>
          </button>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-white/6 pt-3">
          <span ref={chapterRef2} className="text-sm font-extrabold text-amber-300">
            فصل ۱ — نزدیک‌ترین فرکانس به خدا
          </span>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-medium text-slate-500">طیفِ صوت</span>
              <div ref={barsRef} className="flex h-5 items-end gap-[2px]">
                {Array.from({ length: 22 }).map((_, i) => (
                  <span
                    key={i}
                    className="block h-full w-[3px] origin-bottom rounded-sm bg-gradient-to-t from-sky-400 to-amber-300"
                    style={{ transform: 'scaleY(0.08)' }}
                  />
                ))}
              </div>
            </div>

            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-white/8">
              <div
                ref={meterRef}
                className="h-full origin-right rounded-full bg-gradient-to-l from-amber-300 to-rose-400"
                style={{ transform: 'scaleX(0.06)' }}
              />
            </div>

            <span
              className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${
                audioState === 'error'
                  ? 'border-rose-400/40 bg-rose-500/10 text-rose-200'
                  : audioState === 'playing' || audioState === 'ready'
                    ? 'border-emerald-400/35 bg-emerald-500/10 text-emerald-200'
                    : 'border-white/12 bg-white/5 text-slate-400'
              }`}
            >
              <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-current" />
              {audioLabel}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
