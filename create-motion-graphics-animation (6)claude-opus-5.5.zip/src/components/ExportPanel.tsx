import { useState } from 'react';
import type { CodecChoice } from '../motion/recorder';
import { estimateMB } from '../motion/recorder';
import type { Host, HostedLink } from '../motion/uploader';
import { TOTAL_DURATION } from '../motion/timeline';
import { toFaDigits } from '../motion/primitives';

export type AspectKey = '16:9' | '9:16' | '1:1' | '4:5';
export type QualityKey = 'sd' | 'hd' | 'fhd' | 'qhd';

export interface ExportSettings {
  aspect: AspectKey;
  quality: QualityKey;
  fps: 30 | 60;
  mbps: number;
  showHud: boolean;
  showSubtitles: boolean;
}

export const RESOLUTIONS: Record<AspectKey, Record<QualityKey, [number, number]>> = {
  '16:9': { sd: [854, 480], hd: [1280, 720], fhd: [1920, 1080], qhd: [2560, 1440] },
  '9:16': { sd: [480, 854], hd: [720, 1280], fhd: [1080, 1920], qhd: [1440, 2560] },
  '1:1': { sd: [480, 480], hd: [720, 720], fhd: [1080, 1080], qhd: [1440, 1440] },
  '4:5': { sd: [576, 720], hd: [864, 1080], fhd: [1080, 1350], qhd: [1440, 1800] },
};

export const ASPECT_LABEL: Record<AspectKey, string> = {
  '16:9': 'افقی • یوتیوب',
  '9:16': 'عمودی • ریلز و استوری',
  '1:1': 'مربع • پستِ اینستاگرام',
  '4:5': 'پرترهٔ اینستاگرام',
};

export const QUALITY_LABEL: Record<QualityKey, string> = {
  sd: 'SD ۴۸۰',
  hd: 'HD ۷۲۰',
  fhd: 'FHD ۱۰۸۰',
  qhd: 'QHD ۱۴۴۰',
};

export interface RenderResult {
  blob: Blob;
  url: string;
  ext: string;
  filename: string;
  sizeMB: number;
  seconds: number;
}

export type Stage = 'idle' | 'recording' | 'encoding' | 'done' | 'error';

interface Props {
  settings: ExportSettings;
  onSettings: (s: ExportSettings) => void;
  codecs: CodecChoice[];
  stage: Stage;
  progress: number;
  message: string | null;
  result: RenderResult | null;
  onStart: () => void;
  onCancel: () => void;
  onDownload: () => void;
  uploading: { host: Host; pct: number; mb: number } | null;
  links: HostedLink[];
  onUpload: (host: Host) => void;
  onReset: () => void;
}

function Seg<T extends string>({
  value,
  options,
  onChange,
  disabled,
}: {
  value: T;
  options: Array<{ key: T; label: string; sub?: string }>;
  onChange: (v: T) => void;
  disabled?: boolean;
}) {
  return (
    <div className="grid grid-cols-2 gap-1.5">
      {options.map((o) => {
        const active = o.key === value;
        return (
          <button
            key={o.key}
            disabled={disabled}
            onClick={() => onChange(o.key)}
            className={`btn rounded-xl border px-2.5 py-2 text-right transition-all duration-300 ${
              active
                ? 'border-amber-300/60 bg-amber-400/12 shadow-[0_0_24px_-6px_rgba(251,191,36,0.55)]'
                : 'border-white/10 bg-white/[0.03] hover:border-white/25 hover:bg-white/[0.06]'
            } ${disabled ? 'opacity-50' : ''}`}
          >
            <span className={`block text-[13px] font-extrabold ${active ? 'text-amber-200' : 'text-slate-200'}`}>
              {o.label}
            </span>
            {o.sub && <span className="mt-0.5 block text-[10.5px] font-medium text-slate-500">{o.sub}</span>}
          </button>
        );
      })}
    </div>
  );
}

export default function ExportPanel(props: Props) {
  const {
    settings,
    onSettings,
    codecs,
    stage,
    progress,
    message,
    result,
    onStart,
    onCancel,
    onDownload,
    uploading,
    links,
    onUpload,
    onReset,
  } = props;
  const [copied, setCopied] = useState<string | null>(null);

  const [w, h] = RESOLUTIONS[settings.aspect][settings.quality];
  const est = estimateMB(settings.mbps * 1_000_000, TOTAL_DURATION);
  const mp4 = codecs.find((c) => c.ext === 'mp4');
  const best = mp4 ?? codecs[0];
  const busy = stage === 'recording' || stage === 'encoding';

  const copy = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 1800);
    } catch {
      setCopied(null);
    }
  };

  const set = <K extends keyof ExportSettings>(k: K, v: ExportSettings[K]) =>
    onSettings({ ...settings, [k]: v });

  return (
    <section className="panel rounded-3xl p-5 sm:p-6">
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl leading-none text-amber-200">خروجی و انتشار</h2>
          <p className="mt-2 text-[13px] leading-6 text-slate-400">
            ضبطِ بلادرنگِ تایم‌لاین با موتورِ <span className="text-slate-200">MediaRecorder</span> — ویدیو با
            {' '}
            <span className="text-slate-200">{toFaDigits(TOTAL_DURATION)}</span> ثانیه روایتِ صوتیِ همگام ساخته می‌شود.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {best ? (
            <span className="rounded-full border border-emerald-400/35 bg-emerald-500/10 px-3 py-1.5 text-[11px] font-bold text-emerald-200">
              رمزگذارِ فعال: {best.label}
            </span>
          ) : (
            <span className="rounded-full border border-rose-400/35 bg-rose-500/10 px-3 py-1.5 text-[11px] font-bold text-rose-200">
              مرورگر از MediaRecorder پشتیبانی نمی‌کند
            </span>
          )}
        </div>
      </header>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* نسبتِ تصویر */}
        <div>
          <label className="mb-2 block text-[11px] font-bold tracking-wide text-slate-400">نسبتِ تصویر</label>
          <Seg<AspectKey>
            value={settings.aspect}
            disabled={busy}
            onChange={(v) => set('aspect', v)}
            options={(Object.keys(ASPECT_LABEL) as AspectKey[]).map((k) => ({
              key: k,
              label: k,
              sub: ASPECT_LABEL[k],
            }))}
          />
        </div>

        {/* کیفیت */}
        <div>
          <label className="mb-2 block text-[11px] font-bold tracking-wide text-slate-400">کیفیت</label>
          <Seg<QualityKey>
            value={settings.quality}
            disabled={busy}
            onChange={(v) => set('quality', v)}
            options={(Object.keys(QUALITY_LABEL) as QualityKey[]).map((k) => ({
              key: k,
              label: QUALITY_LABEL[k],
            }))}
          />
        </div>

        {/* نرخِ فریم */}
        <div>
          <label className="mb-2 block text-[11px] font-bold tracking-wide text-slate-400">نرخِ فریم</label>
          <Seg<'30' | '60'>
            value={String(settings.fps) as '30' | '60'}
            disabled={busy}
            onChange={(v) => set('fps', v === '60' ? 60 : 30)}
            options={[
              { key: '30', label: '۳۰ فریم', sub: 'حجمِ کمتر' },
              { key: '60', label: '۶۰ فریم', sub: 'حرکتِ روان‌تر' },
            ]}
          />
        </div>

        {/* نرخِ بیت */}
        <div>
          <label className="mb-2 flex items-center justify-between text-[11px] font-bold tracking-wide text-slate-400">
            <span>نرخِ بیتِ ویدیو</span>
            <span className="tabular text-amber-300">{toFaDigits(settings.mbps)} مگابیت بر ثانیه</span>
          </label>
          <input
            type="range"
            min={3}
            max={24}
            step={1}
            value={settings.mbps}
            disabled={busy}
            onChange={(e) => set('mbps', Number(e.target.value))}
            className="scrub w-full"
          />
          <div className="mt-1 flex justify-between text-[10.5px] text-slate-500">
            <span>۳</span>
            <span>حجمِ برآوردی: ~{toFaDigits(est.toFixed(0))} مگابایت</span>
            <span>۲۴</span>
          </div>
        </div>
      </div>

      {/* لایه‌های روی تصویر */}
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {[
          { key: 'showHud' as const, label: 'HUD و نوارِ فصل‌ها', hint: 'کپسولِ عنوانِ فصل، زمان و طیفِ صوت' },
          { key: 'showSubtitles' as const, label: 'زیرنویسِ فارسی', hint: 'متنِ همگام در پایینِ کادر' },
        ].map((o) => (
          <button
            key={o.key}
            disabled={busy}
            onClick={() => set(o.key, !settings[o.key])}
            className={`btn flex items-center justify-between gap-3 rounded-2xl border px-4 py-3 text-right transition-all ${
              settings[o.key]
                ? 'border-sky-300/45 bg-sky-400/10'
                : 'border-white/10 bg-white/[0.03] hover:border-white/25'
            }`}
          >
            <span>
              <span className="block text-[13px] font-bold text-slate-100">{o.label}</span>
              <span className="mt-0.5 block text-[11px] text-slate-500">{o.hint}</span>
            </span>
            <span
              className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300 ${
                settings[o.key] ? 'bg-sky-400/80' : 'bg-white/12'
              }`}
            >
              <span
                className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-all duration-300 ${
                  settings[o.key] ? 'right-1' : 'right-6'
                }`}
              />
            </span>
          </button>
        ))}
      </div>

      {/* دکمهٔ ضبط */}
      <div className="mt-6 flex flex-wrap items-center gap-3">
        {stage !== 'recording' ? (
          <button
            onClick={onStart}
            disabled={!best || busy}
            className="btn btn-gold flex items-center gap-3 rounded-2xl bg-gradient-to-l from-amber-400 to-amber-300 px-6 py-3.5 text-[15px] font-extrabold text-[#150f02] shadow-[0_18px_44px_-16px_rgba(251,191,36,0.75)]"
          >
            <span className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#150f02]" />
            ساختِ ویدیوی {toFaDigits(TOTAL_DURATION)} ثانیه‌ای
          </button>
        ) : (
          <button
            onClick={onCancel}
            className="btn flex items-center gap-3 rounded-2xl border border-rose-400/45 bg-rose-500/12 px-6 py-3.5 text-[15px] font-extrabold text-rose-100"
          >
            لغوِ ضبط
          </button>
        )}

        <div className="min-w-[180px] flex-1">
          <div className="h-2 overflow-hidden rounded-full bg-white/8">
            <div
              className={`h-full rounded-full transition-[width] duration-150 ${
                stage === 'recording'
                  ? 'bg-gradient-to-l from-rose-400 to-amber-300'
                  : 'bg-gradient-to-l from-emerald-400 to-sky-400'
              }`}
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </div>
          <p className="mt-2 text-[11.5px] font-medium text-slate-400">
            {stage === 'recording'
              ? `ضبطِ بلادرنگ — ${toFaDigits(Math.round(progress * 100))}٪ از ${toFaDigits(Math.ceil(TOTAL_DURATION / 60))} دقیقه`
              : stage === 'encoding'
                ? 'در حالِ بستنِ فایلِ ویدیو…'
                : stage === 'done'
                  ? 'فایل آماده است ✓'
                  : `خروجیِ ${w}×${h} • ${toFaDigits(settings.fps)} فریم • ${toFaDigits(settings.mbps)} مگابیت`}
          </p>
        </div>
      </div>

      {message && (
        <p
          className={`mt-4 rounded-xl border px-4 py-3 text-[12.5px] leading-6 ${
            stage === 'error'
              ? 'border-rose-400/35 bg-rose-500/8 text-rose-100'
              : 'border-sky-300/30 bg-sky-400/8 text-sky-100'
          }`}
        >
          {message}
        </p>
      )}

      {/* نتیجه */}
      {result && (
        <div className="mt-6 rounded-2xl border border-emerald-400/30 bg-emerald-500/[0.06] p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-400/12 text-emerald-200">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                  <path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z" />
                </svg>
              </span>
              <div>
                <p className="text-[14px] font-extrabold text-emerald-100" dir="ltr">
                  {result.filename}
                </p>
                <p className="tabular mt-0.5 text-[11.5px] text-emerald-200/70">
                  {toFaDigits(result.sizeMB.toFixed(1))} مگابایت • {w}×{h} • {toFaDigits(settings.fps)} فریم
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={onDownload}
                className="btn rounded-xl bg-emerald-400 px-4 py-2.5 text-[13px] font-extrabold text-[#04140e]"
              >
                دانلودِ مستقیم
              </button>
              <button
                onClick={() => onUpload('tmpfiles.org')}
                disabled={!!uploading}
                className="btn rounded-xl border border-white/15 bg-white/6 px-4 py-2.5 text-[13px] font-bold text-slate-100 hover:border-amber-300/50"
              >
                انتشار روی tmpfiles.org
              </button>
              <button
                onClick={() => onUpload('gofile.io')}
                disabled={!!uploading}
                className="btn rounded-xl border border-white/15 bg-white/6 px-4 py-2.5 text-[13px] font-bold text-slate-100 hover:border-sky-300/50"
              >
                انتشار روی gofile.io
              </button>
              <button
                onClick={onReset}
                className="btn rounded-xl border border-white/10 px-3 py-2.5 text-[13px] font-bold text-slate-400 hover:text-slate-200"
              >
                پاک‌کردن
              </button>
            </div>
          </div>

          {uploading && (
            <div className="mt-4 rounded-xl border border-white/10 bg-[#04060e]/60 p-3">
              <div className="flex items-center justify-between text-[12px] font-bold text-slate-200">
                <span>در حالِ ارسال به {uploading.host}</span>
                <span className="tabular text-amber-300">
                  {toFaDigits(uploading.mb.toFixed(1))} از {toFaDigits(result.sizeMB.toFixed(1))} مگابایت
                </span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-l from-sky-400 to-amber-300 transition-[width] duration-200"
                  style={{ width: `${uploading.pct}%` }}
                />
              </div>
            </div>
          )}

          {links.length > 0 && (
            <div className="mt-4 space-y-2.5">
              {links.map((l, i) => (
                <div key={`${l.host}-${i}`} className="rounded-xl border border-white/10 bg-[#04060e]/70 p-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="rounded-md bg-white/8 px-2 py-1 text-[11px] font-extrabold text-amber-200">
                      {l.host}
                    </span>
                    <span className="text-[11px] text-slate-500">{l.note}</span>
                  </div>
                  <div className="mt-2.5 flex flex-wrap items-center gap-2">
                    <a
                      href={l.pageUrl}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="btn min-w-0 flex-1 truncate rounded-lg border border-white/12 bg-white/5 px-3 py-2 text-[12px] font-semibold text-sky-200 hover:border-sky-300/50"
                      dir="ltr"
                    >
                      {l.pageUrl}
                    </a>
                    <button
                      onClick={() => copy(l.pageUrl, `p${i}`)}
                      className="btn rounded-lg border border-white/12 bg-white/5 px-3 py-2 text-[12px] font-bold text-slate-200 hover:border-amber-300/50"
                    >
                      {copied === `p${i}` ? 'کپی شد ✓' : 'کپی'}
                    </button>
                  </div>
                  {l.directUrl && (
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <a
                        href={l.directUrl}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="btn min-w-0 flex-1 truncate rounded-lg border border-emerald-400/25 bg-emerald-400/8 px-3 py-2 text-[12px] font-semibold text-emerald-200 hover:border-emerald-300/50"
                        dir="ltr"
                      >
                        {l.directUrl}
                      </a>
                      <button
                        onClick={() => copy(l.directUrl!, `d${i}`)}
                        className="btn rounded-lg border border-emerald-400/25 bg-emerald-400/8 px-3 py-2 text-[12px] font-bold text-emerald-100 hover:border-emerald-300/60"
                      >
                        {copied === `d${i}` ? 'کپی شد ✓' : 'کپیِ لینکِ مستقیم'}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
