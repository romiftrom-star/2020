/* ------------------------------------------------------------------
   engine.ts — موتورِ صوت
   پخش، تحلیلِ انرژیِ لحظه‌ای (برای واکنش‌پذیریِ المان‌ها) و آماده‌سازیِ
   ترکِ صوتی برای ضبطِ هم‌زمان در فایلِ ویدیویی
------------------------------------------------------------------ */

export type AudioState = 'idle' | 'loading' | 'ready' | 'playing' | 'paused' | 'error';

const BANDS = 28;

export class AudioEngine {
  el: HTMLAudioElement;
  ctx: AudioContext | null = null;
  private src: MediaElementAudioSourceNode | null = null;
  private analyser: AnalyserNode | null = null;
  private monitor: GainNode | null = null;
  private recDest: MediaStreamAudioDestinationNode | null = null;
  private timeBuf: Uint8Array<ArrayBuffer> | null = null;
  private freqBuf: Uint8Array<ArrayBuffer> | null = null;

  state: AudioState = 'idle';
  error: string | null = null;
  duration = 0;
  muted = false;
  energy = 0;
  levels: Float32Array = new Float32Array(BANDS);
  private smooth = 0;
  private smoothLevels: Float32Array = new Float32Array(BANDS);

  constructor() {
    this.el = new Audio();
    this.el.crossOrigin = 'anonymous';
    this.el.preload = 'auto';
  }

  /** اتصالِ گرافِ صوتی — باید پس از یک تعاملِ کاربر انجام شود */
  private ensureGraph() {
    if (this.ctx) return;
    const AC: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) throw new Error('مرورگر از Web Audio پشتیبانی نمی‌کند.');
    this.ctx = new AC();
    this.src = this.ctx.createMediaElementSource(this.el);
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.72;
    this.timeBuf = new Uint8Array(this.analyser.fftSize);
    this.freqBuf = new Uint8Array(this.analyser.frequencyBinCount);

    this.monitor = this.ctx.createGain();
    this.monitor.gain.value = this.muted ? 0 : 1;
    this.recDest = this.ctx.createMediaStreamDestination();

    this.src.connect(this.analyser);
    this.analyser.connect(this.monitor);
    this.monitor.connect(this.ctx.destination);
    this.analyser.connect(this.recDest);
  }

  async load(url: string) {
    this.state = 'loading';
    this.error = null;
    this.el.src = url;
    try {
      this.ensureGraph();
      await this.ctx?.resume();
      await new Promise<void>((resolve, reject) => {
        const done = () => {
          this.el.removeEventListener('loadedmetadata', done);
          this.el.removeEventListener('error', fail);
          resolve();
        };
        const fail = () => {
          this.el.removeEventListener('loadedmetadata', done);
          this.el.removeEventListener('error', fail);
          reject(new Error('فایلِ صوتی بارگذاری نشد.'));
        };
        this.el.addEventListener('loadedmetadata', done);
        this.el.addEventListener('error', fail);
        this.el.load();
      });
      this.duration = Number.isFinite(this.el.duration) ? this.el.duration : 0;
      this.state = 'ready';
    } catch (err) {
      this.state = 'error';
      this.error = err instanceof Error ? err.message : 'خطای ناشناخته در بارگذاری صوت.';
    }
  }

  /** بارگذاری از فایلِ محلیِ کاربر */
  async loadFile(file: File) {
    this.state = 'loading';
    this.error = null;
    this.el.src = URL.createObjectURL(file);
    try {
      this.ensureGraph();
      await this.ctx?.resume();
      await new Promise<void>((resolve) => {
        this.el.addEventListener('loadedmetadata', () => resolve(), { once: true });
        this.el.load();
      });
      this.duration = Number.isFinite(this.el.duration) ? this.el.duration : 0;
      this.state = 'ready';
    } catch (err) {
      this.state = 'error';
      this.error = err instanceof Error ? err.message : 'خطا در خواندن فایلِ صوتی.';
    }
  }

  get recordingStream(): MediaStream | null {
    return this.recDest ? this.recDest.stream : null;
  }

  get hasAudioGraph() {
    return !!this.analyser;
  }

  async play(from?: number) {
    try {
      this.ensureGraph();
      await this.ctx?.resume();
      if (from !== undefined && Math.abs(this.el.currentTime - from) > 0.25) this.el.currentTime = from;
      await this.el.play();
      this.state = 'playing';
    } catch (err) {
      this.state = 'error';
      this.error = err instanceof Error ? err.message : 'پخشِ صوت ممکن نشد.';
    }
  }

  pause() {
    this.el.pause();
    if (this.state === 'playing') this.state = 'paused';
  }

  seek(t: number) {
    if (Number.isFinite(this.el.duration) && this.el.duration > 0) {
      this.el.currentTime = Math.max(0, Math.min(this.el.duration - 0.05, t));
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.monitor && this.ctx) {
      this.monitor.gain.setTargetAtTime(m ? 0 : 1, this.ctx.currentTime, 0.02);
    }
  }

  /** به‌روزرسانیِ انرژی و طیفِ فرکانسی — هر فریم صدا شود */
  sample(fallbackT: number) {
    if (this.analyser && this.timeBuf && this.freqBuf && this.el.paused === false) {
      this.analyser.getByteTimeDomainData(this.timeBuf);
      this.analyser.getByteFrequencyData(this.freqBuf);
      let sum = 0;
      for (let i = 0; i < this.timeBuf.length; i++) {
        const v = (this.timeBuf[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / this.timeBuf.length);
      const target = Math.min(1, rms * 3.4);
      this.smooth += (target - this.smooth) * (target > this.smooth ? 0.42 : 0.12);
      this.energy = this.smooth;

      const bins = this.freqBuf.length;
      for (let i = 0; i < BANDS; i++) {
        const lo = Math.floor(Math.pow(i / BANDS, 1.7) * bins);
        const hi = Math.max(lo + 1, Math.floor(Math.pow((i + 1) / BANDS, 1.7) * bins));
        let s = 0;
        for (let k = lo; k < hi; k++) s += this.freqBuf[k];
        const v = s / (hi - lo) / 255;
        this.smoothLevels[i] += (v - this.smoothLevels[i]) * (v > this.smoothLevels[i] ? 0.5 : 0.16);
        this.levels[i] = this.smoothLevels[i];
      }
      return;
    }

    // انرژیِ شبیه‌سازی‌شده — وقتی صوت در دسترس نیست، انیمیشن زنده می‌ماند
    const t = fallbackT;
    const beat = Math.pow(Math.max(0, Math.sin(t * Math.PI * 1.35)), 6);
    const breath = 0.5 + 0.5 * Math.sin(t * 0.42);
    const target = Math.min(1, 0.16 + beat * 0.62 + breath * 0.1 + Math.max(0, Math.sin(t * 7.1)) * 0.05);
    this.smooth += (target - this.smooth) * 0.16;
    this.energy = this.smooth;
    for (let i = 0; i < BANDS; i++) {
      const v =
        0.16 +
        0.5 * Math.abs(Math.sin(t * 2.1 + i * 0.52)) * (0.4 + this.smooth) +
        0.3 * Math.abs(Math.sin(t * 5.3 + i * 1.31)) * beat;
      this.smoothLevels[i] += (v - this.smoothLevels[i]) * 0.22;
      this.levels[i] = Math.min(1, this.smoothLevels[i]);
    }
  }
}
