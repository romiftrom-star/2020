import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Stage from './components/Stage';
import ExportPanel, { RESOLUTIONS, type ExportSettings, type RenderResult, type Stage as ExportStage } from './components/ExportPanel';
import { AudioPanel, CaptionEditor, ChapterRail } from './components/Panels';
import { AudioEngine, type AudioState } from './audio/engine';
import { drawMotionFrame } from './motion/renderer';
import {
  AUDIO_URL,
  CAPTIONS,
  CHAPTERS,
  TOTAL_DURATION,
  getChapterAt,
  type CaptionCue,
  type MotionChapter,
} from './motion/timeline';
import {
  downloadBlob,
  pickCodec,
  supportedCodecs,
  startRecording,
  type RecorderHandle,
} from './motion/recorder';
import { uploadTo, type Host, type HostedLink } from './motion/uploader';
import { formatTimeFa, toFaDigits } from './motion/primitives';
import montageAudio from './assets/montage.mp3';

const MONTAGE_URL = montageAudio || AUDIO_URL;

const ASPECT_CSS: Record<ExportSettings['aspect'], string> = {
  '16:9': '16 / 9',
  '9:16': '9 / 16',
  '1:1': '1 / 1',
  '4:5': '4 / 5',
};

export default function App() {
  /* ---------- مرجع‌ها ---------- */
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const audioRef = useRef<AudioEngine | null>(null);
  if (!audioRef.current) audioRef.current = new AudioEngine();
  const audio = audioRef.current;

  const timeRef = useRef(0);
  const playingRef = useRef(true);
  const recordingRef = useRef<RecorderHandle | null>(null);
  const isRecordingRef = useRef(false);
  const chapterRef = useRef<MotionChapter>(CHAPTERS[0]);
  const energyRef = useRef(0);
  const levelsRef = useRef<Float32Array>(new Float32Array(28));
  const settingsRef = useRef<ExportSettings>({
    aspect: '16:9',
    quality: 'fhd',
    fps: 60,
    mbps: 10,
    showHud: true,
    showSubtitles: true,
  });
  const captionsRef = useRef<CaptionCue[]>(CAPTIONS);
  const fontsReadyRef = useRef(false);

  /* ---------- حالت ---------- */
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(false);
  const [audioState, setAudioState] = useState<AudioState>('idle');
  const [audioError, setAudioError] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState(0);
  const [sourceLabel, setSourceLabel] = useState('منتخبِ ۵ دقیقه‌ای • جلسهٔ سوم، بخشِ سوم (j 3-3.mp3) • ۹ برش');
  const [captions, setCaptions] = useState<CaptionCue[]>(CAPTIONS);
  const [settings, setSettings] = useState<ExportSettings>(settingsRef.current);
  const [activeChapter, setActiveChapter] = useState(1);
  const [loop, setLoop] = useState(true);

  const [exportStage, setExportStage] = useState<ExportStage>('idle');
  const [exportProgress, setExportProgress] = useState(0);
  const [exportMessage, setExportMessage] = useState<string | null>(null);
  const [result, setResult] = useState<RenderResult | null>(null);
  const [uploading, setUploading] = useState<{ host: Host; pct: number; mb: number } | null>(null);
  const [links, setLinks] = useState<HostedLink[]>([]);

  const codecs = useMemo(() => supportedCodecs(), []);

  settingsRef.current = settings;
  captionsRef.current = captions;

  /* ---------- فونت‌ها ---------- */
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        await Promise.all([
          document.fonts.load('900 86px Vazirmatn'),
          document.fonts.load('800 42px Vazirmatn'),
          document.fonts.load('600 22px Vazirmatn'),
          document.fonts.load('700 31px Amiri'),
          document.fonts.load('400 26px Lalezar'),
        ]);
        await document.fonts.ready;
      } catch {
        /* فونتِ جایگزینِ سیستم */
      }
      if (alive) fontsReadyRef.current = true;
    };
    load();
    return () => {
      alive = false;
    };
  }, []);

  /* ---------- آشکارشدنِ بخش‌ها هنگامِ اسکرول ---------- */
  useEffect(() => {
    const els = Array.from(document.querySelectorAll('.reveal'));
    if (!('IntersectionObserver' in window)) {
      els.forEach((el) => el.classList.add('is-in'));
      return;
    }
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add('is-in');
            io.unobserve(en.target);
          }
        }),
      { threshold: 0.06, rootMargin: '0px 0px -6% 0px' },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  /* ---------- اندازهٔ بومِ پیش‌نمایش ---------- */
  const sizePreview = useCallback(() => {
    const c = canvasRef.current;
    const wrap = wrapRef.current;
    if (!c || !wrap || isRecordingRef.current) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = wrap.getBoundingClientRect();
    const w = Math.max(320, Math.round(rect.width * dpr));
    const h = Math.max(180, Math.round(rect.height * dpr));
    if (c.width !== w || c.height !== h) {
      c.width = w;
      c.height = h;
    }
  }, []);

  useEffect(() => {
    sizePreview();
    const ro = new ResizeObserver(() => sizePreview());
    if (wrapRef.current) ro.observe(wrapRef.current);
    window.addEventListener('resize', sizePreview);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', sizePreview);
    };
  }, [sizePreview, settings.aspect]);

  /* ---------- رسمِ یک فریم ---------- */
  const renderAt = useCallback((t: number, opts?: { hud?: boolean; subs?: boolean }) => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d', { alpha: false });
    if (!ctx) return;
    const s = opts ?? settingsRef.current;
    audio.sample(t);
    energyRef.current = audio.energy;
    levelsRef.current = audio.levels;
    chapterRef.current = getChapterAt(t);
    drawMotionFrame(ctx, t, c.width, c.height, audio.energy, audio.levels, {
      showHud: opts ? (opts.hud ?? true) : settingsRef.current.showHud,
      showSubtitles: opts ? (opts.subs ?? true) : settingsRef.current.showSubtitles,
      captions: captionsRef.current,
    });
    void s;
  }, [audio]);

  /* ---------- حلقهٔ پخش ---------- */
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let lastChapter = 1;

    const tick = (now: number) => {
      const dt = Math.min(0.12, (now - last) / 1000);
      last = now;

      if (!isRecordingRef.current) {
        if (playingRef.current) {
          let t: number;
          const usingAudio = audio.state === 'playing' && !audio.el.paused && audio.duration > 0;
          if (usingAudio) {
            t = audio.el.currentTime;
            if (t >= TOTAL_DURATION - 0.02) {
              if (loop) {
                t = 0;
                audio.seek(0);
              } else {
                t = TOTAL_DURATION;
                playingRef.current = false;
                setPlaying(false);
                audio.pause();
              }
            }
          } else {
            t = timeRef.current + dt;
            if (t >= TOTAL_DURATION) {
              if (loop) t = t % TOTAL_DURATION;
              else {
                t = TOTAL_DURATION;
                playingRef.current = false;
                setPlaying(false);
              }
            }
          }
          timeRef.current = t;
        }
        if (fontsReadyRef.current) renderAt(timeRef.current);
        const ch = getChapterAt(timeRef.current);
        if (ch.id !== lastChapter) {
          lastChapter = ch.id;
          setActiveChapter(ch.id);
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [audio, loop, renderAt]);

  /* ---------- کنترل‌ها ---------- */
  const syncAudioState = () => {
    setAudioState(audio.state);
    setAudioError(audio.error);
    setAudioDuration(audio.duration);
  };

  const togglePlay = useCallback(async () => {
    if (isRecordingRef.current) return;
    if (playingRef.current) {
      playingRef.current = false;
      setPlaying(false);
      audio.pause();
      syncAudioState();
      return;
    }
    if (timeRef.current >= TOTAL_DURATION - 0.05) {
      timeRef.current = 0;
      audio.seek(0);
    }
    playingRef.current = true;
    setPlaying(true);
    if (audio.state === 'ready' || audio.state === 'paused' || audio.state === 'playing') {
      await audio.play(timeRef.current);
    } else if (audio.state === 'idle') {
      await loadDefaultAudio(true);
    }
    syncAudioState();
  }, [audio]);

  const seek = useCallback(
    (t: number) => {
      if (isRecordingRef.current) return;
      const clamped = Math.max(0, Math.min(TOTAL_DURATION, t));
      timeRef.current = clamped;
      setActiveChapter(getChapterAt(clamped).id);
      if (audio.state === 'ready' || audio.state === 'playing' || audio.state === 'paused') {
        audio.seek(clamped);
        if (playingRef.current) void audio.play(clamped);
      }
      renderAt(clamped);
    },
    [audio, renderAt],
  );

  const restart = useCallback(() => {
    seek(0);
    if (!playingRef.current) void togglePlay();
  }, [seek, togglePlay]);

  const toggleMute = useCallback(() => {
    const next = !muted;
    setMuted(next);
    audio.setMuted(next);
  }, [audio, muted]);

  const fullscreen = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  const loadDefaultAudio = useCallback(
    async (autoplay = false) => {
      setAudioState('loading');
      setExportMessage(null);
      await audio.load(MONTAGE_URL);
      setSourceLabel('منتخبِ ۵ دقیقه‌ای • جلسهٔ سوم، بخشِ سوم (j 3-3.mp3) • ۹ برش');
      syncAudioState();
      if (autoplay && audio.state !== 'error') {
        playingRef.current = true;
        setPlaying(true);
        await audio.play(timeRef.current);
        syncAudioState();
      }
    },
    [audio],
  );

  const loadFile = useCallback(
    async (file: File) => {
      setAudioState('loading');
      await audio.loadFile(file);
      setSourceLabel(`${file.name} • ${(file.size / 1048576).toFixed(1)} مگابایت`);
      syncAudioState();
    },
    [audio],
  );

  /* ---------- ضبط ---------- */
  const startExport = useCallback(async () => {
    const c = canvasRef.current;
    if (!c) return;
    const codec = pickCodec(true);
    if (!codec) {
      setExportStage('error');
      setExportMessage('مرورگرِ شما MediaRecorder ندارد. از آخرین نسخهٔ Chrome، Edge یا Safari استفاده کنید.');
      return;
    }
    const s = settingsRef.current;
    const [w, h] = RESOLUTIONS[s.aspect][s.quality];

    // صوت را آماده کن
    if (audio.state === 'idle' || audio.state === 'error') {
      await audio.load(MONTAGE_URL);
      syncAudioState();
    }

    setExportStage('recording');
    setExportProgress(0);
    setExportMessage(null);
    setLinks([]);
    setResult(null);

    playingRef.current = false;
    setPlaying(false);
    audio.pause();

    // مطمئن شو فونت‌های فارسی پیش از اولین فریمِ ضبط بارگذاری شده‌اند
    try {
      await document.fonts.ready;
    } catch {
      /* بی‌اهمیت */
    }

    // بوم را به قطعیتِ خروجی ببر
    isRecordingRef.current = true;
    c.width = w;
    c.height = h;
    timeRef.current = 0;
    audio.seek(0);
    audio.setMuted(false);
    setMuted(false);
    renderAt(0);

    // پخشِ هم‌زمانِ صوت برای ضبطِ صدا
    const audioPromise = audio.play(0);
    audioPromise.catch(() => undefined);

    const handle = startRecording(c, {
      duration: TOTAL_DURATION,
      fps: s.fps,
      videoBitrate: s.mbps * 1_000_000,
      audioBitrate: 160_000,
      codec,
      audioStream: audio.recordingStream,
      render: (t) => {
        timeRef.current = t;
        renderAt(t);
        const ch = getChapterAt(t);
        setActiveChapter((prev) => (prev === ch.id ? prev : ch.id));
      },
      onProgress: (_t, pct) => setExportProgress(pct),
    });
    recordingRef.current = handle;

    try {
      const out = await handle.promise;
      const filename = `shokr-frequency-5min-${w}x${h}-${s.fps}fps.${out.ext}`;
      const url = URL.createObjectURL(out.blob);
      setResult({ blob: out.blob, url, ext: out.ext, filename, sizeMB: out.sizeMB, seconds: out.seconds });
      setExportProgress(1);
      setExportStage('done');
      setExportMessage(
        out.ext === 'mp4'
          ? 'فایلِ MP4 (H.264 + AAC) آماده است — هم دانلودِ مستقیم، هم انتشارِ عمومی.'
          : 'مرورگرِ شما MP4 ضبط نمی‌کند؛ فایلِ WebM آماده است. برای MP4 از Chrome/Edge نسخهٔ ۱۳۰ به بالا یا Safari استفاده کنید.',
      );
    } catch (err) {
      setExportStage('error');
      setExportMessage(err instanceof Error ? err.message : 'خطا در ضبطِ ویدیو.');
    } finally {
      audio.pause();
      isRecordingRef.current = false;
      recordingRef.current = null;
      sizePreview();
      timeRef.current = 0;
      renderAt(0);
    }
  }, [audio, renderAt, sizePreview]);

  const cancelExport = useCallback(() => {
    recordingRef.current?.cancel();
    audio.pause();
    isRecordingRef.current = false;
    sizePreview();
    setExportStage('idle');
    setExportProgress(0);
    setExportMessage('ضبط لغو شد.');
  }, [audio, sizePreview]);

  const download = useCallback(() => {
    if (!result) return;
    downloadBlob(result.blob, result.filename);
  }, [result]);

  const doUpload = useCallback(
    async (host: Host) => {
      if (!result) return;
      setUploading({ host, pct: 0, mb: 0 });
      setExportMessage(null);
      try {
        const link = await uploadTo(host, result.blob, result.filename, (pct, loadedMB) =>
          setUploading({ host, pct, mb: loadedMB }),
        );
        setLinks((prev) => [link, ...prev]);
        setExportMessage(
          host === 'tmpfiles.org'
            ? 'لینکِ عمومی ساخته شد. روی «کپیِ لینکِ مستقیم» بزنید تا آدرسِ دانلودِ بی‌واسطه کپی شود.'
            : 'لینکِ عمومیِ gofile آماده شد — صفحهٔ دانلود با ماندگاریِ بیشتر.',
        );
      } catch (err) {
        setExportStage('error');
        setExportMessage(
          `آپلود روی ${host} ناموفق بود: ${
            err instanceof Error ? err.message : 'خطای ناشناخته'
          } — سرویسِ دیگر یا دانلودِ مستقیم را امتحان کنید.`,
        );
      } finally {
        setUploading(null);
      }
    },
    [result],
  );

  const resetResult = useCallback(() => {
    if (result) URL.revokeObjectURL(result.url);
    setResult(null);
    setLinks([]);
    setExportStage('idle');
    setExportProgress(0);
    setExportMessage(null);
  }, [result]);

  /* ---------- میان‌برهای صفحه‌کلید ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') {
        e.preventDefault();
        void togglePlay();
      } else if (e.code === 'ArrowRight') {
        seek(timeRef.current - 5);
      } else if (e.code === 'ArrowLeft') {
        seek(timeRef.current + 5);
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, seek, toggleMute]);

  /* ---------- دریچهٔ کنترلِ بیرونی (برای اشکال‌زدایی و تستِ خودکار) ---------- */
  useEffect(() => {
    const w = window as unknown as Record<string, unknown>;
    w.__jaryanNoor = {
      seek,
      renderAt,
      /** رندرِ آفلاینِ فریم‌به‌فریم (برای خروجیِ دقیقِ MP4 بیرون از زمانِ واقعی) */
      beginOffline: (wpx: number, hpx: number) => {
        isRecordingRef.current = true;
        playingRef.current = false;
        audio.pause();
        const c = canvasRef.current!;
        c.width = wpx;
        c.height = hpx;
      },
      renderOffline: (t: number, energy: number, levels: number[], hud = true, subs = true) => {
        const c = canvasRef.current!;
        const ctx = c.getContext('2d', { alpha: false })!;
        timeRef.current = t;
        drawMotionFrame(ctx, t, c.width, c.height, energy, levels, {
          showHud: hud,
          showSubtitles: subs,
          captions: captionsRef.current,
        });
      },
      frameJpeg: (q = 0.9) => canvasRef.current!.toDataURL('image/jpeg', q).slice(23),
      play: () => void togglePlay(),
      get time() {
        return timeRef.current;
      },
      get canvas() {
        return canvasRef.current;
      },
      total: TOTAL_DURATION,
    };
  }, [seek, renderAt, togglePlay]);

  const activeCh = CHAPTERS.find((c) => c.id === activeChapter) ?? CHAPTERS[0];

  return (
    <div className="relative min-h-full">
      <div className="aurafield" />
      <div className="grain" />

      <div className="relative z-10 mx-auto max-w-[1500px] px-4 pb-24 pt-6 sm:px-7">
        {/* ══════════ سربرگ ══════════ */}
        <header className="mb-7 flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <span className="relative flex h-16 w-16 shrink-0 items-center justify-center">
              <svg viewBox="0 0 100 100" className="spin-slow absolute inset-0 h-full w-full">
                <g fill="none" stroke="rgba(251,191,36,0.55)" strokeWidth="1.3">
                  <circle cx="50" cy="50" r="46" />
                  <circle cx="50" cy="50" r="34" strokeDasharray="5 7" />
                  <rect x="18" y="18" width="64" height="64" transform="rotate(45 50 50)" />
                  <rect x="18" y="18" width="64" height="64" />
                </g>
              </svg>
              <svg viewBox="0 0 100 100" className="absolute h-7 w-7">
                <path
                  d="M50 8 58 34 84 26 66 46 92 50 66 54 84 74 58 66 50 92 42 66 16 74 34 54 8 50 34 46 16 26 42 34Z"
                  fill="#fde68a"
                />
              </svg>
            </span>
            <div>
              <p className="text-[11px] font-bold tracking-[0.32em] text-sky-300/80">موشن گرافیکِ المان‌محور</p>
              <h1 className="mt-1 font-display text-4xl leading-none text-amber-100 sm:text-5xl">فرکانسِ شکر</h1>
              <p className="mt-1.5 text-[12.5px] text-slate-400">
                منتخبِ ۵ دقیقه از سخنانِ استاد حاج نصرالله باستین • جلسهٔ سوم
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {[
              { k: 'مدت', v: `${formatTimeFa(TOTAL_DURATION)}` },
              { k: 'فصل', v: toFaDigits(CHAPTERS.length) },
              { k: 'صوت', v: audioDuration > 0 ? formatTimeFa(audioDuration) : '۰۵:۰۰' },
              { k: 'فصلِ جاری', v: `${toFaDigits(activeCh.id)} از ${toFaDigits(CHAPTERS.length)}` },
            ].map((chip) => (
              <span
                key={chip.k}
                className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-2 text-[11.5px] font-semibold text-slate-300 transition-colors duration-300 hover:border-amber-300/40"
              >
                <span className="text-slate-500">{chip.k}</span>
                <span className="tabular text-amber-200">{chip.v}</span>
              </span>
            ))}
          </div>
        </header>

        {/* ══════════ صحنه + پنلِ صوت ══════════ */}
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <div className="reveal is-in">
            <Stage
              canvasRef={canvasRef}
              wrapRef={wrapRef}
              timeRef={timeRef}
              playing={playing}
              muted={muted}
              audioLabel={
                audioState === 'error'
                  ? 'صوت در دسترس نیست — انرژیِ شبیه‌ساز'
                  : audioState === 'playing'
                    ? 'روایت پخش می‌شود'
                    : audioState === 'ready'
                      ? 'روایت آماده است'
                      : 'روایت بارگذاری نشده'
              }
              audioState={audioState}
              recording={exportStage === 'recording'}
              recProgress={exportProgress}
              chapterRef={chapterRef}
              energyRef={energyRef}
              levelsRef={levelsRef}
              aspectCss={ASPECT_CSS[settings.aspect]}
              onTogglePlay={() => void togglePlay()}
              onSeek={seek}
              onToggleMute={toggleMute}
              onFullscreen={fullscreen}
              onRestart={restart}
            />

            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setLoop((l) => !l)}
                className={`btn rounded-full border px-4 py-2 text-[12px] font-bold transition-colors ${
                  loop
                    ? 'border-emerald-400/45 bg-emerald-400/10 text-emerald-200'
                    : 'border-white/12 bg-white/5 text-slate-400'
                }`}
              >
                پخشِ پیوسته {loop ? 'روشن' : 'خاموش'}
              </button>
              <span className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-[11.5px] text-slate-500">
                میان‌برها: <span className="text-slate-300">Space</span> پخش •
                <span className="text-slate-300"> ← →</span> پنج ثانیه •
                <span className="text-slate-300"> M</span> بی‌صدا
              </span>
              <span
                className="rounded-full border px-4 py-2 text-[11.5px] font-bold transition-colors duration-500"
                style={{
                  borderColor: `${activeCh.accent}55`,
                  background: `${activeCh.accent}12`,
                  color: activeCh.accent,
                }}
              >
                {activeCh.badge} — {activeCh.title}
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-5">
            <AudioPanel
              state={audioState}
              error={audioError}
              duration={audioDuration}
              sourceLabel={sourceLabel}
              onLoadDefault={() => void loadDefaultAudio(true)}
              onPickFile={(f) => void loadFile(f)}
              busy={exportStage === 'recording'}
            />

            <section className="panel panel-hover rounded-3xl p-5 sm:p-6">
              <h2 className="font-display text-2xl leading-none text-amber-200">موتورِ کار</h2>
              <p className="mt-3 text-[13px] leading-7 text-slate-400">
                همه‌چیز روی <span className="text-slate-100">Canvas 2D</span> و به‌صورتِ برداری رسم می‌شود؛ هیچ
                ویدیوی آماده‌ای در کار نیست. المان‌ها با انرژیِ لحظه‌ایِ صدا می‌تپند و فریم‌ها در همان مرورگرِ شما
                به فایلِ ویدیویی تبدیل می‌شوند.
              </p>
              <ul className="mt-4 space-y-2.5">
                {[
                  ['۱', 'فضای طراحیِ ۱۲۸۰×۷۲۰ با مقیاسِ خودکار برای هر قطعیت'],
                  ['۲', 'هشت فصل، هرکدام با استعارهٔ بصریِ مستقل و پالتِ اختصاصی'],
                  ['۳', 'تحلیلِ صوت با AnalyserNode و انرژیِ نرم‌شده برای ضربِ المان‌ها'],
                  ['۴', 'ضبطِ بلادرنگ با MediaRecorder و چندسازشِ صوت و تصویر'],
                ].map(([n, txt]) => (
                  <li key={n} className="flex gap-3 text-[12.5px] leading-6 text-slate-400">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-amber-300/35 bg-amber-400/10 text-[11px] font-extrabold text-amber-200">
                      {n}
                    </span>
                    <span>{txt}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>

        {/* ══════════ فصل‌ها ══════════ */}
        <div className="reveal mt-6">
          <ChapterRail activeId={activeChapter} onSeek={seek} timeRef={timeRef} />
        </div>

        {/* ══════════ خروجی ══════════ */}
        <div className="reveal mt-6">
          <ExportPanel
            settings={settings}
            onSettings={setSettings}
            codecs={codecs}
            stage={exportStage}
            progress={exportProgress}
            message={exportMessage}
            result={result}
            onStart={() => void startExport()}
            onCancel={cancelExport}
            onDownload={download}
            uploading={uploading}
            links={links}
            onUpload={(h) => void doUpload(h)}
            onReset={resetResult}
          />
        </div>

        {/* ══════════ زیرنویس ══════════ */}
        <div className="reveal mt-6">
          <CaptionEditor
            captions={captions}
            onChange={setCaptions}
            onReset={() => setCaptions(CAPTIONS)}
            disabled={exportStage === 'recording'}
          />
        </div>

        {/* ══════════ پانویس ══════════ */}
        <footer className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-white/8 pt-6 text-[11.5px] leading-6 text-slate-500">
          <p>
            «فرکانسِ شکر» — موشن گرافیکِ المان‌محورِ ۰۵:۰۰ • هشت فصل • تایپوگرافیِ فارسیِ راست‌به‌چپ •
            خطِ نمایشیِ Lalezar و متنِ Vazirmatn و Amiri
          </p>
          <p className="text-slate-600">
            رندر و ضبط کاملاً در مرورگرِ شما انجام می‌شود؛ فایلی به سروری فرستاده نمی‌شود جز همان میزبانی که خودتان
            انتخاب می‌کنید.
          </p>
        </footer>
      </div>
    </div>
  );
}
